/// <reference path="../../../../../node_modules/bingmaps/types/MicrosoftMaps/Microsoft.Maps.All.d.ts" />

import { Component, AfterViewInit, ElementRef, ViewChild, OnInit, OnDestroy } from '@angular/core';
import { MapService } from '../../../services/map.service';
import { AssetsService } from '../../../services/assets.service';
import { ActivatedRoute, Router } from '@angular/router';
// import * as CanvasJS from '../../../../../canvasjs.min';
import {
  MapModule, MapAPILoader, MarkerTypeId, IMapOptions, IBox, IMarkerIconInfo, WindowRef, DocumentRef, MapServiceFactory,
  BingMapAPILoaderConfig, BingMapAPILoader,
  GoogleMapAPILoader, GoogleMapAPILoaderConfig
} from 'angular-maps';

@Component({
  selector: 'app-add-location',
  templateUrl: './add-location.component.html',
  styleUrls: ['./add-location.component.css']
})
export class AddLocationComponent implements OnInit {


  private searchManager: Microsoft.Maps.Search.SearchManager;
  private map: Microsoft.Maps.Map;
  public mapPin:any; 
  public lat;
  public lng;
  public assetid;
  public location;
  selectedParam;
  eventHandler;
  event;
  centerMarker;

  @ViewChild('myMap', { static: false }) myMap;

  constructor(private assetsService: AssetsService, private route: ActivatedRoute, private router: Router, public _dataService: MapService, private el: ElementRef) { }



  ngOnInit() {

    console.log("no oninit");
    this.assetid=this.assetsService.assetId;
    console.log("ADD LOCATION",this.assetid);
    this.mapOnInit();

  }

  mapOnInit() {

    this._dataService.load().then(() => {

      console.log("load completed");

      this.map = new Microsoft.Maps.Map(this.myMap.nativeElement, {
        credentials: 'Avh43rwIxMpHSkLOHeo7MeaFNwaQgk8BsehjzGxYxscXNvi6VH_VlUnX_MHAyFzw',
        center: new Microsoft.Maps.Location(14.954821, 77.613646),
        mapTypeId: Microsoft.Maps.MapTypeId.road,
        zoom: 1

      });

      console.log("map printed");

      Microsoft.Maps.Events.addHandler(this.map, 'click', e => {
        console.log("map clicked");
        this.addMarker(e);
  
      });

      if (!this.searchManager) {
        Microsoft.Maps.loadModule('Microsoft.Maps.Search', () => {
            this.searchManager = new Microsoft.Maps.Search.SearchManager(this.mapPin);
        });
    }

    this._dataService.GetSearchText.subscribe(searchParam => {
      this.selectedParam = searchParam;
    });

    Microsoft.Maps.loadModule('Microsoft.Maps.AutoSuggest', () => {
      var options = {
          maxResults: 6,
          map: this.map
      };
      var manager = new Microsoft.Maps.AutosuggestManager(options);
      manager.attachAutosuggest('#searchBox', '#searchBoxContainer', this.selectedSuggestion);
  });

    });

  


  }


  selectedSuggestion = (suggestionResult) => {
       
    console.log(suggestionResult);
    console.log(this.map)
    this.map.entities.clear();
   
    //this.showInfo = false;
    this.map.setView({ bounds: suggestionResult.bestView });
    //     var pushpin = new Microsoft.Maps.Pushpin(suggestionResult.location);
    //    this.map.entities.push(pushpin);
  
  
    console.log(suggestionResult.formattedSuggestion +
        ' &nbsp    Lat: ' + suggestionResult.location.latitude +
        '&nbsp    Lon: ' + suggestionResult.location.longitude);
  
  
    }
  

  addMarker(e) {

       console.log("Add marker called");
      this.map.entities.clear();
      this.event = e as Microsoft.Maps.IMouseEventArgs;
      console.log(this.event.location);
      let point = new Microsoft.Maps.Point(this.event.getX(), this.event.getY());
      this.lat=this.event.location.latitude;
      this.lng=this.event.location.longitude;
      this.centerMarker = new Microsoft.Maps.Location(this.event.location.latitude, this.event.location.longitude)
      var pin = new Microsoft.Maps.Pushpin(this.centerMarker, {
        icon: '../assets/place-24px.svg',
        //  anchor: new Microsoft.Maps.Point(-10, 80)
      });


      //Add the pushpin to the map
      this.map.entities.push(pin);
    this.assetsService.getLocationwithCoord(this.lat,this.lng).subscribe(res => {
      console.log("location details:"+res.resourceSets[0].resources[0].name);
      this.location=res.resourceSets[0].resources[0].name;
    });
 

  }



addLocation(){
  
  console.log("add location");
  

  let params:any = {
       
    RAM_AssetID: this.assetid,
    RAM_Latitude:this.lat,
    RAM_Longitude:this.lng,
    RAM_location:this.location,
    
    };

    console.log(params);

    this.assetsService.sendLocation(params)
    .subscribe( 
      (response:any) => {
        //alert("Asset locatiton added succesfully");
        console.log(response);
        this.router.navigate(['administration/asset-manager']);
      },
      (error) => {
        console.log(+error);
       
      });
}


cancel(){
  console.log("cancel called")
  this.map.entities.clear();
}

  
}


