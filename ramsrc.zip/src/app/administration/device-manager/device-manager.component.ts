import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AssetsService } from '../../services/assets.service';
declare var jQuery: any;
@Component({
  selector: 'app-device-manager',
  templateUrl: './device-manager.component.html',
  styleUrls: ['./device-manager.component.css']
})
export class DeviceManagerComponent implements OnInit {

  public sensorKitList;
  public fieldArray: Array<any> = [];
  private newAttribute: any = {};
  public sensorId;
  public parameters;
  public addedDevice: boolean = false;
  public deletedDevice: boolean = false;
  public editedDevice: boolean = false;
  public isFullyLoaded: boolean = false;
  public editArray = [];


  // public sensorParameterArray:Array<any> = [];

  constructor(private assetsService: AssetsService, private router: Router) { }

  ngOnInit() {
    this.getSensorKitList();
  }

  // API call to list the devices
  getSensorKitList() {
    this.assetsService.getSensorKitList()
      .subscribe(res => {
        this.sensorKitList = res;
        this.isFullyLoaded = true;
      });
  }

  setData(kit) {
    //console.log("setDAta");
    this.sensorId = kit.RAM_SensorID;
    let params: any = {
      RAM_SensorID: this.sensorId
    }
    //console.log(params);
    this.assetsService.getSensorKitParams(params)
      .subscribe(res => {
        this.fieldArray = res;
        // console.log(res);
        this.editArray = new Array(res.length);    //editArray is initialized       
        this.editArray.fill(false);
        console.log(this.editArray);
      });
  }

  addFieldValue() {
    this.fieldArray.push(this.newAttribute);
    this.editArray.push(true);       //new value is added to edit array
    this.newAttribute = {};
  }

  deleteFieldValue(index) {
    this.fieldArray.splice(index, 1);
  }

  // function for adding a device
  addDevice() {
    // console.log("add device called");
    let params: any = {
      RAM_SensorKit_ID: this.sensorId,
      parameters: this.fieldArray
    };
    params = JSON.stringify(params);
    //console.log(params);
    this.assetsService.addDevice(params)
      .subscribe(
        (response: any) => {
          //alert("Data Inserted succesfully");
          // hide the modal on successfull addition
          jQuery("#addSensorKitModal").modal("hide");
          this.addedDevice = true;
          this.editedDevice = false;
          this.deletedDevice = false;
          this.getSensorKitList();
          this.router.navigate(['administration/device-manager']);
        },
        (error) => {
          console.log('we are in error part' + error);
          //alert(error);
        });
  }

  // function for editing a device
  editSensorKit(params) {
    params = JSON.stringify(params);
    //console.log(params);
    //jQuery("#editSensorKitModal").modal("hide");
    this.assetsService.editDevice(params)
      .subscribe(
        (response: any) => {
          //alert("Data edited succesfully");
          this.addedDevice = false;
          this.editedDevice = true;
          this.deletedDevice = false;
          this.getSensorKitList();
        },
        (error) => {
          //alert(error);
        });
  }



  //function for closing modal box after editing sensor kit

  closeEditModal() {
    jQuery("#editSensorKitModal").modal("hide");
  }

  //function for deleting device parameter
  deleteParameter(index) {
    let params: any = {
      RAM_SensorID: this.sensorId,
      RAM_parameter: this.fieldArray[index].RAM_parameter
    }
    this.assetsService.deleteSensorParameter(params)
      .subscribe(
        (res) => {
          console.log(res);
          this.deleteFieldValue(index);

        },
        (err) => {
          console.log(err);
        })



  }

  // function for editing device parameter
  editParameter(index) {
    // this.sensorParameterArray.push(        {
    //   RAM_parameter: this.fieldArray[index].RAM_parameter,
    //   RAM_R_MIN: this.fieldArray[index].RAM_R_MIN,
    //   RAM_R_MAX: this.fieldArray[index].RAM_R_MAX,
    //   RAM_A_MIN: this.fieldArray[index].RAM_A_MIN,
    //   RAM_A_MAX: this.fieldArray[index].RAM_A_MAX,
    //   RAM_G_MIN: this.fieldArray[index].RAM_G_MIN,
    //   RAM_G_MAX: this.fieldArray[index].RAM_G_MAX
    // });
    // console.log(this.sensorParameterArray);


    let params: any = {
      RAM_SensorID: this.sensorId,
      RAM_parameter: this.fieldArray[index].RAM_parameter,
      RAM_R_MIN: this.fieldArray[index].RAM_R_MIN,
      RAM_R_MAX: this.fieldArray[index].RAM_R_MAX,
      RAM_A_MIN: this.fieldArray[index].RAM_A_MIN,
      RAM_A_MAX: this.fieldArray[index].RAM_A_MAX,
      RAM_G_MIN: this.fieldArray[index].RAM_G_MIN,
      RAM_G_MAX: this.fieldArray[index].RAM_G_MAX
    };
    //console.log(params);
    this.editSensorKit(params);
  }

  // function for deleting device
  deleteSensorKit() {
    let params: any = {
      RAM_SensorID: this.sensorId
    };
    this.assetsService.deleteSensorKit(params)
      .subscribe(
        res => {
          console.log("The sensor kit was deleted");
          this.addedDevice = false;
          this.editedDevice = false;
          this.deletedDevice = true;
          this.getSensorKitList();
  
        },
        err => {
         // console.log("We are on error part");
         jQuery("#deleteLinkedSensorKit").modal("show");
          console.log(err);
        } );

        
        
        
  }

  clearDevice() {
    this.addedDevice = false;
    this.editedDevice = false;
    this.deletedDevice = false;
  }

  clearAddSensorKit() {
    //alert('inside clear alert');
    jQuery('#addSensorKitModal').find("input,textarea,select").val('').end();
    // jQuery('#addSensorKitModal').on('hidden.bs.modal', function () {
    //   jQuery(this).find("input,textarea,select").val('').end();       
    // });
  }


}