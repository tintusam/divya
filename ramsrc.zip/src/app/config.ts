export const Config = Object.freeze({
     BASE_API_URL: 'https://ramfuncapi.azurewebsites.net/',
     SECOND_API_URL: 'https://ramsolutionfunction.azurewebsites.net/',
     API_PATH: 'api/' 
});        
