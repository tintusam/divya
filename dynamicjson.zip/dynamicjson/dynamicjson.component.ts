import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dynamicjson',
  templateUrl: './dynamicjson.component.html',
  styleUrls: ['./dynamicjson.component.css']
})
export class DynamicjsonComponent implements OnInit {

  public questionnire:any;
  public fullQuestionnire:any;
  public itemsPerPage:number;
  public pageNumber:number;
  public totalQuestionnire:number;
  public totalPages:number;
  public endPage:boolean = false;
  public postData:any;

  constructor() { }

  ngOnInit(): void {
    this.questionnire = [
      {
        "questionNumber":"Q1",
        "questionName":"Please choose appropriate option",
        "questionType":"radiobuton",
        "answerOptions":[
          { "value":"I am coming to office vountarily" },
          { "value":"I have not volunteered to come to office" }
        ],
        "selectedAnswer":''
      },

      {
        "questionNumber":"Q2",
        "questionName":"Please select relevant option",
        "questionType":"radiobuton",
        "answerOptions":[
          { "value":"I am Healthy" },
          { "value":"I have one of these symptoms - Fever, Dry cough, Body Ache, Headaches, Sore throat, Runny Nose, Tiredness, and Shortness of Breath" }
        ],
        "selectedAnswer":''
      },

      {
        "questionNumber":"Q3",
        "questionName":"Download of Aarogya Setu app is recommended by Goverment of India for entering inside the office",
        "questionType":"radiobuton",
        "answerOptions":[
          { "value":"I have the Aarogya Setu App" },
          { "value":"I have not downloaded the Aarogya Setu app" }
        ],
        "selectedAnswer":''
      },
      {
        "questionNumber":"Q4",
        "questionName":"Have you been in contact with a confirmed COVID-19 patient in past 28 Days?",
        "questionType":"radiobuton",
        "answerOptions":[
          { "value":"Yes" },
          { "value":"No" }
        ],
        "selectedAnswer":''
      },

      {
        "questionNumber":"Q5",
        "questionName":"Have you been to COVID-19 affected countries or hot spots inside the country in past 28 days?",
        "questionType":"radiobuton",
        "answerOptions":[
          { "value":"Yes" },
          { "value":"No" }
        ],
        "selectedAnswer":''
      },

      {
        "questionNumber":"Q6",
        "questionName":"Declaration: If I have any symptoms like -Fever,Dry Cough,Body Ache, Headaches,Sore throat, Runny Nose, Tiredness,Shortness of Breath or related symptoms, I will NOT come to office",
        "questionType":"radiobuton",
        "answerOptions":[
          { "value":"Accept" },
          { "value":"Decline" }
        ],
        "selectedAnswer":''
      },
      
      {
        "questionNumber":"Q7",
        "questionName":"Declaration: I agree to abide by the Social Media Policy of company (For details, please visit the Social Media Policy in the Suraksha app)",
        "answerOptions":[
          { "value":"Accept" },
          { "value":"Decline" }
        ],
        "selectedAnswer":''
      }      

    ];
    this.itemsPerPage = 3;
    this.pageNumber = 1;
    this.fullQuestionnire = this.questionnire; // assigning qstns to new variable as we will replace exsiting
    this.totalQuestionnire = this.fullQuestionnire.length; // calculating total number of questions
    this.questionnire = this.paginate(this.fullQuestionnire, this.itemsPerPage, 1); // setting first page
    this.totalPages = Math.ceil(this.totalQuestionnire /this.itemsPerPage); // calculating total pages
  }

  // method to show final answers that needs to be passed to backend service
  onSubmit(formData){
    //console.log(formData.value);
    this.postData = JSON.stringify(formData.value);
  }

  // method displays data of a paginated page
  paginate(questions, itemsPerPage, pageNumber) {
    return questions.slice((pageNumber - 1) * itemsPerPage, pageNumber * itemsPerPage);
  }

  // Method to show next set of three questions
  NextPage(){
    this.pageNumber = this.pageNumber + 1;
    // to display paginated data 
    // if page number is 2 it displays second page data
    this.questionnire = this.paginate(this.fullQuestionnire, this.itemsPerPage, this.pageNumber);
    // checking if current page is the last page
    if (this.pageNumber === this.totalPages){
      this.endPage = true;
    }
  }
  
}
