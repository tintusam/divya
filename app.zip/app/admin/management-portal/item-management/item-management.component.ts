import { Component, OnInit, Output, EventEmitter, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from '../../../../environments/environment.prod';
import { from, Observable } from 'rxjs';
import { combineAll, map } from 'rxjs/operators';
import { ISasToken } from '../../../../assets/azure-storage/azureStorage';
import { BlobStorageService } from '../../../../assets/azure-storage/blob-storage.service';
import { ProductService } from '../../../services/product.service';
import { formatDate } from '@angular/common';
import Swal from 'sweetalert2';
interface IUploadProgress {
  filename: string;
  progress: number;
};

@Component({
  selector: 'app-item-management',
  templateUrl: './item-management.component.html',
  styleUrls: ['./item-management.component.css']
})
export class ItemManagementComponent implements OnInit {

  public selectedTimeZone: String;
  today = new Date();
  todaysDataTime = '';
  selectedFile: String;
  public showUploadForm: boolean = false;
  public vendorsList: any;
  public showLoader: boolean = false;
  public showUploadComplete: boolean = false;
  public filesSelected: boolean = false;
  public showButton: boolean = false;
  public showInvalidFileExtensionMsg: boolean = false;
  @Output() onExit = new EventEmitter<any>();
  uploadProgress$: Observable<IUploadProgress[]>;
  public fileUploadSuccess: boolean = false;
  public uploadFileName: string;
  public storageUrl = '';
  public fullName: string;
  public productInfo:any;
  public initialProduct:string;
  public isLoaded:boolean = false;
  public productList:any;
  public currentFile:any;

  constructor(private blobStorage: BlobStorageService, private _productService:ProductService, private _router:Router) { }
  items = [1, 2, 3, 4, 5];
 
  
  ngOnInit(): void {
    if(localStorage.getItem("userRole")!='Admin'){
      this._router.navigateByUrl('my-dashboard');
    }else{
      this.fullName = localStorage.getItem("fullName");
      this.getProductList();
    }
    
  }

  toggleUploadForm(){
    this.showUploadForm = !this.showUploadForm;
    console.log(this.showUploadForm);
  }

  get fileName(): string {
    return this.selectedFile ? this.selectedFile.split('/').pop() : 'Browse';
  }


  // Method to push file to blob on selecting it from UI
  onFileChange(event: any): void {
    this.showLoader = true;
    this.showUploadComplete = false;
    this.filesSelected = true;
    this.showButton = true;
    this.currentFile = event.target.files;
    //console.log(event.target.files[0])
    
  }

  uploadFile(file: File): Observable<IUploadProgress> {
    if (!(file.type === "text/csv" || file.type === "application/vnd.ms-excel")) {
      alert('Please Choose a file with .csv Extension only.');
      this.showLoader = false;
      this.showButton = false;
      this.showInvalidFileExtensionMsg = true;
    } else {
      this.uploadFileName = file.name;
      this.storageUrl = environment.blobAccessUrl + this.uploadFileName + environment.SAS_Token
      const accessToken: ISasToken = {
        container: 'itrackcontainer', // container with same name should be created in blob storage account
        filename: file.name,
        storageAccessToken: environment.SAS_Token,
        storageUri: environment.storageLink + environment.SAS_Token,
      };
      return this.blobStorage
        .uploadToBlobStorage(accessToken, file)
        .pipe(map(progress => this.mapProgress(file, progress)));
    }
  }

  private mapProgress(file: File, progress: number): IUploadProgress {
    if (progress === 100) {
      this.showLoader = false;
      this.showUploadComplete = true;
      this.fileUploadSuccess = true;
      this.filesSelected = false;
      this.showButton = true;
    }
    return {
      filename: file.name,
      progress: progress
    };
  }

  // Method to sync csv data from blob to database
  onUploadCSV() {
    this.uploadProgress$ = from(this.currentFile as FileList).pipe(
      map(file => this.uploadFile(file)), // Getting FIle Details HEre
      combineAll()
    );
    let payload = {
      "blobContainerName": this.currentFile[0]['name'],
      "createdBy": this.fullName
      //'filePath': ''
    }
    this._productService.uploadProductDetailsCSV(payload).subscribe(res => {
      this.showInvalidFileExtensionMsg = false;
      this.onExit.emit(false);
      this.showButton = false;
      this.showUploadForm = false;
      this.selectedFile = '';
      this.getProductList();
      Swal.fire({
        position: 'top-end',
        icon: 'success',
        text: 'Uploaded Successfully!',
        showConfirmButton: false,
        timer: 2000
      })
    }, error => {
      Swal.fire({
        position: 'top-end',
        icon: 'error',
        text: 'Failed to Upload!',
        showConfirmButton: true,
        confirmButtonColor:'#cd0000'
        //timer: 1500
      })
      this.showLoader = false;
      this.showButton = false;
      this.selectedFile = '';
    })
  }

  getProductList(){
    this.isLoaded=false;
    this._productService.listAllProducts().subscribe(
      res => {
        this.productList = res;
        this.isLoaded=true;
        //console.log(this.productList);
        this.initialProduct = this.productList[0]["materialCode"];
        //console.log(this.initialProduct);
        this.showProductInfo(this.initialProduct);
      },
      err => {
        console.log(err);
      }
    )
  }

  showProductInfo(materialCode){
    this.isLoaded = false;
    let payload = {
      materialCode:materialCode
    }
    this._productService.getProductInfo(payload).subscribe(
      res => {
        this.isLoaded = true;
        this.productInfo = res[0];
       // console.log(this.productInfo);
      },
      err => {
        console.log(err);
            }
    )
  }

  
}
