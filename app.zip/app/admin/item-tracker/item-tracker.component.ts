import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import {TrackerService} from '../../services/tracker.service';

@Component({
  selector: 'app-item-tracker',
  templateUrl: './item-tracker.component.html',
  styleUrls: ['./item-tracker.component.css']
})
export class ItemTrackerComponent implements OnInit {
  public toggleStatus: boolean = false;
  public toggleFlag: boolean;
  public materialSteps: any;
  public poContent: any;
  public selectedItem: any;
  public DateRange:string[] = [];
  public filterStartMonth:any;
  public filterStartDate:any;
  public filterEndMonth:any;
  public filterEndDate:any;
  public dueDateType:string = "DueDate";
  public getLineItemTracker:any;
  public query:any = '';
  public isLoaded: boolean = false;

  constructor(private _router: Router, private _trackerService:TrackerService) { }

  ngOnInit(): void {
    if(localStorage.getItem("userRole")!='Admin'){
      this._router.navigateByUrl('my-dashboard');
    }else{
      this.listAllTrackerItems();
    }
    
  }

// Method to toggle expand and collapse all items on single click
  toggleItems() {
    this.toggleStatus = !this.toggleStatus;
    for (let i = 0; i < this.getLineItemTracker.length; i++) {
      this.getLineItemTracker[i]['toggleFlag'] = this.toggleStatus;
    }  
  }

  // Expand and collapse selected item
  toggleSelectedItem(selectedItem) {
    this.getLineItemTracker[selectedItem]['toggleFlag'] = !this.getLineItemTracker[selectedItem]['toggleFlag'];
  }

  backToDashboard() {
    this._router.navigateByUrl('dashboard');
  }

  getSelectedDateType(e){
    if(!e.target.value){
      this.dueDateType = "DueDate";
    }else{
      this.dueDateType = e.target.value;
    }
  }


  // Method to filter items by date
  onFilterByDate(){
    this.isLoaded = false;
    this.filterStartMonth = new Date(this.DateRange[0]).getMonth();
    this.filterStartMonth = this.filterStartMonth + 1;
    this.filterEndMonth = new Date(this.DateRange[1]).getMonth();
    this.filterEndMonth = this.filterEndMonth +1;
    this.filterStartDate = new Date(this.DateRange[0]).getFullYear() +"-"+this.filterStartMonth+"-"+new Date(this.DateRange[0]).getDate();
    this.filterEndDate = new Date(this.DateRange[1]).getFullYear() +"-"+this.filterEndMonth+"-"+new Date(this.DateRange[1]).getDate();  
    if(isNaN(this.filterStartMonth)){
      Swal.fire({
        icon: 'error',
        text: 'Select a date range',
        showConfirmButton: false,
        timer: 1500
      })
    }else{
      let payload={
        fromDate:this.filterStartDate,
        toDate:this.filterEndDate,
        dateType:this.dueDateType
      }

      this._trackerService.getLineItemTracker(payload).subscribe(
        res => {
          this.getLineItemTracker = res;
          this.isLoaded = true;
          console.log(this.getLineItemTracker);
        },
        err => {
          console.log(err);
        }
      )  
    }
  }

  listAllTrackerItems(){
    let payload={
      fromDate:null,
      toDate:null,
      dateType:null
    }
    this.isLoaded = false;
    this._trackerService.getLineItemTracker(payload).subscribe(
      res => {
        this.getLineItemTracker = res;
        this.isLoaded = true;
        console.log(this.getLineItemTracker);
      },
      err => {
        console.log(err);
      }
    )
  }

  
}
