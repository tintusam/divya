import { Component, OnInit, Output, EventEmitter, AfterViewInit } from '@angular/core';
import {Router} from '@angular/router';
import { environment } from '../../../environments/environment.prod';
import { from, Observable } from 'rxjs';
import { combineAll, map } from 'rxjs/operators';
import { ISasToken } from '../../../assets/azure-storage/azureStorage';
import { BlobStorageService } from '../../../assets/azure-storage/blob-storage.service';
import { DashboardService } from '../../services/dashboard.service';
import Swal from 'sweetalert2';

interface IUploadProgress {
  filename: string;
  progress: number;
};

@Component({
  selector: 'app-po-dashboard',
  templateUrl: './po-dashboard.component.html',
  styleUrls: ['./po-dashboard.component.css']
})
export class PoDashboardComponent implements OnInit {

  public selectedFile:String;
  public showUploadForm: boolean = false;
  public vendorsList: any;
  public showLoader: boolean = false;
  public showUploadComplete: boolean = false;
  public filesSelected: boolean = false;
  public showButton: boolean = false;
  public showInvalidFileExtensionMsg: boolean = false;
  @Output() onExit = new EventEmitter<any>();
  uploadProgress$: Observable<IUploadProgress[]>;
  public fileUploadSuccess: boolean = false;
  public uploadFileName: string;
  public storageUrl = '';
  public fullName: string;
  public poList:any;
  public isLoaded:boolean = false;
  public query:any='';

  constructor(private blobStorage: BlobStorageService, private _dashboardService:DashboardService, private _router:Router) { }

  ngOnInit(): void {
    this.fullName = localStorage.getItem("fullName");
    if(localStorage.getItem("userRole")!='Admin'){
      this._router.navigateByUrl('my-dashboard');
    }else{
      this.fullName = localStorage.getItem("fullName");
      this.listPOdata();
    }
    
  }


  toggleUploadForm(){
    this.showUploadForm = !this.showUploadForm;
    console.log(this.showUploadForm);
  }

  get fileName(): string {
    return this.selectedFile ? this.selectedFile.split('/').pop() : 'Browse';
  }

    // Method to push file to blob on selecting it from UI
    onFileChange(event: any): void {
      this.showLoader = true;
      this.showUploadComplete = false;
      this.filesSelected = true;
      //console.log(event.target.files[0])
      this.uploadProgress$ = from(event.target.files as FileList).pipe(
        map(file => this.uploadFile(file)), // Getting FIle Details HEre
        combineAll()
      );
    }
  
    uploadFile(file: File): Observable<IUploadProgress> {
      if (!(file.type === "text/csv" || file.type === "application/vnd.ms-excel")) {
        alert('Please Choose a file with .csv Extension only.');
        this.showLoader = false;
        this.showButton = false;
        this.showInvalidFileExtensionMsg = true;
      } else {
        this.uploadFileName = file.name;
        this.storageUrl = environment.blobAccessUrl + this.uploadFileName + environment.SAS_Token
        const accessToken: ISasToken = {
          container: 'halliburton', // container with same name should be created in blob storage account
          filename: file.name,
          storageAccessToken: environment.SAS_Token,
          storageUri: environment.storageLink + environment.SAS_Token,
        };
        return this.blobStorage
          .uploadToBlobStorage(accessToken, file)
          .pipe(map(progress => this.mapProgress(file, progress)));
      }
    }
  
    private mapProgress(file: File, progress: number): IUploadProgress {
      if (progress === 100) {
        this.showLoader = false;
        this.showUploadComplete = true;
        this.fileUploadSuccess = true;
        this.filesSelected = false;
        this.showButton = true;
      }
      return {
        filename: file.name,
        progress: progress
      };
    }
  
    // Method to sync csv data from blob to database
    UploadCSV() {
      let payload = {
        "blobContainerName": this.uploadFileName,
        "createdBy": this.fullName
      }
      this._dashboardService.uploadPoDetailsCSV(payload).subscribe(res => {
        this.showInvalidFileExtensionMsg = false;
        this.onExit.emit(false);
        this.showButton = false;
        this.showUploadForm = false;
        this.selectedFile = '';
        this.listPOdata();
        Swal.fire({
          position: 'top-end',
          icon: 'success',
          text: 'Uploaded Successfully!',
          showConfirmButton: false,
          timer: 1500
        })
      }, error => {
        Swal.fire({
          position: 'top-end',
          icon: 'error',
          text: 'Failed to Upload!',
          showConfirmButton: false,
          timer: 1500
        })
        this.showLoader = false;
        this.showButton = false;
        this.selectedFile = '';
      })
    }

    public listPOdata(){
      this.isLoaded = false;
      let payload ={
        userType:localStorage.getItem("userRole"),
        vendorCode:localStorage.getItem("vendorCode")
      }
      this._dashboardService.listPoDetails(payload).subscribe(
        res => {
          this.poList = res;
          this.isLoaded = true;
          console.log(this.poList);
        },
        err => {
          console.log(err);
        }
      )
    }
  
  
}
