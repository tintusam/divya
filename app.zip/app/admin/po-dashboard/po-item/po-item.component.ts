import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { DashboardService } from '../../../services/dashboard.service';

@Component({
  selector: 'app-po-item',
  templateUrl: './po-item.component.html',
  styleUrls: ['./po-item.component.css']
})
export class PoItemComponent implements OnInit {

  public toggleStatus: boolean = false;
  public toggleFlag: boolean = false;
  public materialSteps: any;
  public poContent: any;
  public selectedItem: any;
  public poItems: any;
  public poDetails: any;
  public isLoaded: boolean = false;
  public isFullyLoaded: boolean = false;


  public poNumber: string;

  constructor(private _router: Router, private _dashboard: DashboardService, private _activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {

    if(localStorage.getItem("userRole")!='Admin'){
      this._router.navigateByUrl('my-dashboard');
    }else{
      this.poNumber = this._activatedRoute.snapshot.paramMap.get("poNumber");
      if (this.poNumber) {
        this.onGetPOMaterialInfo();
        this.onGetSinglePODetails();
      } else {
        console.log('failed to get PO number');
      }
    }    
  }

  onGetSinglePODetails() {
    this.isLoaded = false;
    let payload = {
      poNumber: this.poNumber
    }
    this._dashboard.getSinglePODetails(payload).subscribe(
      res => {
        this.poDetails = res[0];
        this.isLoaded = true;
      },

      err => {
        console.log(err);
      }
    )
  }


  onGetPOMaterialInfo() {
    let payload = {
      poNumber: this.poNumber
    }
    this.isFullyLoaded = false;
    this._dashboard.getPOMaterialInfo(payload).subscribe(
      res => {
        this.poItems = res;
        this.isFullyLoaded = true;
        console.log(this.poItems);
      },
      err => {
        console.log(err);
      }
    )
  }

  toggleItems() {
    this.toggleStatus = !this.toggleStatus;
    for (let i = 0; i < this.poItems.length; i++) {
      this.poItems[i]['toggleFlag'] = this.toggleStatus;
    }
  }

  toggleSelectedItem(selectedItem) {
    this.poItems[selectedItem]['toggleFlag'] = !this.poItems[selectedItem]['toggleFlag'];
  }

  backToDashboard() {
    this._router.navigateByUrl('dashboard');
  }



}
