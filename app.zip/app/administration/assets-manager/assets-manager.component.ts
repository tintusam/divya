import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { last } from 'rxjs/operators';
import { from, Observable } from 'rxjs';
import { AssetsService } from '../../services/assets.service';
import { DashboardService } from './../../services/dashboard.service';

declare var jQuery: any;

interface IUploadProgress {
  filename: string;
  progress: number;
}

@Component({
  selector: 'app-assets-manager',
  templateUrl: './assets-manager.component.html',
  styleUrls: ['./assets-manager.component.css']
})

export class AssetsManagerComponent implements OnInit {

  private sas = '?sv=2019-02-02&ss=bfqt&srt=sco&sp=rwdlacup&se=2031-03-31T19:31:21Z&st=2020-01-24T11:31:21Z&spr=https&sig=fiJghPWfH%2FdCKzBsqw8570yAEk5roOjWw4adwxPCwfg%3D';
  private storageuri = 'https://ramstorageimage.blob.core.windows.net/';
  public imageSrc: string = '';
  public fileName;
  public fileType;
  public assetsList;
  public sensorKitList;
  public assetId;
  public assetName;
  public assetlocation;
  public asset_SensorkitID;
  public assetStakeHolder;
  public assetContact;
  public uploadimage;
  public assetType = "Non Movable";
  public imgfile;
  public imageUrl;
  public imagePreview;
  public all = false;
  public isShown: boolean = false // hidden by default
  selected = [];
  public selectedAll: any;
  public itemsToDelete: any;
  public deleteSelectedIDs: any[] = [];
  public deletedIds: any[] = [];
  recentData: any;
  public sensorParameters: Array<any> = [];
  public sensorId;


  uploadProgress$: Observable<IUploadProgress[]>;
  filesSelected = false;

  constructor(private assetsService: AssetsService, private dashboardService: DashboardService) { }

  ngOnInit() {
    this.getAssetsList();
    this.getSensorKitList();
    this.showRecentAssetDetails();
  }

  // method to list all assets
  getAssetsList() {
    let payload = {
      "custId": JSON.parse(localStorage.getItem("customerID"))
    }
    this.assetsService.getDeviceList(payload)
      .subscribe(res => {
        //console.log("Assets List is: ");
        //console.log(res);
        this.assetsList = res;
        for (let a of this.assetsList) {
          //console.log(a);
        }
      });
  }

  // Method to List Devices
  getSensorKitList() {
    let payload = {
      "custId": JSON.parse(localStorage.getItem("customerID"))
    }
    this.assetsService.getSensorKitList(payload)
      .subscribe(res => {
        this.sensorKitList = res;
      });
  }


  onFilterByAssetData(e) {
    var input, filter, ul, li, a, i, txtValue, selectedClassName;
    input = e.target.value;
    selectedClassName = e.target.className;
    selectedClassName = selectedClassName.toString();
    filter = input.toUpperCase();
    ul = document.getElementById("accordion");
    li = ul.getElementsByClassName("assetList");
    for (i = 0; i < li.length; i++) {
      a = li[i].getElementsByClassName(selectedClassName)[0];
      txtValue = a.textContent || a.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        li[i].style.display = "";
      } else {
        li[i].style.display = "none";
      }
    }
  }


  setData(asset) {
    //console.log("setdata called");
    this.assetsService.assetId = asset.RAM_AssetID;
    this.assetId = asset.RAM_AssetID;
    this.assetName = asset.RAM_Assetname;
    this.assetStakeHolder = asset.RAM_SensorkitID;
    this.assetContact = asset.RAM_Asset_Contact;
    this.uploadimage = asset.RAM_Image;
  }

  setSensorData(sensorID) {
    console.log(sensorID);
    this.sensorId = sensorID;
    let params: any = {
      RAM_SensorID: this.sensorId,
      custId:JSON.parse(localStorage.getItem("customerID"))
    }
    //console.log(params);
    this.assetsService.getSensorKitParams(params)
      .subscribe(res => {
        this.sensorParameters = res;
        //console.log(this.sensorParameters);
      });

  }

  checkIfAssetMoveable(e) {
    if (e.target.checked) {
      this.assetType = "Movable";
    } else {
      this.assetType = "Non Movable";
    }
  }

  // method for file uploading
  public onImageUpload(e) {
    this.filesSelected = true;
    var file = e.dataTransfer ? e.dataTransfer.files[0] : e.target.files[0];
    var pattern = /image-*/;
    this.fileName = file.name;
    this.fileType = file.type;
    var fReader = new FileReader();
    if (!file.type.match(pattern)) {
      console.log('invalid file format');
      return;
    }
    fReader.onload = this.handleUploadedImage.bind(this);
    fReader.readAsDataURL(file);
  }

  // method for file preview rendering as base64
  public handleUploadedImage(e) {
    let reader = e.target;
    this.imageSrc = reader.result; // stored base64 image
    //console.log(this.imageSrc);
  }

  // added this function to clear the image preview and image data while clicking cancel button of modal
  clearSelection() {
    this.filesSelected = false;
  }


  // Method to add Asset Data to Azure Backend
  onAddAsset(assetFormData: NgForm) {
    //console.log("add asset");
    if (assetFormData.valid) {
      //console.log(assetFormData.value);
      let params: any = {
        RAM_AssetID: assetFormData.value.assetId,
        RAM_Asset_Type: this.assetType,
        RAM_Assetname: assetFormData.value.assetName,
        RAM_location: "Bangalore",
        RAM_SensorkitID: assetFormData.value.assetStakeHolder,
        RAM_Image: this.imageSrc,
        RAM_Asset_Contact: this.assetContact,
        custId: JSON.parse(localStorage.getItem("customerID"))
      };
      // params is the custom asset data we get by filling the form that need to be posted to rest api of azure
      //console.log(params);
      // to clear the form after submission
      assetFormData.reset();
      this.assetsService.postAssetData(params)
        .subscribe(
          (response: any) => {
            this.onAddAssetDataSuccess(response);
          },
          (error) => {
            this.onAddAssetDataError(error);
          });
    }
  }

  public clearAddModal() {
    jQuery(document).ready(function () {
      jQuery('.modal').on('hidden.bs.modal', function (e) {
        jQuery(this).removeData();
      });
    });

    //jQuery("#addAssetModal").removeData();
  }

  onAddAssetDataSuccess(response) {
    jQuery("#addAssetModal").modal("hide");
    //console.log('Successfully Added Assets Data with response of ' + response);
    this.getAssetsList();
  }

  onAddAssetDataError(error) {
    console.log('Failed to Add Assets Data with error response of ' + error);
    this.getAssetsList();
  }

  // Method to Edit Asset Data from Azure Backend
  onEditAsset(assetFormData: NgForm) {
    if (assetFormData.valid) {
      let params: any = {
        RAM_AssetID: assetFormData.value.assetId,
        RAM_Asset_Type: this.assetType,
        RAM_Assetname: assetFormData.value.assetName,
        RAM_location: "Bangalore",
        RAM_SensorkitID: assetFormData.value.assetStakeHolder,
        RAM_Image: this.imageSrc,
        RAM_Asset_Contact: assetFormData.value.assetContact,
        custId:JSON.parse(localStorage.getItem("customerID"))
      };
      assetFormData.resetForm();
      this.assetsService.editAssetData(params)
        .subscribe(
          (response: any) => {
            jQuery("#editAssetModal").modal("hide");
            this.getAssetsList();
            this.onAddAssetDataSuccess(response);
            //console.log(response);
          },
          (error) => {
            this.onAddAssetDataError(error);
          });
    }
  }

  // Method to delete particular Asset Data
  deleteAsset() {
    let params: any = {
      RAM_AssetID: this.assetId,
      custId: JSON.parse(localStorage.getItem("customerID"))
    };
    this.assetsService.deleteAsset(params)
      .subscribe(
        res => {
          // console.log(res);
          console.log("The asset was deleted");
          this.getAssetsList();
        }
      );
  }

// Method to delete alerts related to an asset
  deleteAlert() {
    let params: any = {
      RAM_AssetID: this.assetId,
      custId: JSON.parse(localStorage.getItem("customerID"))
    };
    this.assetsService.deleteAlert(params)
      .subscribe(
        res => {
          this.getAssetsList();
        }
      );
  }

  // method to delete an asset
  // it unlinks all assets and alerts data related to the deleted asset and updates latest assets list
  onDeleteAsset() {
    this.deleteAsset();
    //this.deleteAlert();
    this.getAssetsList();
  }

  // method to delete selected assets
  deleteSelectedItems() {
    let d = 0;
    for (let s of this.selected) {
      let params: any = {
        RAM_AssetID: s,
        custId: JSON.parse(localStorage.getItem("customerID"))
      };
      this.assetsService.deleteAsset(params)
        .subscribe(
          res => {
            console.log("The asset was deleted", res);
            d++;
            if (d == this.selected.length) {
              this.getAssetsList();
              this.all = false;
            }
          }
        );
    }
  }

  //utility function to capture the checked and unchecked assets which can be used for multiple delete
  onCheck(event, value) {
    if (!event.checked) {
      let index = this.selected.indexOf(value);
      if (index > -1) {
        this.selected.splice(index, 1);
      }
      else {
        this.selected.push(value);
      }
    }
  }

  // functions written for select all
  selectAll() {
    this.all = !this.all;
    if (this.all) {
      for (var i = 0; i < this.assetsList.length; i++) {
        this.selected.push(this.assetsList[i].RAM_AssetID);
      }
    }
    else {
      this.selected = [];
    }
    //console.log("selected :" + this.selected);
  }

  // function to get most recent data of an asset
  showRecentAssetDetails() {
    let params: any = {
      RAM_AssetID: this.assetId,
      custId:JSON.parse(localStorage.getItem("customerID"))
    };
    this.dashboardService.getAssetDetails(params)
      .pipe(last())
      .subscribe(
        (res) => {
          var resData = JSON.parse(res["_body"]);
          this.recentData = resData.slice(-1)[0];
          //console.log(this.recentData);
        }
      )
  }

}
