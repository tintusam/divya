import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-asset-modal',
  templateUrl: './delete-asset-modal.component.html',
  styleUrls: ['./delete-asset-modal.component.css']
})
export class DeleteAssetModalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
