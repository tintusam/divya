import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import {AssetsService} from '../../../services/assets.service';

@Component({
  selector: 'app-add-asset-modal',
  templateUrl: './add-asset-modal.component.html',
  styleUrls: ['./add-asset-modal.component.css']
})
export class AddAssetModalComponent implements OnInit {

  constructor( private assetsService:AssetsService) { }

  ngOnInit() {
  }

  onAddAsset(assetFormData: NgForm) {
    if (assetFormData.valid) {
      //console.log(assetFormData.value);
      let params:any = {
        RAM_AssetID: assetFormData.value.assetId,
        RAM_Asset_Type : "movable",
        RAM_Assetname: assetFormData.value.assetName,
        RAM_location : "Bangalore",
        RAM_SensorkitID : "RT237-43",    
        RAM_Image :assetFormData.value.uploadimage,
        RAM_Asset_Contact :  assetFormData.value.assetContact
        };
        // params is the custom asset data we get by filling the form that need to be posted to rest api of azure
        console.log(params);
        // to clear the form after submission
        assetFormData.resetForm();
        
        this.assetsService.postAssetData(params)
        .subscribe( 
          (response:any) => {
            console.log('we are in success part',response);
            alert("Data Inserted succesfully");
           
          },
          (error) => {
            console.log('we are in error part',error);
            
          });

    }
  }



}
