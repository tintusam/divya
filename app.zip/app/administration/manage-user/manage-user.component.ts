import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { AssetsService } from '../../services/assets.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-manage-user',
  templateUrl: './manage-user.component.html',
  styleUrls: ['./manage-user.component.css']
})
export class ManageUserComponent implements OnInit {

  constructor(private assetsService: AssetsService,  private router: Router) { }

  @ViewChild('closeAddUserModal', {static:false}) closeAddUserModal;
  @ViewChild('closeEditUserModal', {static:false}) closeEditUserModal;

  public usersList;
  public uid;
  public ufname;
  public ulname;
  public urole;
  public umail;
  public firstname;
  public lastname;
  public role;
  public email;
  public password;
  public addedUser: boolean = false;
  public addedUserError: boolean = false;
  public deletedUser: boolean = false;
  public editedUser: boolean = false;
  public isFullyLoaded:boolean = false;
  public roles:any;
  public userrole:any;
  public usersUnderCustomer:any = [];

  public addUserModel: any = {};

  ngOnInit() {
    if(localStorage.getItem('userRole') == 'Super Admin'){
      this.router.navigate(['administration/manage-customers']);
    }else if(localStorage.getItem('userRole') == 'workforce'){
      this.router.navigate(['dashboard/smart-view']);
    }else{
      this.getUsersList();
    }
  }

  selectRole(e){
    this.userrole = e.target.value;
  }

  setUser(user) {
    this.uid = user.UserID;
    this.ufname = user.FirstName;
    this.ulname = user.LastName;
    this.urole = user.Role;
    this.umail = user.Mail
  }

  getUsersList() {
    let payload = {
      "custId":JSON.parse(localStorage.getItem("customerID"))
    }
    this.assetsService.getUsersList(payload)
      .subscribe(res => {
        this.usersList = res;
        this.usersUnderCustomer = [];
        for (var i=0; i < this.usersList.length; i++) {
          if(this.usersList[i]["Role"] != "Customer" ){
            this.usersUnderCustomer.push(this.usersList[i]);
          }          
        }
        this.isFullyLoaded = true;
      });
  }


  addUser(form:NgForm) {
    // last minute hack to set userrole as supervisor by default 
    // role change is working only on onchange event
    if(this.userrole == undefined){
      this.userrole = "supervisor"
    }
    let params: any = {
      UserID: this.addUserModel.userid,
      FirstName: this.addUserModel.fullname,
      LastName: '',
      custId:JSON.parse(localStorage.getItem("customerID")),
      Role: this.userrole,
      Mail: this.addUserModel.useremail,
      Password: ''
    };
   // console.log(params);

    this.assetsService.addUser(params)
      .subscribe(
        (response: any) => {
          this.addedUser = true;
          this.deletedUser = false;
          this.editedUser = false;
          form.reset();
          this.closeAddUserModal.nativeElement.click();
          this.getUsersList();
        },
        (error) => {
          this.addedUserError = true;
          form.reset();
          this.closeAddUserModal.nativeElement.click();
          this.getUsersList();
        });
  }

  clearUser() {
    this.addedUser = false;
    this.deletedUser = false;
    this.editedUser = false;
  }

  // Method to delete a supervisor or workforce that comes under the customer
  deleteUser() {
    let params: any = {
      UserID: this.uid,
      custId: JSON.parse(localStorage.getItem("customerID"))
    };
    this.assetsService.deleteUser(params)
      .subscribe(
        res => {
          this.deletedUser = true;
          this.getUsersList();
        },
        err => {
          console.log(err);
          this.getUsersList();
        });
  }


  editUser(editData:NgForm) {
    let params: any = {
      UserID: editData.value.edituserid,
      FirstName: editData.value.editusername,
      LastName: '',
      Role: editData.value.edituserrole,
      Mail: editData.value.edituseremail,
      custId:JSON.parse(localStorage.getItem("customerID")),
    };

    //console.log(params);

    this.assetsService.editUser(params)
      .subscribe(
        (response: any) => {
          this.editedUser = true;
          this.deletedUser = false;
          editData.reset();
          this.closeEditUserModal.nativeElement.click();
          this.getUsersList();
        },
        (error) => {
          console.log(error);
          this.getUsersList();
        });
  }
}
