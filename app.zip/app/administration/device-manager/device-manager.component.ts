import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AssetsService } from '../../services/assets.service';
declare var jQuery: any;
@Component({
  selector: 'app-device-manager',
  templateUrl: './device-manager.component.html',
  styleUrls: ['./device-manager.component.css']
})
export class DeviceManagerComponent implements OnInit {

  public sensorKitList;
  public fieldArray: Array<any> = [];
  private newAttribute: any = {};
  public sensorId;
  public parameters;
  public addedDevice: boolean = false;
  public deletedDevice: boolean = false;
  public editedDevice: boolean = false;
  public isFullyLoaded: boolean = false;
  public editArray = [];
  public deviceInfoMessage: string;
  public editSensorMsg:string;
  public editSensorErrorMsg:string;


  // public sensorParameterArray:Array<any> = [];

  constructor(private assetsService: AssetsService, private router: Router) { }

  ngOnInit() {
    if (localStorage.getItem('userRole') == 'Super Admin') {
      this.router.navigate(['administration/manage-customers']);
    } else if (localStorage.getItem('userRole') == 'workforce') {
      this.router.navigate(['dashboard/smart-view']);
    } else {
      this.getSensorKitList();
    }
  }

  // API call to list the devices
  getSensorKitList() {
    let payload = {
      "custId": JSON.parse(localStorage.getItem("customerID"))
    }
    this.assetsService.getSensorKitList(payload)
      .subscribe(res => {
        this.sensorKitList = res;
        this.isFullyLoaded = true;
        if (this.sensorKitList.length == 0) {
          this.deviceInfoMessage = "You have not yet added any devices. You can add new device by clicking the plus icon."
        } else {
          this.deviceInfoMessage = '';
        }
      });
  }

  setData(kit) {
    this.sensorId = kit.RAM_SensorID;
    let params: any = {
      RAM_SensorID: this.sensorId,
      custId: JSON.parse(localStorage.getItem("customerID"))
    }
    //console.log(params);
    this.assetsService.getSensorKitParams(params)
      .subscribe(res => {
        this.fieldArray = res;
        // console.log(res);
        this.editArray = new Array(res.length);    //editArray is initialized       
        this.editArray.fill(false);
        //console.log(this.editArray);
      });
  }

  addFieldValue() {
    this.fieldArray.push(this.newAttribute);
    this.editArray.push(true);       //new value is added to edit array
    this.newAttribute = {};
  }

  deleteFieldValue(index) {
    this.fieldArray.splice(index, 1);
  }

  // function for adding a device
  addDevice() {
    let params: any = {
      RAM_SensorKit_ID: this.sensorId,
      "custId": JSON.parse(localStorage.getItem("customerID")),
      parameters: this.fieldArray
    };
    params = JSON.stringify(params);
    this.assetsService.addDevice(params)
      .subscribe(
        (response: any) => {
          // hide the modal on successfull addition
          jQuery("#addSensorKitModal").modal("hide");
          this.addedDevice = true;
          this.editedDevice = false;
          this.deletedDevice = false;
          this.getSensorKitList();
          this.router.navigate(['administration/device-manager']);
        },
        (error) => {
          console.log('we are in error part' + error);
          alert(error.Message)
          //alert(error);
        });
  }

  // function for editing a device
  editSensorKit(params) {
    params = JSON.stringify(params);
    this.assetsService.editDevice(params)
      .subscribe(
        (response: any) => {
          this.editSensorMsg = "Successfully Updated Sensor Parameter"
          this.addedDevice = false;
          this.editedDevice = true;
          this.deletedDevice = false;
          this.getSensorKitList();
        },
        (error) => {
          this.editSensorErrorMsg = "Remote Servers are not responding. Please try after some time!"
        });
  }



  //function for closing modal box after editing sensor kit
  closeEditModal() {
    jQuery("#editSensorKitModal").modal("hide");
  }

  //function for deleting device parameter
  deleteParameter(index) {
    let params: any = {
      RAM_SensorID: this.sensorId,
      custId: JSON.parse(localStorage.getItem("customerID")),
      RAM_parameter: this.fieldArray[index].RAM_parameter
    }
    this.assetsService.deleteSensorParameter(params)
      .subscribe(
        (res) => {
          console.log(res);
          this.deleteFieldValue(index);

        },
        (err) => {
          console.log(err);
        })
  }

  // function for editing device parameter
  editParameter(index) {
    let params: any = {
      RAM_SensorID: this.sensorId,
      custId: JSON.parse(localStorage.getItem("customerID")),
      RAM_parameter: this.fieldArray[index].RAM_parameter,
      RAM_unit: this.fieldArray[index].RAM_unit,
      RAM_R_MIN: this.fieldArray[index].RAM_R_MIN,
      RAM_R_MAX: this.fieldArray[index].RAM_R_MAX,
      RAM_A_MIN: this.fieldArray[index].RAM_A_MIN,
      RAM_A_MAX: this.fieldArray[index].RAM_A_MAX,
      RAM_G_MIN: this.fieldArray[index].RAM_G_MIN,
      RAM_G_MAX: this.fieldArray[index].RAM_G_MAX
    };
    //console.log(params);
    this.editSensorKit(params);
  }

  // function for deleting device
  deleteSensorKit() {
    let params: any = {
      RAM_SensorID: this.sensorId,
      "custId": JSON.parse(localStorage.getItem("customerID"))
    };
    this.assetsService.deleteSensorKit(params)
      .subscribe(
        res => {
          console.log("The sensor kit was deleted");
          this.addedDevice = false;
          this.editedDevice = false;
          this.deletedDevice = true;
          this.getSensorKitList();

        },
        err => {
          // console.log("We are on error part");
          jQuery("#deleteLinkedSensorKit").modal("show");
          console.log(err);
        });
  }

  clearDevice() {
    this.addedDevice = false;
    this.editedDevice = false;
    this.deletedDevice = false;
    this.editSensorMsg = '';
    this.editSensorErrorMsg = '';
  }

  clearAddSensorKit() {
    jQuery('#addSensorKitModal').find("input,textarea,select").val('').end();
  }

}