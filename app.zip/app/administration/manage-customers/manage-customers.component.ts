import { Component, OnInit } from '@angular/core';
import { ViewChild, ElementRef} from '@angular/core';
import { Router } from '@angular/router';
import { AssetsService } from '../../services/assets.service';
import { NgForm }   from '@angular/forms';
@Component({
  selector: 'app-manage-customers',
  templateUrl: './manage-customers.component.html',
  styleUrls: ['./manage-customers.component.css']
})
export class ManageCustomersComponent implements OnInit {

  @ViewChild('closeAddCustomerModal', {static:false}) closeAddCustomerModal;
  @ViewChild('closeEditCustomerModal',{static:false}) closeEditCustomerModal;
  @ViewChild('closeDeleteCustomerModal',{static:false}) closeDeleteCustomerModal;

  constructor(private assetsService: AssetsService,  public _router :Router) { }
  public usersList;
  public addCustomerModel: any = {};
  public uid;
  public ufname;
  public ulname;
  public urole;
  public umail;
  public firstname;
  public lastname;
  public role;
  public email;
  public uaddress;
  public password;
  public addedUser: boolean = false;
  public addedUserError: boolean = false;
  public deletedUser: boolean = false;
  public editedUser: boolean = false;
  public isFullyLoaded:boolean = false;
  public customerMsg:string;
  public customerID:any;
  public customerName:string;
  public managerEmail:string;
  public managerId:string;
  public managerName:string;
  public address:string;

  ngOnInit() {
    if(localStorage.getItem('userRole') == 'Super Admin'){
      this.getCustomerList();
    }else if(localStorage.getItem('userRole') == 'Customer'){
      this._router.navigate(['administration/manage-user']);
    }else{
      this._router.navigate(['dashboard/smart-view']);
    }   
  }

  setUser(customer) {
   // console.log(customer);
    this.customerID = customer.custId;
    this.customerName = customer.customerName;
    this.managerEmail = customer.managerEmail;
    this.managerName = customer.managerName;
    this.managerId = customer.managerId;
    this.address = customer.address
  }



  // new method to list all customers for admin - Multi tenant api
  getCustomerList() {
    let payload = {
      "custId":JSON.parse(localStorage.getItem("customerID"))
    }
    this.assetsService.getCustomersList(payload)
      .subscribe(res => {
        this.usersList = res;
        this.isFullyLoaded = true;
        if(this.usersList.length == 0){
          this.customerMsg = " No customers to show!"
        }
      },
      err => {
        console.log(err);
      });
  }


  // Method to add customers via manage customers section super admin
  addCustomer(form:NgForm) {
    let params: any = {
      customerName: this.addCustomerModel.customername,
      managerName: this.addCustomerModel.managername,
      managerEmail: this.addCustomerModel.customeremail,
      managerId:this.addCustomerModel.customername+this.addCustomerModel.managerId,
      address: this.addCustomerModel.customeraddress
    };
    this.assetsService.addCustomer(params)
      .subscribe(
        (response: any) => {
          this.addedUser = true;
          this.deletedUser = false;
          this.editedUser = false;
          form.reset();
          this.closeAddCustomerModal.nativeElement.click();
          this.getCustomerList();
        },
        (error) => {
          this.addedUserError = true;
        });
  }

  clearUser() {
    this.addedUser = false;
    this.deletedUser = false;
    this.editedUser = false;
  }

  editSupervisor(editData:NgForm) {
    let params: any = {
      custId: this.customerID,
      customerName: editData.value.editcustomername,
      managerName: editData.value.editmanagername,
      address: editData.value.editcustomeraddress
    };
    //console.log(params);
    this.assetsService.editCustomer(params)
      .subscribe(
        (response: any) => {
          this.editedUser = true;
          this.deletedUser = false;
          editData.reset();
          this.closeEditCustomerModal.nativeElement.click();
          this.getCustomerList();
        },
        (error) => {
          console.log(+error);
        });
  }

  deleteCustomer() {
    let params: any = {
      custId: this.customerID
    };

   // console.log(params)
    this.assetsService.deleteCustomer(params)
      .subscribe(
        res => {
          this.deletedUser = true;
         this.closeDeleteCustomerModal.nativeElement.click();
          this.getCustomerList();
        });
  }



}
