import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import { Config } from "./../config";

@Injectable({
  providedIn: 'root'
})

export class DashboardService {

  constructor(private http: Http) { }

  getAssetDetails(params) {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, method: 'post' });
    return this.http.post(Config.SECOND_API_URL + Config.API_PATH + 'GetUPSParamsCosmos', JSON.stringify(params), options);
  }

  getInsightParameters(params) {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, method: 'post' });
    return this.http.post(Config.SECOND_API_URL + Config.API_PATH + 'GraphParam', JSON.stringify(params), options);
  }

  getAlertsCount(payload) {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, method: 'get' });
    return this.http.post(Config.SECOND_API_URL + Config.API_PATH + 'RamGetAlertCount',payload, options);
  }

  getRAMVoltAlert(params) {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, method: 'get' });
    return this.http.post(Config.SECOND_API_URL + Config.API_PATH + 'GetAlert', JSON.stringify(params), options);
  }

  getAssetsByStatus(params){
    //console.log(params);
    let headers=new Headers({'Content-Type':'application/json'});
    let options = new RequestOptions({ headers: headers, method: 'get' });
    return this.http.post(Config.SECOND_API_URL + Config.API_PATH +'DisplayAssetStatus',JSON.stringify(params),options);

  }

  getAssetsByType(params){
    let headers=new Headers({'Content-Type':'application/json'});
    let options = new RequestOptions({ headers: headers, method: 'get' });
    return this.http.post(Config.SECOND_API_URL + Config.API_PATH +'DisplayAssetType',JSON.stringify(params),options);
  }

  sentAlertData(params) {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, method: 'post' });
    return this.http.post(Config.SECOND_API_URL + Config.API_PATH + 'DisplayAlert', JSON.stringify(params), options);
  }

  getChartData(params) {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, method: 'post' });
    return this.http.post(Config.SECOND_API_URL + Config.API_PATH + 'RAMGraphForInsight', JSON.stringify(params), options);
  }

  getAssetRenderFrequency(payload) {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, method: 'post' });
    //console.log(payload);
    return this.http.post(Config.SECOND_API_URL + Config.API_PATH + 'UpdateFrequency', JSON.stringify(payload), options);
  }

  getParticularDeviceData(params) {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, method: 'post' });
    return this.http.post(Config.SECOND_API_URL + Config.API_PATH + 'getParticularDeviceData', JSON.stringify(params), options);
  }


}
