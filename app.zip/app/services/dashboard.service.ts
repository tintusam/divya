import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Config } from '../config';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  constructor(private http: HttpClient) { }

  uploadPoDetailsCSV(payload) {
    return this.http.post(Config.BASE_API_URL+Config.API_PATH + 'UploadPODetails?code=p3ZpXE2haJuZ1y4VJoG5876G7/BD1vU1OKqEdyaFJb6uxTRaFKVJ1w==', payload)
  }

  listPoDetails(payload){
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+'getPODetails?',payload)
  }

  // getLineItemTracker(payload){
  //   return this.http.post(Config.BASE_API_URL+Config.API_PATH+'getPOMaterialInfo?',payload)
  // }

  getPOMaterialInfo(payload){
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+'getPOMaterialInfo?', payload)
  }

  getSinglePODetails(payload){
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+'getSinglePODetails',payload)
  }

}
