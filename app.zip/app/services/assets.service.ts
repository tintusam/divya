/* Service for managing user level, devices and assets */
import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import { map } from 'rxjs/operators';
import { Config } from "./../config";
@Injectable({
  providedIn: 'root'
})
export class AssetsService {
  public assetId;

  constructor(private http: Http) { }

  // User Management Services Starts here 
  // This includes supervisor and workforce users add, list edit delete

  public getUsersList(payload) {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, method: 'post' });
    return this.http.post(Config.BASE_API_URL + Config.API_PATH + 'DisplayUser', payload, options)
      .pipe(map(res => res.json()));
  }

  public addUser(payload) {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, method: 'post' });
    return this.http.post(Config.SECOND_API_URL + Config.API_PATH + 'CreateUser', payload, options);
  }

  public editUser(payload) {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, method: 'post' });
    return this.http.post(Config.BASE_API_URL + Config.API_PATH + 'editUser', payload, options);
  }

  public deleteUser(payload) {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, method: 'post' });
    return this.http.post(Config.BASE_API_URL + Config.API_PATH + 'deleteUser', payload, options);
  }

  // Customer Management Services Starts here 
  // This includes customer add, list edit delete

  public getCustomersList(payload) {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, method: 'post' });
    return this.http.post(Config.SECOND_API_URL + Config.API_PATH + 'displayCustomer', payload, options)
      .pipe(map(res => res.json()));
  }

  public addCustomer(payload) {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, method: 'post' });
    return this.http.post(Config.SECOND_API_URL + Config.API_PATH + 'addCustomer', payload, options);
  }

  public editCustomer(payload) {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, method: 'post' });
    return this.http.post(Config.SECOND_API_URL + Config.API_PATH + 'editCustomer', payload, options);
  }

  public deleteCustomer(payload) {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, method: 'post' });
    return this.http.post(Config.SECOND_API_URL + Config.API_PATH + 'deleteCustomer', payload, options);
  }


  // Device Management Services Starts here 
  // This includes sensor kit devices add, list edit delete

  public getSensorKitList(payload) {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, method: 'post' });
    return this.http.post(Config.BASE_API_URL + Config.API_PATH + 'DisplaySensorKitID', payload, options)
      .pipe(map(res => res.json()));
  }

  public getSensorKitParams(paylod) {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, method: 'post' });
    return this.http.post(Config.BASE_API_URL + Config.API_PATH + 'DisplaySensorKitParams', paylod, options)
      .pipe(map(res => res.json()));
  }

  public addDevice(payload) {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, method: 'post' });
    return this.http.post(Config.SECOND_API_URL + Config.API_PATH + 'RAMSensorKitCreationSql', payload, options);
  }

  public editDevice(payload) {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, method: 'post' });
    return this.http.post(Config.BASE_API_URL + Config.API_PATH + 'editSensorKit', payload, options);
  }

  public deleteSensorKit(payload) {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, method: 'post' });
    return this.http.post(Config.BASE_API_URL + Config.API_PATH + 'deleteSensorKit', payload, options);
  }

  public deleteSensorParameter(payload) {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, method: 'post' });
    return this.http.post(Config.BASE_API_URL + Config.API_PATH + 'DeleteParameter', JSON.stringify(payload), options);
  }


  // Assets Management Services Starts here 
  // This includes Assets add, list edit delete

  public getDeviceList(payload) {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, method: 'post' });
    return this.http.post(Config.SECOND_API_URL + Config.API_PATH + 'DisplayAsset', payload, options)
      .pipe(map(res => res.json()));
  }

  public postAssetData(payload) {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, method: 'post' });
    return this.http.post(Config.BASE_API_URL + Config.API_PATH + 'CreateAsset', JSON.stringify(payload), options);
  }

  public deleteAsset(payload) {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, method: 'post' });
    return this.http.post(Config.BASE_API_URL + Config.API_PATH + 'DeleteAsset', payload, options);
  }

  public editAssetData(payload) {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, method: 'post' });
    return this.http.post(Config.BASE_API_URL + Config.API_PATH + 'editAsset', JSON.stringify(payload), options);
  }

  // not using this on front end as backend team *Praveen is not able to find it in backend during multi tenancy configuring time // 28th August 2020
  public deleteAlert(payload) {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, method: 'post' });
    return this.http.post(Config.BASE_API_URL + Config.API_PATH + 'DeleteAlert', payload, options);
  }


  // other api calls for set and update locations of asset comes here

  public sendLocation(payload) {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, method: 'post' });
    return this.http.post(Config.BASE_API_URL + Config.API_PATH + 'UpdateLocation', payload, options);
  }

  public getLocationwithCoord(lat, lng) {
    return this.http.get('https://dev.virtualearth.net/REST/v1/Locations/' + lat + ',' + lng + '?o=json&key=Avh43rwIxMpHSkLOHeo7MeaFNwaQgk8BsehjzGxYxscXNvi6VH_VlUnX_MHAyFzw')
      .pipe(map(res => res.json()));
  }

}
