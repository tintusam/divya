import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MapService {
  public loadPromise: Promise<void>;
   public loadAPI: Promise<any>;
   geofence:any[];

   private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type':  'application/json'
    })
};

  constructor( private http: HttpClient ) { }
  
  public load(): Promise<void> {
    if (this.loadPromise) {
        return this.loadPromise;
    }

    const script = document.createElement('script');
    script.type = 'text/javascript';
    script.async = true;
    script.defer = true;

    const mapsCallback = 'mapOnInit';

    // script.src = 'https://www.bing.com/api/maps/mapcontrol?callback=mapOnInit&key=Ali1WlBXVFx_qNGje1nFcDxZlOVpMWSEkeMlbkzw9tLC3hxWPFStj6LIudftObDv&s=1';

    // New API Key for Asset Radar App

    script.src = 'https://www.bing.com/api/maps/mapcontrol?callback=mapOnInit&key=Av9GBHwc3Q8s5t2rFtD8vbSjY2h0KjXl3vwHbM1IDfKz1jJPCplJukCsHFafHefK&s=1';

    this.loadPromise = new Promise<
        void
        >((resolve: Function, reject: Function) => {
            window[mapsCallback] = () => {
              console.log("map function resolved");

                resolve();
            };
            script.onerror = (error: Event) => {
                console.error('maps script error' + error);
                reject(error);
            };
        });

    document.body.appendChild(script);

    return this.loadPromise;
}

private search = new BehaviorSubject('AQI');
GetSearchText = this.search.asObservable();

setSearchText(message: any) {
  this.search.next(message);

}



}