import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Config } from '../config';
@Injectable({
  providedIn: 'root'
})
export class VendorService {

  constructor(private http: HttpClient) { }

  uploadVendorDetailsCSV(payload) {
    return this.http.post(Config.BASE_API_URL+Config.API_PATH + 'uploadVendorDetails', payload, { headers: {'Ocp-Apim-Subscription-Key':'279c5064b6bf4f839f19556ced8b57b5', 'Ocp-Apim-Trace':'true'}})
  }

  getVendorList(){
    return this.http.get(Config.BASE_API_URL+Config.API_PATH + 'getVendorsList?code=f2c4omC7vfbHgIz13CDk14GInf9Eh5zmCZIaMC5oVWpSxVmhJOyZUg==', { headers: {'Ocp-Apim-Subscription-Key':'279c5064b6bf4f839f19556ced8b57b5', 'Ocp-Apim-Trace':'true'}})
  }

  getVendorInfo(payload){
    return this.http.post(Config.BASE_API_URL+Config.API_PATH + 'getSingleVendorInfo', payload, { headers: {'Ocp-Apim-Subscription-Key':'279c5064b6bf4f839f19556ced8b57b5', 'Ocp-Apim-Trace':'true'}})
  }

}
