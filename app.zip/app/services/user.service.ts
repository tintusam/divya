import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import { Config } from "./../config";
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class UserService {

  private loginSource = new BehaviorSubject(false);
  getLogin = this.loginSource.asObservable();

  constructor(private http: Http) { }

  // service to fetch the login response after authentication from backend
  sendLoginData(params) {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, method: 'post' });
    return this.http.post(Config.SECOND_API_URL + Config.API_PATH + 'GetLoginResponse', JSON.stringify(params), options);
  }

  // emits boolean subject on login
  setLogin(log: boolean) {
    this.loginSource.next(log);
  }

  // authenticate function to check if the user exists in local storage
  isAuthenticated() {
    if (localStorage.getItem("Login")) {
      return true;
    }
    else {
      return false;
    }
  }

  onSetPassword(payload){
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, method: 'post' });
    return this.http.post(Config.SECOND_API_URL + Config.API_PATH + 'ChangePassword', JSON.stringify(payload), options);
  }

}
