import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Config } from '../config';

@Injectable({
  providedIn: 'root'
})
export class TrackerService {

  constructor(private http: HttpClient) { }

  getLineItemTracker(payload){
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+'getPOMaterialInfo?',payload)
  }

}
