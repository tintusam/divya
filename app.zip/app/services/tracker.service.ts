import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Config } from '../config';

@Injectable({
  providedIn: 'root'
})
export class TrackerService {

  constructor(private http: HttpClient) { }

  getLineItemTracker(payload){
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+'getPOMaterialInfo?',payload, { headers: {'Ocp-Apim-Subscription-Key':'279c5064b6bf4f839f19556ced8b57b5', 'Ocp-Apim-Trace':'true'}})
  }

}
