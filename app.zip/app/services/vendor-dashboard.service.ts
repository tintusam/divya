import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Config } from '../config';

@Injectable({
  providedIn: 'root'
})
export class VendorDashboardService {

  constructor(private http: HttpClient) { }

  listPoDetails(payload){
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+'getPODetails?',payload)
  }

  poSummaryDetails(payload){
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+'getSinglePODetails',payload)
  }

  getPOItemDetails(payload){
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+'getPOMaterialInfo?',payload)
  }

  listProcess(payload){
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+'listProductSteps',payload)
  }

  updateCurrentStepByVendor(payload){
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+'updateCurrentStepbyVendor?code=CWCaKr/pLqzzGIkxyrSwBLZ0JvMf6lQ5yMsHZM/68k9ss1WsIc2PuQ==',payload)
  }
}
