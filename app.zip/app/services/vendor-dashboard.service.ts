import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Config } from '../config';

@Injectable({
  providedIn: 'root'
})
export class VendorDashboardService {

  constructor(private http: HttpClient) { }

  listPoDetails(payload){
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+'getPODetails?',payload, { headers: {'Ocp-Apim-Subscription-Key':'279c5064b6bf4f839f19556ced8b57b5', 'Ocp-Apim-Trace':'true'}})
  }

  poSummaryDetails(payload){
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+'getSinglePODetails',payload, { headers: {'Ocp-Apim-Subscription-Key':'279c5064b6bf4f839f19556ced8b57b5', 'Ocp-Apim-Trace':'true'}})
  }

  getPOItemDetails(payload){
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+'getPOMaterialInfo?',payload, { headers: {'Ocp-Apim-Subscription-Key':'279c5064b6bf4f839f19556ced8b57b5', 'Ocp-Apim-Trace':'true'}})
  }

  listProcess(payload){
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+'listProductSteps',payload, { headers: {'Ocp-Apim-Subscription-Key':'279c5064b6bf4f839f19556ced8b57b5', 'Ocp-Apim-Trace':'true'}})
  }

  updateCurrentStepByVendor(payload){
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+'updateCurrentStepbyVendor?code=CWCaKr/pLqzzGIkxyrSwBLZ0JvMf6lQ5yMsHZM/68k9ss1WsIc2PuQ==',payload, { headers: {'Ocp-Apim-Subscription-Key':'279c5064b6bf4f839f19556ced8b57b5', 'Ocp-Apim-Trace':'true'}})
  }

  updateShipment(payload){
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+'updateShipmentID?',payload, { headers: {'Ocp-Apim-Subscription-Key':'279c5064b6bf4f839f19556ced8b57b5', 'Ocp-Apim-Trace':'true'}})
  }

}
