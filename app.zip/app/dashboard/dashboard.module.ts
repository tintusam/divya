import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AssetComponent } from './asset/asset.component';
import { AlertsComponent } from './alerts/alerts.component';
import { ReportsComponent } from './reports/reports.component';
import { SettingsComponent } from './settings/settings.component';
import { SmartViewComponent } from './smart-view/smart-view.component';
import {DashboardRoutingModule} from './dashboard-routing.module'
import { DashboardSidebarComponent } from './dashboard-sidebar/dashboard-sidebar.component';
import { ServiceSidebarComponent } from './smart-view/service-sidebar/service-sidebar.component';
import {DynamicfieldPipe} from './../pipes/dynamicfield.pipe';
import { FormsModule } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { SubscribeComponent } from './subscribe/subscribe.component'

@NgModule({
  imports: [
    CommonModule,
    DashboardRoutingModule,
    BrowserAnimationsModule,
    BsDatepickerModule.forRoot(),
    FormsModule
  ],
  providers:[DatePipe],
  declarations: [AssetComponent, AlertsComponent, DynamicfieldPipe, ReportsComponent, SettingsComponent, SmartViewComponent, DashboardSidebarComponent, ServiceSidebarComponent, SubscribeComponent],
  exports:[SmartViewComponent, DynamicfieldPipe]
})
export class DashboardModule { }
