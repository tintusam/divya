import { Component, OnInit, OnChanges, DoCheck } from '@angular/core';
import { Router} from '@angular/router';
import { AuthenticateService } from 'src/app/services/authenticate.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit, DoCheck {

  public showMenu:boolean = false;
  public loginStatus:any;
  public fullName:any;
  public userRole:any;
  constructor(private _router:Router, private _auth:AuthenticateService) { }

  ngOnInit(): void {
  }

  ngDoCheck(){
    this.loginStatus = sessionStorage.getItem("Login");
    this.fullName = localStorage.getItem("fullName");
    this.userRole = localStorage.getItem("userRole");
  }

  toggleActionMenu(){
    this.showMenu = !this.showMenu;
  }

  logout(){
    this.showMenu = false;
    localStorage.clear();
    sessionStorage.clear();
    this._router.navigateByUrl('login');
  }

}
