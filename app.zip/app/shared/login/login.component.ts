import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { NgForm } from '@angular/forms';
import { AuthenticateService } from 'src/app/services/authenticate.service';
import Swal from 'sweetalert2';

import * as CryptoJS from 'crypto-js';
import { sha256 } from 'js-sha256'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public isLoggedIn:boolean = true;
  encryptedPwd: any;

  constructor(private _router:Router, private _auth:AuthenticateService) { }

  ngOnInit(): void {
  }

  loginModel: any = {};
  AuthResponse: any;
  email = '';
  password = '';
  authMsg:string ='';

  encrypt(msg, pass) {
    // random salt for derivation
    var keySize = 256;
    var salt = CryptoJS.lib.WordArray.random(16);
    console.log("salt: "+salt);
    // well known algorithm to generate key
    var key = CryptoJS.PBKDF2(pass, salt, {
      keySize: keySize / 32,
      iterations: 100
    });
    console.log("key: "+key);
    // random IV
    var iv = CryptoJS.lib.WordArray.random(128 / 8);
    console.log("iv: "+iv);
    // specify everything explicitly
    var encrypted = CryptoJS.AES.encrypt(msg, key, {
      iv: iv,
      padding: CryptoJS.pad.NoPadding,
      mode: CryptoJS.mode.CBC
    });
    // CryptoJS.createcipheriv()
    // combine everything together in base64 string
    var result = CryptoJS.enc.Base64.stringify(salt.concat(iv).concat(encrypted.ciphertext));
    return result;
  }

  onSubmit(loginData: NgForm){

    // this.encryptedPwd=sha256(loginData.value.password);

        // this.encryptedPwd=this.encrypt(loginData.value.password,'SIWW673BX081TD34')

        var key = CryptoJS.enc.Utf8.parse('SIWW673BX081TD34');
        var iv = CryptoJS.enc.Utf8.parse('SIWW673BX081TD34');

    // this.encryptedPwd = CryptoJS.AES.encrypt(loginData.value.password.trim(), 'SIWW673BX081TD34').toString();
    
    // this.encryptedPwd=CryptoJS.AES.encrypt(
    //   JSON.stringify(loginData.value.password.trim()), 'HTR59234frTg-046ERt49', {
    //     keySize: 16,
    //     iv: 'HTR59234frTg-046ERt49',
    //     mode: CryptoJS.mode.ECB,
    //     padding: CryptoJS.pad.Pkcs7
    //   }).toString();

    var encrypted = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(JSON.stringify(loginData.value.password)), key, {
      keySize: 128 / 8,
      iv: iv,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7
    }).toString();
    
    // console.log("pwd: "+loginData.value.password.trim());
    // console.log("encrypted: ",encrypted);
    let payload: any = {
      user: loginData.value.email,
      password: encrypted
    };
    console.log(payload);
    this.isLoggedIn = false;
    this._auth.authenticateUser(payload).subscribe(
      res => {
        this.AuthResponse = res;
        if(this.AuthResponse.WasSuccessful){
          this.isLoggedIn = true;
          sessionStorage.setItem("Login", "1");
          localStorage.setItem("fullName", this.AuthResponse.User.FirstName + " "+ this.AuthResponse.User.LastName);
          localStorage.setItem("userEmail", this.AuthResponse.User.Login);
          localStorage.setItem("userRole", this.AuthResponse.User.userType);
          localStorage.setItem("vendorCode", this.AuthResponse.User.vendorCode);
          if(this.AuthResponse.User.userType == 'Seller'){
            this._router.navigateByUrl('my-dashboard');
          }else{
            this._router.navigateByUrl('dashboard');
          }
        }
        else{
          this.email = '';
          this.password = ''; 
          this.isLoggedIn = true;
          this.authMsg = "Invalid Username or Password";
          Swal.fire({
            icon: 'error',
            text: this.authMsg,
            showConfirmButton: true,
            confirmButtonColor:'#cd0000'
          })
        }

        console.log(this.AuthResponse);
        

      },
      err => {
        if(err.status == 500){
          Swal.fire({
            position: 'top-end',
            icon: 'error',
            text: 'Servers not responding!',
            showConfirmButton: false,
            timer: 1500
          })
        }else if(err.status == 404){
          Swal.fire({
            position: 'top-end',
            icon: 'error',
            text: 'Not Found!',
            showConfirmButton: false,
            timer: 1500
          })
        }
        console.log(err);
      })

      // this.AuthResponse = {
      //   Message: "User authenticated",
      //   U_Fullname:"Divya Gopinath",
      //   U_UserType:"Admin",
      //   U_VendorCode:"123456"
      // }

    

      //   if (this.AuthResponse.Message === 'User authenticated') {
      //     sessionStorage.setItem("Login", "1");
      //     sessionStorage.setItem("fullName", this.AuthResponse.U_Fullname);
      //     sessionStorage.setItem("userRole", this.AuthResponse.U_UserType);
      //     sessionStorage.setItem("vendorCode", this.AuthResponse.U_VendorCode);
      //   this._auth.setLogin(true);
      //   this._router.navigateByUrl('management');
      // }else{
      //   this.email = '';
      //   this.password = ''; 
      //   this._router.navigateByUrl('');    
      // }

    
  }

}
