import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { NgForm } from '@angular/forms';
import { AuthenticateService } from 'src/app/services/authenticate.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public isLoggedIn:boolean = true;

  constructor(private _router:Router, private _auth:AuthenticateService) { }

  ngOnInit(): void {
  }

  loginModel: any = {};
  AuthResponse: any;
  email = '';
  password = '';
  authMsg:string ='';

  onSubmit(loginData: NgForm){
    let payload: any = {
      user: loginData.value.email,
      password: loginData.value.password
    };
    this.isLoggedIn = false;
    this._auth.authenticateUser(payload).subscribe(
      res => {
        this.AuthResponse = res;
        if(this.AuthResponse.WasSuccessful){
          this.isLoggedIn = true;
          sessionStorage.setItem("Login", "1");
          localStorage.setItem("fullName", this.AuthResponse.User.FirstName + " "+ this.AuthResponse.User.LastName);
          localStorage.setItem("userEmail", this.AuthResponse.User.Login);
          localStorage.setItem("userRole", this.AuthResponse.User.userType);
          localStorage.setItem("vendorCode", this.AuthResponse.User.vendorCode);
          if(this.AuthResponse.User.userType == 'Seller'){
            this._router.navigateByUrl('my-dashboard');
          }else{
            this._router.navigateByUrl('management');
          }
        }
        else{
          this.email = '';
          this.password = ''; 
          this.isLoggedIn = true;
          this.authMsg = "Invalid Username or Password";
          Swal.fire({
            icon: 'error',
            text: this.authMsg,
            showConfirmButton: false,
            timer: 1500
          })
        }

        console.log(this.AuthResponse);
        

      },
      err => {
        if(err.status == 500){
          Swal.fire({
            position: 'top-end',
            icon: 'error',
            text: 'Servers not responding!',
            showConfirmButton: false,
            timer: 1500
          })
        }else if(err.status == 404){
          Swal.fire({
            position: 'top-end',
            icon: 'error',
            text: 'Not Found!',
            showConfirmButton: false,
            timer: 1500
          })
        }
        console.log(err);
      })

      // this.AuthResponse = {
      //   Message: "User authenticated",
      //   U_Fullname:"Divya Gopinath",
      //   U_UserType:"Admin",
      //   U_VendorCode:"123456"
      // }

    

      //   if (this.AuthResponse.Message === 'User authenticated') {
      //     sessionStorage.setItem("Login", "1");
      //     sessionStorage.setItem("fullName", this.AuthResponse.U_Fullname);
      //     sessionStorage.setItem("userRole", this.AuthResponse.U_UserType);
      //     sessionStorage.setItem("vendorCode", this.AuthResponse.U_VendorCode);
      //   this._auth.setLogin(true);
      //   this._router.navigateByUrl('management');
      // }else{
      //   this.email = '';
      //   this.password = ''; 
      //   this._router.navigateByUrl('');    
      // }

    
  }

}
