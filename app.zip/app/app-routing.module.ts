import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TrackerLandingPageComponent } from './Components/Tracker-Dashboard/tracker-landing-page/tracker-landing-page.component';
import { ManagerPortalLandingPageComponent } from './Components/Manager-Portal/manager-portal-landing-page/manager-portal-landing-page.component';
import { RegionDashboardComponent } from './Components/Tracker-Dashboard/region-dashboard/region-dashboard.component';
import { StoreDashboardComponent } from './Components/Tracker-Dashboard/store-dashboard/store-dashboard.component';
import { AssociateDashboardComponent } from './Components/Tracker-Dashboard/associate-dashboard/associate-dashboard.component';
import { SiteManagementComponent } from './Components/Manager-Portal/site-management/site-management.component';
import { AddSiteComponent } from './Components/Manager-Portal/site-management/add-site/add-site.component';
import { LoginComponent } from './Components/Common-Shared/login/login.component';
import { NotificationsComponent } from './Components/Common-Shared/notifications/notifications.component';
import { ContactTracingReportComponent } from './Components/Reports/contact-tracing-report/contact-tracing-report.component';
import { ReportLandingPageComponent } from './Components/Reports/report-landing-page/report-landing-page.component';
import { TemperatureReportComponent } from './Components/Reports/temperature-report/temperature-report.component';
import { HLAlertsReportComponent } from './Components/Reports/hl-alerts-report/hl-alerts-report.component';
import { HLSDReportComponent } from './Components/Reports/hl-sd-report/hl-sd-report.component';
import { HLQuarantineReportComponent } from './Components/Reports/hl-quarantine-report/hl-quarantine-report.component';
import { ChangePasswordComponent } from './Components/Common-Shared/change-password/change-password.component';
import { UserManagementComponent } from './Components/user-management/user-management.component';
import { SDACumulativeReportComponent } from './Components/Reports/sda-cumulative-report/sda-cumulative-report.component';
import { TNTDashboardComponent} from './Components/tnt-dashboard/tnt-dashboard.component';

import { AuthGuard } from './Services/auth.guard'
const routes: Routes = [
  {
    path: '',
    component: LoginComponent
  },
  {
    path: 'notifications',
    component: NotificationsComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'change-password',
    component: ChangePasswordComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'tracker',
    component: TrackerLandingPageComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'tnt-dashboard',
    component: TNTDashboardComponent,
    canActivate: [AuthGuard]
  },  
  {
    path: 'managers-portal',
    component: ManagerPortalLandingPageComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: 'site-management',
        component: SiteManagementComponent,
        canActivate: [AuthGuard],
        children: [
          {
            path: 'add-site',
            component: AddSiteComponent,
            canActivate: [AuthGuard],
          }
        ]

      },
      {
        path: 'user-management',
        component: UserManagementComponent,
        canActivate: [AuthGuard]
      }
    ]

  },
  {
    path: 'reports',
    component: ReportLandingPageComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: 'contact-tracing-report',
        component: ContactTracingReportComponent,
        canActivate: [AuthGuard]
      },
      {
        path: 'temperature-report',
        component: TemperatureReportComponent,
        canActivate: [AuthGuard]
      },
      {
        path: 'hl-temperature-report',
        component: HLAlertsReportComponent,
        canActivate: [AuthGuard]
      },
      {
        path: 'hl-sd-report',
        component: HLSDReportComponent,
        canActivate: [AuthGuard]
      },
      {
        path: 'hl-quarantine-report',
        component: HLQuarantineReportComponent,
        canActivate: [AuthGuard]
      },
      {
        path: 'cumulative-SDA-report',
        component: SDACumulativeReportComponent,
        canActivate: [AuthGuard]
      }
    ]

  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
