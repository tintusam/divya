import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NotFoundComponent } from './shared/not-found/not-found.component';
import { LoginComponent } from './shared/login/login.component';
import { ManagementPortalComponent } from './admin/management-portal/management-portal.component';
import { PoDashboardComponent } from './admin/po-dashboard/po-dashboard.component';
import { PoItemComponent } from './admin/po-dashboard/po-item/po-item.component';
import { ItemManagementComponent } from './admin/management-portal/item-management/item-management.component';
import { VendorManagementComponent } from './admin/management-portal/vendor-management/vendor-management.component';
import { ItemTrackerComponent } from './admin/item-tracker/item-tracker.component';
import { VendorDashboardComponent } from './vendor/vendor-dashboard/vendor-dashboard.component';
import { PoSummaryComponent } from './vendor/vendor-dashboard/po-summary/po-summary.component';
import { AuthGuard } from './services/auth.guard';

const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'login', component: LoginComponent },
  { path: '',   redirectTo: '/LoginComponent',pathMatch: 'full'},
  { path:'management', component:ManagementPortalComponent,canActivate: [AuthGuard]},
  { path:'management/vendors', component:VendorManagementComponent,canActivate: [AuthGuard]},
  { path:'management/products', component:ItemManagementComponent,canActivate: [AuthGuard]},
  { path:'dashboard', component:PoDashboardComponent,canActivate: [AuthGuard]},
  { path:'dashboard/po/:poNumber', component:PoItemComponent,canActivate: [AuthGuard]},
  { path:'tracker', component:ItemTrackerComponent,canActivate: [AuthGuard]},
  { path:'my-dashboard', component:VendorDashboardComponent,canActivate: [AuthGuard]}, 
  { path:'my-dashboard/po/:poNumber', component:PoSummaryComponent,canActivate: [AuthGuard]},  
  { path: '**', component: NotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
