import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service';
import { Router  , ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {

  constructor(private _route:ActivatedRoute,  private _user:UserService) { }
  setPasswordModel:any ={};
  validationMsg:any;
  successMessage:any;
  redirectToLogin:boolean = false;

  ngOnInit() {
  }

  // to change password
  onSetPassword(setpassword: NgForm){
    if(setpassword.value.confirmPassword != setpassword.value.newpassword){
      this.validationMsg = "New Password and Confirm Password should match!";
    }else{
      var payload: any = {
        'Email':localStorage.getItem("userEmail"),
        'OldPassword': setpassword.value.currentpassword,
        'Password': setpassword.value.newpassword
      };
    }
    this._user.onSetPassword(payload).subscribe(res => {
      let body:string = JSON.parse(res['_body']);
        this.successMessage = body
        this.successMessage = this.successMessage.Message;
        this.redirectToLogin = true;
    },
    err => {
        if (err.status == 500){
          this.successMessage = "Remote servers are not responding at the moment. Please try after sometime.";
          this.redirectToLogin = false;
        }
        if (err.status == 400){
          this.successMessage = "User already registered!";
          this.redirectToLogin = false;
        }
    });
  }


}
