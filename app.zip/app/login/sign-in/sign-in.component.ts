import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserService } from '../../services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.css']
})

export class SignInComponent implements OnInit {

  constructor(private userService: UserService, private router: Router) { }

  ngOnInit() {
  }
  // the loginModel is set for front end validation part
  loginModel: any = {};
  public responseData: any;
  public login: boolean;
  public errorResponse: string;
  public invalidlogin: boolean = false;

  // function that executes on submitting the login form
  onSubmit(loginData: NgForm) {
    if (loginData.valid) {
      // creating the request payload that needs to be passed to authentication api
      let params: any = {
        'Mail': loginData.value.email,
        'Password': loginData.value.password
      };
      this.userService.sendLoginData(params).subscribe(
        (res) => {
          this.responseData = JSON.parse(res['_body']);
          if (this.responseData.Status == "OK") {
            this.login = true;
            sessionStorage.setItem("email", loginData.value.email);
            sessionStorage.setItem("password", loginData.value.password);
            localStorage.setItem("customerID",this.responseData.custId)
            localStorage.setItem("Login", "1");
            localStorage.setItem("userID", this.responseData.UserID);
            localStorage.setItem("userName", this.responseData.FirstName + " " + this.responseData.LastName);
            localStorage.setItem("userEmail", this.responseData.Mail);
            localStorage.setItem("userRole", this.responseData.Role);
            this.userService.setLogin(true);
            this.router.navigate(['/dashboard/smart-view']);
          } else {
            this.login = false;
            this.invalidlogin = true;
            this.errorResponse = "Please Enter Valid Credentials";
            this.router.navigate(['/sign-in']);
          }
        },
        (error) => {
          error = JSON.parse(error['_body']);
          this.login = false;
          this.invalidlogin = true;
          this.errorResponse = "Unable to reach the servers at the moment";
          this.router.navigate(['/sign-in']);
          loginData.resetForm();
        }
      );
    }
  }

  // function for logging out and clearing the local storage items
  logout() {
    localStorage.removeItem("Login");
    localStorage.removeItem("userID");
    localStorage.removeItem("userName");
    localStorage.removeItem("userEmail");
    localStorage.removeItem("userRole");
    sessionStorage.clear();
    this.userService.setLogin(false);
    this.router.navigate(['/sign-in']);
  }

}
