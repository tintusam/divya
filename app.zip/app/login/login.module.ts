import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { SignInComponent } from './sign-in/sign-in.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
//import {UserService} from './../services/user.service';
import { LoginRoutingModule } from './login-routing.module';
import { ChangePasswordComponent } from './change-password/change-password.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule,
    LoginRoutingModule
  ],
  declarations: [SignInComponent, SignUpComponent, ForgetPasswordComponent, ChangePasswordComponent],
 // providers:[UserService],
  exports:[SignInComponent,SignUpComponent,ForgetPasswordComponent]
  
})
export class LoginModule { }
