import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {AuthGuard} from './../services/auth.service'
import { SignInComponent } from './sign-in/sign-in.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
import { ChangePasswordComponent } from './change-password/change-password.component'

const loginRoutes: Routes = [
    { path: '',  component: SignInComponent },
    { path: 'sign-in',  component: SignInComponent },
    { path: 'sign-up', component: SignUpComponent },
    { path: 'forgot-password', component: ForgetPasswordComponent },
    { path: 'change-password', component: ChangePasswordComponent,canActivate:[AuthGuard] }
  ];

@NgModule({
  imports: [
    RouterModule.forChild(loginRoutes)
  ],
  exports:[RouterModule]
})
export class LoginRoutingModule { }
