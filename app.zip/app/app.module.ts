import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';


// import your feature modules here so you can add it to the imports array below
import { AdministrationModule } from './administration/administration.module';
import { DashboardModule } from './dashboard/dashboard.module';
import { LoginModule } from './login/login.module';
import {AppRoutingModule} from './app-routing.module';

import { UserService } from './services/user.service';
import { DashboardService } from './services/dashboard.service';

import { AppComponent } from './app.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { HeaderComponent } from './layout/header/header.component';
import { SearchboxComponent } from './layout/header/searchbox/searchbox.component';
import { MaincontentComponent } from './layout/maincontent/maincontent.component';


@NgModule({
  imports: [
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    HttpModule,
    AdministrationModule,
    DashboardModule,
    LoginModule,
    AppRoutingModule
  ],
  declarations: [
    AppComponent,
    NotFoundComponent,
    HeaderComponent,
    SearchboxComponent,
    MaincontentComponent,
    
  ],
  providers:[UserService, DashboardService],
  bootstrap: [AppComponent]
})

export class AppModule { }