import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { MatExpansionModule } from "@angular/material/expansion";
import { MatDatepickerModule } from '@angular/material/datepicker';
import { NgxHeatMapModule } from 'ngx-heatmap';
import { AppComponent } from './app.component';
import { NavbarComponent } from './Components/Common-Shared/navbar/navbar.component';
import { LoginComponent } from './Components/Common-Shared/login/login.component';
import { TrackerLandingPageComponent } from './Components/Tracker-Dashboard/tracker-landing-page/tracker-landing-page.component';
import { ManagerPortalLandingPageComponent } from './Components/Manager-Portal/manager-portal-landing-page/manager-portal-landing-page.component';
import { RegionDashboardComponent } from './Components/Tracker-Dashboard/region-dashboard/region-dashboard.component';
import { StoreDashboardComponent } from './Components/Tracker-Dashboard/store-dashboard/store-dashboard.component';
import { AssociateDashboardComponent } from './Components/Tracker-Dashboard/associate-dashboard/associate-dashboard.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SiteManagementComponent } from './Components/Manager-Portal/site-management/site-management.component';
import { AddSiteComponent } from './Components/Manager-Portal/site-management/add-site/add-site.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { AppService } from './Services/app.service';
import { AssociatesComponent } from './Components/Manager-Portal/site-management/associates/associates.component';
import { BLOB_STORAGE_TOKEN, IAzureStorage } from './Components/Manager-Portal/site-management/azure-storage/azureStorage';
import { BlobStorageService } from './Components/Manager-Portal/site-management/azure-storage/blob-storage.service';
import { UserTemperatureTabComponent } from './Components/Tracker-Dashboard/user-temperature-tab/user-temperature-tab.component';
declare var AzureStorage: IAzureStorage;
// import { ChartistModule } from 'ng-chartist';
import { UserSocialDistancingTabComponent } from './Components/Tracker-Dashboard/user-social-distancing-tab/user-social-distancing-tab.component';
import { NotificationsComponent } from './Components/Common-Shared/notifications/notifications.component';
import { ChartistTestComponent } from './Components/Tracker-Dashboard/chartist-test/chartist-test.component';
import { ChartistModule } from 'ng-chartist';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatNativeDateModule, MatInputModule } from '@angular/material'
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { NgxPrintModule } from 'ngx-print';
import { MatMenuModule } from '@angular/material/menu';
import { TruncatePipeModule } from 'src/app/custom-pipes/truncatepipe.module';
import { SearchPipeModule } from 'src/app/custom-pipes/searchpipe.module';
import { SearchAccountPipeModule } from 'src/app/custom-pipes/searchAccountpipe.module';
import { SearchGeofencePipeModule } from 'src/app/custom-pipes/searchGeofencepipe.module';
// PrimeNG Components
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';
import { ContactTracingReportComponent } from './Components/Reports/contact-tracing-report/contact-tracing-report.component';
import { ReportLandingPageComponent } from './Components/Reports/report-landing-page/report-landing-page.component';
import { TemperatureReportComponent } from './Components/Reports/temperature-report/temperature-report.component';
import { NgChartjsModule } from 'ng-chartjs';
import * as ChartAnnotation from 'chartjs-plugin-annotation';
const chartAnnotation = ChartAnnotation;
import { ChartsModule } from 'ng2-charts';
import { HLAlertsReportComponent } from './Components/Reports/hl-alerts-report/hl-alerts-report.component';
import { HLSDReportComponent } from './Components/Reports/hl-sd-report/hl-sd-report.component';
import { HLQuarantineReportComponent } from './Components/Reports/hl-quarantine-report/hl-quarantine-report.component';
import { AddManagerComponent } from './Components/Manager-Portal/site-management/add-manager/add-manager.component';
import { ChangePasswordComponent } from './Components/Common-Shared/change-password/change-password.component';
import { UserManagementComponent } from './Components/user-management/user-management.component';
import { DeviceManagementComponent } from './Components/Manager-Portal/site-management/device-management/device-management.component';
import { SDACumulativeReportComponent } from './Components/Reports/sda-cumulative-report/sda-cumulative-report.component';
import { MatRadioModule } from '@angular/material/radio';
import { MatIconModule } from '@angular/material';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { DeviceConfigComponent } from './Components/Manager-Portal/site-management/device-config/device-config.component';
import { MatDialogModule } from '@angular/material/dialog';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { NormalizedContactTracingComponent } from './Components/Tracker-Dashboard/normalized-contact-tracing/normalized-contact-tracing.component';
import { FacilitiesManagementComponent } from './Components/Manager-Portal/site-management/facilities-management/facilities-management.component';
import { AssetService } from './Services/asset.service';
import { TNTDashboardComponent } from './Components/tnt-dashboard/tnt-dashboard.component';
@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    LoginComponent,
    TrackerLandingPageComponent,
    ManagerPortalLandingPageComponent,
    RegionDashboardComponent,
    TruncatePipeModule,
    SearchPipeModule,
    SearchAccountPipeModule,
    SearchGeofencePipeModule,
    StoreDashboardComponent,
    AssociateDashboardComponent,
    SiteManagementComponent,
    AddSiteComponent,
    AssociatesComponent,
    UserTemperatureTabComponent,
    UserSocialDistancingTabComponent,
    NotificationsComponent,
    ChartistTestComponent,
    ContactTracingReportComponent,
    ReportLandingPageComponent,
    TemperatureReportComponent,
    HLAlertsReportComponent,
    HLSDReportComponent,
    HLQuarantineReportComponent,
    AddManagerComponent,
    ChangePasswordComponent,
    UserManagementComponent,
    DeviceManagementComponent,
    SDACumulativeReportComponent,
    DeviceConfigComponent,
    NormalizedContactTracingComponent,
    FacilitiesManagementComponent,
    TNTDashboardComponent
  ],
  imports: [
    BrowserModule,
    FormsModule, ReactiveFormsModule, HttpModule,  HttpClientModule,
    AppRoutingModule,
    MatExpansionModule,
    MatIconModule,
    MatDialogModule,
    MatFormFieldModule,
    MatRadioModule,
    MatCheckboxModule,
    MatSlideToggleModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatMenuModule,
    ToastModule,
    MatInputModule,
    ChartistModule,
    ChartsModule,
    NgxHeatMapModule,
    Ng2SearchPipeModule,
    BrowserAnimationsModule,
    NgxPrintModule,
    BsDatepickerModule.forRoot(),
    NgChartjsModule.registerPlugin([chartAnnotation]),
  ],
  providers: [
    AssetService,
    AppService,
    BlobStorageService,
    MessageService,
    {
      provide: BLOB_STORAGE_TOKEN,
      useValue: AzureStorage.Blob
    },],
  bootstrap: [AppComponent]
})
export class AppModule { }
