import { Component, OnInit } from '@angular/core';
import { AppService } from '../../Services/app.service'
@Component({
  selector: 'app-user-management',
  templateUrl: './user-management.component.html',
  styleUrls: ['./user-management.component.scss']
})
export class UserManagementComponent implements OnInit {
  SiteList: any;
  AssociateList: any;
  selectedAssociates: any;
  SelectedStore = 'Select Site/Store'
  constructor(private app: AppService) {
    this.SiteList = [];
    this.AssociateList = [];
    this.selectedAssociates = [];
    this.app.GetAllStore().subscribe(res => {
      // console.log(res);
      this.SiteList = res
    })
  }

  ngOnInit() {
  }

  getAssociateList(SiteId) {
    let payload = {
      "Sid": SiteId
    }
    this.app.getAssociateList(payload).subscribe(res => {
      this.AssociateList = res
    })
  }

  AddToSelectedList(item) {
    this.selectedAssociates.push(item)
    // console.log(item)
  }

}
