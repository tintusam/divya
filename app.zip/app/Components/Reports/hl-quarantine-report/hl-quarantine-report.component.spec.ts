import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HLQuarantineReportComponent } from './hl-quarantine-report.component';

describe('HLQuarantineReportComponent', () => {
  let component: HLQuarantineReportComponent;
  let fixture: ComponentFixture<HLQuarantineReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HLQuarantineReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HLQuarantineReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
