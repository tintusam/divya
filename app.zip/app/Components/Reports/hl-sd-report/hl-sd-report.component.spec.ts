import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HLSDReportComponent } from './hl-sd-report.component';

describe('HLSDReportComponent', () => {
  let component: HLSDReportComponent;
  let fixture: ComponentFixture<HLSDReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HLSDReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HLSDReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
