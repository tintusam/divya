import { Component, OnInit } from '@angular/core';
import { AppService } from '../../../Services/app.service';
import * as XLSX from 'xlsx';
import { MessageService } from 'primeng/api';
import * as moment from 'moment';

import { Workbook } from 'exceljs';
import * as fs from 'file-saver';


@Component({
  selector: 'app-hl-sd-report',
  templateUrl: './hl-sd-report.component.html',
  styleUrls: ['./hl-sd-report.component.scss']
})
export class HLSDReportComponent implements OnInit {


  sessionCountry: any;
  sessionState: any;
  sessionSite: any;
  sessionSid: any;
  sessionSiteId: any;
  sessionTempAlertCount: any;
  sessionSDA_Counts: any;
  sessionQuarantineCounts: any;
  showLoader = false;
  associateAlertList: any;
  fileName = '';
  currentJS_Date: Date;
  NewDateSelected: Date;
  currentDate = moment().format("MMM-DD-YYYY");
  constructor(private app: AppService, private messageService: MessageService) { }

  ngOnInit() {
    this.currentJS_Date = new Date();
    this.associateAlertList = [];
    this.sessionCountry = sessionStorage.getItem('Country');
    this.sessionSite = (sessionStorage.getItem('store'));
    this.sessionQuarantineCounts = parseInt(sessionStorage.getItem('QuarantineCount'))
    this.sessionSDA_Counts = parseInt(sessionStorage.getItem('SDA_Counts'))
    this.sessionTempAlertCount = parseInt(sessionStorage.getItem('TempAlertCount'))
    if (this.sessionSite != 'all') {
      this.sessionSite = JSON.parse(sessionStorage.getItem('store'));
      this.sessionSiteId = this.sessionSite.StoreId;
      this.sessionSid = this.sessionSite.Sid;
      this.sessionState = this.sessionSite.State;
      this.sessionCountry = this.sessionSite.Country;
    } else {
      this.sessionState = sessionStorage.getItem('State');
      this.sessionSiteId = this.sessionSite;
      this.sessionSid = 0;
    }

    this.fileName = this.sessionSiteId + '-SDA-Report-' + this.currentDate
    let payload = {
      "Country": this.sessionCountry,
      "Region": this.sessionState,
      "Status": 'SDAlert',
      "Sid": this.sessionSid

    }
    // console.log(payload);
    this.app.getEmployeeListforlabels(payload).subscribe(res => {
      // console.log(res)
      this.associateAlertList = res;
      this.showLoader = false;
    })

  }

  sortInDescendingCBT() {
    this.associateAlertList.sort((a, b) => b.Duration - a.Duration)
  }
  sortInAscendingCBT() {
    this.associateAlertList.sort((a, b) => a.Duration - b.Duration)
  }

  exportexcel(): void {

    if (this.fileName == '') {
      // alert('Please Provide File Name');
      this.messageService.clear();
      this.messageService.add({ key: 'c2', sticky: true, severity: 'warn', summary: 'ERROR', detail: 'Please Provide File Name.' });

    } else {

      // /* table id is passed over here */
      // let element = document.getElementById('excel-table');
      // const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(element);

      // /* generate workbook and add the worksheet */
      // const wb: XLSX.WorkBook = XLSX.utils.book_new();
      // XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

      // /* save to file */
      // XLSX.writeFile(wb, this.fileName + '.xls');
      // this.fileName = '';




      // Styling Excel

      //Create workbook and worksheet
      let workbook = new Workbook();
      let worksheet = workbook.addWorksheet('Report Data');


      worksheet.columns = [
        { header: 'Name', key: 'Name', width: 30 },
        { header: 'Unique ID', key: 'EmployeeId', width: 30 },
        { header: 'Breach Count', key: 'count', width: 15 },
        { header: 'Cumulative Breach Time ', key: 'Duration', width: 30 },
        { header: 'Last Recorded Breach ', key: 'LastUpdatedTime', width: 30 }
      ];

      //Add Header Row
      let headerRow = worksheet.getRow(1);

      headerRow.height = 25;

      // Cell Style : Fill and Border
      headerRow.eachCell((cell, number) => {
        cell.font = {
          name: 'Comic Sans MS',
          family: 4,
          size: 11,
          bold: true,
          color: { argb: 'f8f9fa' }
        },
          cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: '083c5a' }
          },
          cell.alignment = { vertical: 'middle', horizontal: 'center' },
          cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
      })

      for (let row of this.associateAlertList) {
        row["LastUpdatedTime"] = moment(row["LastUpdatedTime"]).format('MMM DD, YYYY, h:mm:ss a');
        let mainrow = worksheet.addRow(row);

        mainrow.height = 20;

        mainrow.eachCell((cell, number) => {
          cell.alignment = { vertical: 'middle', horizontal: 'center' }
        });

      }


      //Generate Excel File with given name
      workbook.xlsx.writeBuffer().then((data) => {
        let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        fs.saveAs(blob, this.fileName + '.xlsx');
      })

    }

  }
}
