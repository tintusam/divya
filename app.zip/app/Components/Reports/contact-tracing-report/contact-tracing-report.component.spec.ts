import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContactTracingReportComponent } from './contact-tracing-report.component';

describe('ContactTracingReportComponent', () => {
  let component: ContactTracingReportComponent;
  let fixture: ComponentFixture<ContactTracingReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContactTracingReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContactTracingReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
