import { Component, OnInit } from '@angular/core';
import { AppService } from '../../../Services/app.service';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';

import { Workbook } from 'exceljs';
import * as fs from 'file-saver';

import * as XLSX from 'xlsx';
import { MessageService } from 'primeng/api';
import * as moment from 'moment';
@Component({
  selector: 'app-contact-tracing-report',
  templateUrl: './contact-tracing-report.component.html',
  styleUrls: ['./contact-tracing-report.component.scss']
})
export class ContactTracingReportComponent implements OnInit {
  DateRange: any[] = [];

  datePickerConfig: Partial<BsDatepickerConfig>;
  showFilter = false;
  showNoteDate = false;
  employeeEmail: any;
  BSEmail: any;
  SDAlertList: any;
  tempFilteredList: any;
  filteredList: any;
  showLoader = false;
  siteObject: any;
  employeeObject: any;
  minDuration = 0;
  showNote = false;
  fileName = '';
  currentJS_Date: Date;
  NewDateSelected: Date;
  currentDate = moment().format("MMM-DD-YYYY");
  searchTermUniqueId = ''
  showUniqId = false;
  constructor(private app: AppService, private messageService: MessageService) {
    this.datePickerConfig = Object.assign({},
      {
        containerClass: 'theme-dark-blue',
        showWeekNumbers: false,
        rangeInputFormat: 'DD/MM/YYYY',
        isAnimated: true,
        adaptivePosition: true
      });
  }

  ngOnInit() {
    this.filteredList = [];
    this.showNoteDate = false;
    this.DateRange = [];
    this.siteObject = JSON.parse(sessionStorage.getItem('store'))
    this.employeeObject = JSON.parse(sessionStorage.getItem('SetEmployee'))
    this.employeeEmail = sessionStorage.getItem('EmpEmail');
    this.app.getEmailId.subscribe(email => {
      this.showLoader = true;
      this.SDAlertList = [];
      this.BSEmail = email || this.employeeEmail;
      this.fileName = this.employeeObject.FullName + '-Contact-Tracing-Report-' + this.currentDate
      let payload = {
        "Email": this.BSEmail
      }
      this.app.getSocialDistancingAlerts(payload).subscribe(res => {
        this.showNote = false;
        this.showLoader = false;
        this.SDAlertList = res;
        this.filteredList = this.SDAlertList;
        // console.log('HELLLLLLLO', this.SDAlertList)
        // alert('user SD Email:' + this.BSEmail)

      })
    })
  }

  resetFilter() {
    this.DateRange = [];
    this.minDuration = 0
  }
  showAllRecords() {
    this.filteredList = [];
    this.filteredList = this.SDAlertList;
    this.showNote = false;
    this.showFilter = false;
    this.DateRange = [];
    this.minDuration = 0
  }
  filterRecords() {

    this.filteredList = [];
    this.tempFilteredList = [];
    for (let item of this.SDAlertList) {
      if (item.Duration >= this.minDuration) {
        this.tempFilteredList.push(item);
      }
    }


    if (this.DateRange.length === 0) {
      this.filteredList = this.tempFilteredList;
      this.showNote = true;
      this.showFilter = false;
    } else {
      this.DateRange[0] = new Date((this.DateRange[0]).setHours(0));
      this.DateRange[0] = new Date((this.DateRange[0]).setMinutes(0));
      this.DateRange[1] = new Date(this.DateRange[1].setHours(23));
      this.DateRange[1] = new Date(this.DateRange[1].setMinutes(59));
      this.filteredList = this.tempFilteredList.filter((item: any) => {
        return new Date(item.StartTime).getTime() >= new Date(this.DateRange[0]).getTime() &&
          new Date(item.EndTime).getTime() <= new Date(this.DateRange[1]).getTime();
      })



      // // console.log(this.filteredList);
      this.showFilter = false;
      this.showNoteDate = true;
      this.showNote = true;
      // this.DateRange = [];
    }

    if (this.searchTermUniqueId !== '') {
      // console.log(this.searchTermUniqueId);
      // this.filteredList = []
      this.filteredList = this.filteredList.filter((item) => {
        // console.log(item.EmployeeId)
        return item.EmployeeId == this.searchTermUniqueId
      })

      if (this.DateRange.length != 0) {
        this.showNoteDate = true;
        this.showNote = true;
      } else {
        this.showNote = true;
        this.showUniqId = true;
      }
      this.showFilter = false;
    }
  }



  exportexcel(): void {

    if (this.fileName == '') {
      // alert('Please Provide File Name');
      this.messageService.clear();
      this.messageService.add({ key: 'c2', sticky: true, severity: 'warn', summary: 'ERROR', detail: 'Please Provide File Name.' });

    } else {
      // /* table id is passed over here */
      // let element = document.getElementById('excel-table');
      // const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(element);

      // /* generate workbook and add the worksheet */
      // const wb: XLSX.WorkBook = XLSX.utils.book_new();
      // XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

      // /* save to file */
      // XLSX.writeFile(wb, this.fileName + '.xls');
      // // this.fileName = '';



      // Styling Excel

      //Create workbook and worksheet
      let workbook = new Workbook();
      let worksheet = workbook.addWorksheet('Report Data');


      worksheet.columns = [
        { header: 'Name', key: 'FullName', width: 30 },
        { header: 'Unique ID', key: 'EmployeeId', width: 30 },
        { header: 'Start Time', key: 'StartTime', width: 30 },
        { header: 'End Time ', key: 'EndTime', width: 30 },
        { header: 'Duration (min.sec) ', key: 'Duration', width: 20 }
      ];

      //Add Header Row
      let headerRow = worksheet.getRow(1);

      headerRow.height = 25;

      // Cell Style : Fill and Border
      headerRow.eachCell((cell, number) => {
        cell.font = {
          name: 'Comic Sans MS',
          family: 4,
          size: 11,
          bold: true,
          color: { argb: 'f8f9fa' }
        },
          cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: '083c5a' }
          },
          cell.alignment = { vertical: 'middle', horizontal: 'center' },
          cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
      })

      for (let row of this.filteredList) {
        row["StartTime"] = moment(row["StartTime"]).format('MMM DD, YYYY, h:mm:ss a');
        row["EndTime"] = moment(row["EndTime"]).format('MMM DD, YYYY, h:mm:ss a');

        let mainrow = worksheet.addRow(row);

        mainrow.height = 20;

        mainrow.eachCell((cell, number) => {
          cell.alignment = { vertical: 'middle', horizontal: 'center' }
        });

      }


      //Generate Excel File with given name
      workbook.xlsx.writeBuffer().then((data) => {
        let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        fs.saveAs(blob, this.fileName + '.xlsx');
      })

    }

  }


}
