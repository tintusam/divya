import { Component, OnInit } from '@angular/core';
import { AppService } from '../../../Services/app.service';

import { Workbook } from 'exceljs';
import * as fs from 'file-saver';


import * as XLSX from 'xlsx';
import { MessageService } from 'primeng/api';
import * as moment from 'moment';
import { last } from 'rxjs/operators';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { templateJitUrl } from '@angular/compiler';
@Component({
  selector: 'app-sda-cumulative-report',
  templateUrl: './sda-cumulative-report.component.html',
  styleUrls: ['./sda-cumulative-report.component.scss']
})
export class SDACumulativeReportComponent implements OnInit {

  sessionCountry: any;
  sessionState: any;
  sessionSite: any;
  sessionSid: any;
  sessionSiteId: any;
  sessionTempAlertCount: any;
  sessionSDA_Counts: any;
  sessionQuarantineCounts: any;
  showLoader = false;
  associateAlertList: any;
  showFilterOption = false;
  FilterOptionSelected: any
  fileName = '';
  customDays = undefined
  currentJS_Date: Date;
  NewDateSelected: Date;
  currentDate = moment().format("MMM-DD-YYYY");
  openAll = false;
  showNote = false;
  datePickerConfig: Partial<BsDatepickerConfig>;
  DateRange: string[] = [];
  fullResponse: any;
  showEmployee = false;
  EmployeeIdInput = "";
  constructor(private app: AppService, private messageService: MessageService) {

    this.datePickerConfig = Object.assign({},
      {
        containerClass: 'theme-dark-blue',
        showWeekNumbers: false,
        rangeInputFormat: 'YYYY-MM-DD',
        isAnimated: true,
        adaptivePosition: true
      });
    // console.log(this.DateRange)
  }

  ngOnInit() {
    this.showEmployee = false;
    this.DateRange = [];
    this.EmployeeIdInput = ""
    this.showNote = false;
    this.showLoader = true
    this.currentJS_Date = new Date();
    this.associateAlertList = [];
    this.sessionCountry = sessionStorage.getItem('Country');
    this.sessionSite = (sessionStorage.getItem('store'));
    this.sessionQuarantineCounts = parseInt(sessionStorage.getItem('QuarantineCount'))
    this.sessionSDA_Counts = parseInt(sessionStorage.getItem('SDA_Counts'))
    this.sessionTempAlertCount = parseInt(sessionStorage.getItem('TempAlertCount'))
    if (this.sessionSite != 'all') {
      this.sessionSite = JSON.parse(sessionStorage.getItem('store'));
      this.sessionSiteId = this.sessionSite.StoreId;
      this.sessionSid = this.sessionSite.Sid;
      this.sessionState = this.sessionSite.State;
      this.sessionCountry = this.sessionSite.Country;
    } else {
      this.sessionState = sessionStorage.getItem('State');
      this.sessionSiteId = this.sessionSite;
      this.sessionSid = 0;
    }
    this.fileName = this.sessionSiteId + '-SDA-15mins-Report-' + this.currentDate
    // let payload = {
    //   "Country": this.sessionCountry,
    //   "Region": this.sessionState,
    //   "Status": 'SDAlert',
    //   "Sid": this.sessionSid

    // }

    let payload = {
      "Sid": this.sessionSid
    }
    this.app.getSDAlerts15Mins(payload).subscribe(res => {
      // console.log(res)
      this.associateAlertList = res;
      this.fullResponse = res;
      this.showLoader = false;
      this.showFilterOption = false;
    })

  }

  getCumulativeAlertListByDays() {
    this.showLoader = true;

    if (this.DateRange == null) {
      this.DateRange = []
    }
    // console.log(this.DateRange);
    // console.log('Before', this.associateAlertList)

    if (this.DateRange.length !== 0 && !this.EmployeeIdInput) {
      // console.log('ONLY DATE');
      this.showEmployee = false;
      this.associateAlertList = [];
      let payload = {
        "Sid": this.sessionSid,
        "FromDate": moment(this.DateRange[0]).format('YYYY-MM-DD'),
        "ToDate": moment(this.DateRange[1]).format('YYYY-MM-DD')
      }
      // { Sid: parseInt(sessionStorage.getItem('SiteId')) }
      this.app.getSDAlerts15MinsByDays(payload).subscribe(res => {
        // console.log(res)
        this.associateAlertList = res;
        this.showNote = true;
        this.showLoader = false
      }, err => {
        console.log(err)
        this.showLoader = false
        this.FilterOptionSelected = 0;
      })
    } else if (this.EmployeeIdInput !== '' && this.DateRange.length == 0) {
      this.associateAlertList = this.fullResponse
      // console.log("only Name")
      let tempList = [];
      console.log(this.associateAlertList)
      // console.log('Inside', this.EmployeeIdInput)
      for (let item of this.associateAlertList) {
        // console.log(item.EmployeeId)
        if (item.EmployeeId == this.EmployeeIdInput || item.OtherEmployee == this.EmployeeIdInput) {
          tempList.push(item);

          // console.log('True', item.EmployeeId)
        }
        // console.log(tempList)
      }


      this.associateAlertList = tempList;
      this.showNote = false;
      this.showEmployee = true;
      this.showLoader = false;
    }

    else {

      // console.log('Date and Name')
      // Filter By Date
      this.associateAlertList = [];
      let payload = {
        "Sid": this.sessionSid,
        "FromDate": moment(this.DateRange[0]).format('YYYY-MM-DD'),
        "ToDate": moment(this.DateRange[1]).format('YYYY-MM-DD')
      }
      // { Sid: parseInt(sessionStorage.getItem('SiteId')) }
      this.app.getSDAlerts15MinsByDays(payload).subscribe(res => {
        // console.log(res)
        this.associateAlertList = res;
        this.showNote = true;
        let tempList = [];

        for (let item of this.associateAlertList) {
          // console.log(item.EmployeeId)
          if (item.EmployeeId == this.EmployeeIdInput || item.OtherEmployee == this.EmployeeIdInput) {
            tempList.push(item);
            // console.log('True', item.EmployeeId)
          }
          // console.log(tempList)
        }


        this.associateAlertList = tempList
      }, err => {
        console.log(err)
        this.showLoader = false
        this.FilterOptionSelected = 0;
      })

      // this.showNote = false;
      this, this.showLoader = false;
      this.showEmployee = true
    }

    // this.showLoader = false;
    // // this.FilterOptionSelected = 0;
    // this.showFilterOption = false;

    this.showFilterOption = false
  }

  exportexcel(): void {

    if (this.fileName == '') {
      // alert('Please Provide File Name');
      this.messageService.clear();
      this.messageService.add({ key: 'c2', sticky: true, severity: 'warn', summary: 'ERROR', detail: 'Please Provide File Name.' });

    } else {
      //   /* table id is passed over here */
      //   let element = document.getElementById('excel-table');
      //   const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(element);

      //   /* generate workbook and add the worksheet */
      //   const wb: XLSX.WorkBook = XLSX.utils.book_new();
      //   XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

      //   /* save to file */
      //   XLSX.writeFile(wb, this.fileName + '.xls');
      //   this.fileName = ''
      // }



      // Styling Excel

      //Create workbook and worksheet
      let workbook = new Workbook();
      let worksheet = workbook.addWorksheet('Report Data');


      worksheet.columns = [
        { header: 'Employee ID', key: 'EmployeeId', width: 30 },
        { header: 'Close Contact with', key: 'OtherEmployee', width: 30 },
        { header: 'Duration (min.sec)', key: 'Duration', width: 30 },
        { header: 'Breach Count', key: 'BreachCount', width: 15 }
      ];

      //Add Header Row
      let headerRow = worksheet.getRow(1);

      headerRow.height = 25;

      // Cell Style : Fill and Border
      headerRow.eachCell((cell, number) => {
        cell.font = {
          name: 'Comic Sans MS',
          family: 4,
          size: 11,
          bold: true,
          color: { argb: 'f8f9fa' }
        },
          cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: '083c5a' }
          }
        cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
      })

      for (let row of this.associateAlertList) {

        let mainrow = worksheet.addRow(row);

        mainrow.height = 20;

        let subcol = worksheet.addRow(['Start Time', 'End Time', 'Duration']);

        subcol.eachCell((cell, number) => {
          cell.font = {
            name: 'Comic Sans MS',
            family: 4,
            size: 11,
            bold: true,
            //  color: { argb: 'f8f9fa' }
          },
            cell.fill = {
              type: 'pattern',
              pattern: 'solid',
              fgColor: { argb: 'ffff00' }
            },
            cell.alignment = { vertical: 'middle', horizontal: 'center' };
          cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
        })


        for (let subrow of row.SdAlertsList) {
          let StartTime = moment(subrow["StartTime"]).format('MMM DD, YYYY, h:mm:ss a');

          let EndTime = moment(subrow["EndTime"]).format('MMM DD, YYYY, h:mm:ss a');

          let subrowdata = worksheet.addRow([StartTime, EndTime, subrow["Duration"]]);

          subrowdata.eachCell((cell, number) => {
            cell.fill = {
              type: 'pattern',
              pattern: 'solid',
              fgColor: { argb: 'd2d3d4' }
            },
              cell.alignment = { vertical: 'middle', horizontal: 'center' };
            cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }

          })
        }


      }


      //Generate Excel File with given name
      workbook.xlsx.writeBuffer().then((data) => {
        let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        fs.saveAs(blob, this.fileName + '.xlsx');
      })

    }


  }



  sortInDescending() {
    this.associateAlertList.sort((a, b) => b.Duration - a.Duration)
  }
  sortInAscending() {
    this.associateAlertList.sort((a, b) => a.Duration - b.Duration)
  }

}
