import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HLAlertsReportComponent } from './hl-alerts-report.component';

describe('HLAlertsReportComponent', () => {
  let component: HLAlertsReportComponent;
  let fixture: ComponentFixture<HLAlertsReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HLAlertsReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HLAlertsReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
