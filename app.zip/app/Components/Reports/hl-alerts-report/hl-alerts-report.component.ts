import { Component, OnInit } from '@angular/core';
import { AppService } from '../../../Services/app.service';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import * as moment from 'moment'

@Component({
  selector: 'app-hl-alerts-report',
  templateUrl: './hl-alerts-report.component.html',
  styleUrls: ['./hl-alerts-report.component.scss']
})
export class HLAlertsReportComponent implements OnInit {

  sessionCountry: any;
  sessionState: any;
  sessionSite: any;
  sessionSid: any;
  sessionSiteId: any;
  sessionTempAlertCount: any;
  sessionSDA_Counts: any;
  sessionQuarantineCounts: any;
  showLoader = false;
  associateAlertList: any;

  constructor(private app: AppService) { }

  ngOnInit() {
    this.associateAlertList = [];
    this.sessionQuarantineCounts = parseInt(sessionStorage.getItem('QuarantineCount'))
    this.sessionSDA_Counts = parseInt(sessionStorage.getItem('SDA_Counts'))
    this.sessionTempAlertCount = parseInt(sessionStorage.getItem('TempAlertCount'))
    this.sessionCountry = sessionStorage.getItem('Country');
    this.sessionSite = (sessionStorage.getItem('store'));
    if (this.sessionSite != 'all') {
      this.sessionSite = JSON.parse(sessionStorage.getItem('store'));
      this.sessionSiteId = this.sessionSite.StoreId;
      this.sessionSid = this.sessionSite.Sid;
      this.sessionState = this.sessionSite.State;
      this.sessionCountry = this.sessionSite.Country;
    } else {
      this.sessionState = sessionStorage.getItem('State');
      this.sessionSiteId = this.sessionSite;
      this.sessionSid = 0;
    }

    let payload = {
      "Country": this.sessionCountry,
      "Region": this.sessionState,
      "Status": 'Alert',
      "Sid": this.sessionSid

    }
    this.app.getEmployeeListforlabels(payload).subscribe(res => {
      // console.log(res)
      this.associateAlertList = res;
      this.showLoader = false;
    })

  }

}
