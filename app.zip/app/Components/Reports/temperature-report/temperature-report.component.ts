import { Component, OnInit } from '@angular/core';
import { AppService } from '../../../Services/app.service';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import * as moment from 'moment'
import { ChartDataSets, ChartOptions } from 'chart.js';
import { Color, Label } from 'ng2-charts';
@Component({
  selector: 'app-temperature-report',
  templateUrl: './temperature-report.component.html',
  styleUrls: ['./temperature-report.component.scss']
})
export class TemperatureReportComponent implements OnInit {


  DateRange: any[] = [];

  datePickerConfig: Partial<BsDatepickerConfig>;
  showFilter = false;
  showNoteDate = false;
  employeeEmail: any;
  BSEmail: any;
  SDAlertList: any;
  tempFilteredList: any;
  filteredList: any;
  showLoader = false;
  siteObject: any;
  employeeObject: any;
  minDuration = 0;
  showNote = false;

  dateArray: any;
  dataArray: any;
  temperatureList: any;
  imgWrap: any;
  // Chart

  lineChartData: ChartDataSets[];

  lineChartLabels: Label[];

  lineChartOptions: any;

  lineChartColors: Color[];
  lineChartLegend = true;
  lineChartPlugins = [];
  lineChartType = 'line';
  options: { bezierCurve: boolean; animation: { onComplete: any; }; };
  myLine: Chart;
  canvas: any;
  img: any;
  image: any;

  constructor(private app: AppService) {
    this.datePickerConfig = Object.assign({},
      {
        containerClass: 'theme-dark-blue',
        showWeekNumbers: false,
        rangeInputFormat: 'MMMM Do YYYY',
        isAnimated: true,
        adaptivePosition: true
      });
  }


  ngOnInit() {
    this.filteredList = [];
    this.showNoteDate = false;
    this.DateRange = [];
    this.siteObject = JSON.parse(sessionStorage.getItem('store'))
    this.employeeObject = JSON.parse(sessionStorage.getItem('SetEmployee'))
    this.employeeEmail = sessionStorage.getItem('EmpEmail');
    this.app.getEmailId.subscribe(email => {
      this.showLoader = true;
      this.SDAlertList = [];
      this.BSEmail = email || this.employeeEmail;
      let payload = {
        "Email": this.BSEmail
      }
      this.app.getTemperatureGraphForEmployee(payload).subscribe(res => {
        this.dateArray = [];
        this.dataArray = [];
        this.temperatureList = res;
        for (let item of this.temperatureList) {
          this.dataArray.push(item.Temperature);
          this.dateArray.push(moment(item.EventEnqueuedUtcTime).format('D-MMM'))
        }
        this.chartFunction()
        this.showNote = false;
        this.showLoader = false;
        this.SDAlertList = res;
        this.filteredList = this.SDAlertList;
        // console.log('HELLLLLLLO', this.SDAlertList)
        // alert('user SD Email:' + this.BSEmail)

      })
    })

  }
  chartFunction() {
    this.imgWrap = null;
    this.lineChartData = [
      { data: this.dataArray, label: 'Body Temperature in °F' },
    ];

    this.lineChartLabels = this.dateArray;

    this.lineChartOptions = {
      responsive: true,
      borderWidth: 10,
      scales: {
        xAxes: [{
          ticks: {
            fontColor: 'black',
            autoSkip: true,
            maxTicksLimit: 7
          },
          gridLines: { color: 'rgba(255,255,255,0.0)' }
        }],
        yAxes: [{
          ticks: { fontColor: 'black' },
          gridLines: { color: 'rgba(255,255,255,0)' },
        }]
      },
      annotation: {
        annotations: [{
          drawTime: "afterDatasetsDraw",
          id: "hline",
          type: "line",
          mode: "horizontal",
          scaleID: "y-axis-0",
          value: 100.2,
          borderColor: "red",
          borderWidth: 3,
          borderDash: [4, 4]
        }

        ]
      }
    }

    this.lineChartColors = [
      {
        borderColor: '#115f7ea4',
        backgroundColor: 'rgba(255,255,0,0.05)',
      },
    ];

    //// console.log("jjjh");

    this.lineChartLegend = true;

    this.lineChartPlugins = [{
      afterRender: function () {
        if (this.image == null) {
          // // console.log("hai");
          this.canvas = document.getElementById("chartArea");
          this.imgWrap = document.getElementById('imgWrap');
          this.imgWrap.src = this.canvas.toDataURL("image/png");
          this.canvas.style.display = 'none';
        }
      },
    }];

    this.lineChartType = 'line';


  }
  resetFilter() {
    this.DateRange = [];
    this.minDuration = 0
  }
  showAllRecords() {
    this.filteredList = [];
    this.filteredList = this.SDAlertList;
    this.showNote = false;
    this.showFilter = false;
    this.DateRange = [];
    this.minDuration = 0;
    this.dateArray = [];
    this.dataArray = [];
    this.temperatureList = this.filteredList;
    for (let item of this.temperatureList) {
      this.dataArray.push(item.Temperature);
      this.dateArray.push(moment(item.EventEnqueuedUtcTime).format('D-MMM'))
    }
    this.chartFunction()

  }
  filterRecords() {
    // this.filteredList = [];
    // this.tempFilteredList = []
    // for (let item of this.SDAlertList) {
    //   if (item.Duration >= this.minDuration) {
    //     this.tempFilteredList.push(item)
    //   }
    // }

    // if (this.DateRange == []) {
    //   this.filteredList = this.tempFilteredList;
    //   this.showNote = true;
    //   this.showFilter = false;
    // }
    // else {
    //   alert('Next Step')
    // } June 18th 2020,12:55:54 pm
    this.temperatureList = [];
    this.filteredList = [];
    this.tempFilteredList = [];
    for (let item of this.SDAlertList) {
      if (item.Temperature >= this.minDuration) {
        this.tempFilteredList.push(item);
      }
    }
    if (this.DateRange.length === 0) {
      this.filteredList = this.tempFilteredList;
      this.showNote = true;
      this.showFilter = false;
    } else {
      this.DateRange[0] = new Date((this.DateRange[0]).setHours(0));
      this.DateRange[0] = new Date((this.DateRange[0]).setMinutes(0));
      this.DateRange[1] = new Date(this.DateRange[1].setHours(23));
      this.DateRange[1] = new Date(this.DateRange[1].setMinutes(59));
      // console.log(this.DateRange)
      this.filteredList = this.tempFilteredList.filter((item: any) => {
        return new Date(item.EventEnqueuedUtcTime).getTime() >= new Date(this.DateRange[0]).getTime() &&
          new Date(item.EventEnqueuedUtcTime).getTime() <= new Date(this.DateRange[1]).getTime();
      })
      // // console.log(this.filteredList);
      this.showFilter = false;
      this.showNoteDate = true;
      this.showNote = true;
      // this.DateRange = [];
    }
    this.dateArray = [];
    this.dataArray = [];
    this.temperatureList = this.filteredList;
    for (let item of this.temperatureList) {
      this.dataArray.push(item.Temperature);
      this.dateArray.push(moment(item.EventEnqueuedUtcTime).format('D-MMM'))
    }
    this.chartFunction()
  }
}
