import { Component, OnInit } from '@angular/core';
import { AppService } from '../../../Services/app.service'
import { ChartDataSets, ChartOptions } from 'chart.js';
import { Color, Label } from 'ng2-charts';

import * as moment from 'moment'


@Component({
  selector: 'app-user-temperature-tab',
  templateUrl: './user-temperature-tab.component.html',
  styleUrls: ['./user-temperature-tab.component.scss']
})
export class UserTemperatureTabComponent implements OnInit {

  employeeEmail: any;
  BSEmail: any;
  temperatureList: any;
  temperatureResponse: any;
  dateArray: any;
  showLoader = false;
  dataArray: any;
  tableTempList: any;

  // Chart

  lineChartData: ChartDataSets[];

  lineChartLabels: Label[];

  lineChartOptions: any;

  lineChartColors: Color[];
  lineChartLegend = true;
  lineChartPlugins = [];
  lineChartType = 'line';

  constructor(private app: AppService) {

  }

  ngOnInit() {
    //  ChartJS

    this.tableTempList = [];
    this.temperatureList = []

    // //////////////////

    this.employeeEmail = sessionStorage.getItem('EmpEmail');
    this.app.getEmailId.subscribe(email => {
      this.temperatureList = [];
      this.BSEmail = email || this.employeeEmail;
      this.showLoader = true;
      let payload = {
        "Email": this.BSEmail
      }
      this.app.getTemperatureGraphForEmployee(payload).subscribe(res => {

        this.dateArray = [];
        this.dataArray = [];
        this.temperatureList = res;
        // this.tableTempList = res;
        // this.tableTempList.reverse();
        for (let item of this.temperatureList) {
          this.dataArray.push(item.Temperature);
          this.dateArray.push(moment(item.EventEnqueuedUtcTime).format('DD-MMM HH:mm'))
        }
        // this.lineChartData[0].data = this.dataArray;
        this.showLoader = false;
        this.chartFunction();

      })
    })



  }

  refreshChart() {
    setTimeout(() => {
      this.chartFunction()
    }, 500)
  }

  chartFunction() {
    this.lineChartData = [
      { data: this.dataArray, label: 'Body Temperature in °F' },
    ];

    this.lineChartLabels = this.dateArray;

    this.lineChartOptions = {
      responsive: true,
      scales: {
        xAxes: [{
          ticks: {
            fontColor: 'black',
            autoSkip: true,
            maxTicksLimit: 7
          },
          gridLines: { color: 'rgba(255,255,255,0.0)' }
        }],
        yAxes: [{
          ticks: { fontColor: 'black' },
          gridLines: { color: 'rgba(255,255,255,0)' },
          // plotLines: [{
          // color: '#FF0000',
          // width: 2,
          // value: .50 * 200 // The marker value will be 100
          // // Or you can just set its value to 100
          // }]
        }]
      },
      annotation: {
        annotations: [{
          drawTime: "afterDatasetsDraw",
          id: "hline",
          type: "line",
          mode: "horizontal",
          scaleID: "y-axis-0",
          value: 100.2,
          borderColor: "red",
          borderWidth: 5,
          // content: '99.2 °F',
          borderDash: [6, 2]
        }

        ]
      }
    }
    this.lineChartColors = [
      {
        borderColor: '#115f7ea4',
        backgroundColor: 'rgba(255,255,0,0.05)',
      },
    ];

    this.lineChartLegend = true;
    this.lineChartPlugins = [];
    this.lineChartType = 'line';
  }


}