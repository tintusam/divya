import { Component, OnInit } from '@angular/core';
import { AppService } from '../../../Services/app.service'
import * as moment from 'moment';
import { MessageService } from 'primeng/api';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
@Component({
  selector: 'app-user-social-distancing-tab',
  templateUrl: './user-social-distancing-tab.component.html',
  styleUrls: ['./user-social-distancing-tab.component.scss']
})
export class UserSocialDistancingTabComponent implements OnInit {

  DateRange: any[] = [];

  datePickerConfig: Partial<BsDatepickerConfig>;


  employeeEmail: any;
  BSEmail: any;
  SDAlertList: any;
  showLoader = false;
  sessionStoreId = '';
  sessionStore: any;
  Curr_TimeZone: any
  setRecord: any;
  noteText = ''
  showModal = false;
  showNoteModal = false;
  showFilter = false;
  showCustomFilter = false;
  FullList: any;
  FilterSelected: any;
  FilterOptions: string[] = ['All', '1 minute', 'Custom'];
  customFilterInput: any;
  checked = false;
  showNote = false;
  showDate = false
  constructor(private app: AppService, private messageService: MessageService) {
    this.datePickerConfig = Object.assign({},
      {
        containerClass: 'theme-dark-blue',
        showWeekNumbers: false,
        rangeInputFormat: 'DD/MM/YYYY',
        isAnimated: true,
        adaptivePosition: true
      });
  }

  ngOnInit() {
    // this.FilterSelected = 99;
    // console.log('Init: ', this.FilterSelected)
    this.showFilter = false;
    this.Curr_TimeZone = new Date().getTimezoneOffset();

    this.employeeEmail = sessionStorage.getItem('EmpEmail');

    this.app.getEmailId.subscribe(email => {
      this.showLoader = true;
      this.sessionStore = JSON.parse(sessionStorage.getItem('store'));
      // console.log(this.sessionStore)
      this.sessionStoreId = this.sessionStore.StoreId;
      this.FilterSelected = 0;
      this.filterRecords(this.FilterSelected);
      this.DateRange = [];
      this.showFilter = false;
      // console.log(this.sessionStoreId)
      this.showLoader = true;
      this.SDAlertList = [];
      this.showDate = false
      this.BSEmail = email || this.employeeEmail;

      let payload = {
        "Email": this.BSEmail
      }
      this.app.getSocialDistancingAlerts(payload).subscribe(res => {
        this.showLoader = false;
        this.SDAlertList = res;
        this.FullList = res;
        // console.log(this.SDAlertList)
        // alert('user SD Email:' + this.BSEmail)

      })
    })
  }

  filterRecords(option) {
    this.showDate = false;
    this.showLoader = true;
    // this.FilterSelected = option
    // console.log('In Fn: ', this.FilterSelected)
    // console.log(option)
    // console.log('insife Function')
    if (option == 0) {
      // console.log('insife 0 Function')
      this.SDAlertList = this.FullList
      this.showLoader = false
    } else if (option == 1) {
      this.SDAlertList = this.FullList;
      // console.log('insife 1 Function')
      this.SDAlertList = this.SDAlertList.filter(item => {
        return item.Duration >= 1;
      })
      this.showLoader = false
    }
    else {
      this.SDAlertList = this.FullList
      // console.log('insife custom Function')
      this.SDAlertList = this.SDAlertList.filter(item => {
        return item.Duration >= this.customFilterInput;
      })
      this.showLoader = false;
      this.showNote = true;
    }

    // console.log(this.FilterSelected)
    setTimeout(() => {
      this.showFilter = false;
      // this.FilterSelected = 0;
    }, 100)

  }

  filterRecordDate() {
    this.showLoader = true;
    // this.SDAlertList = this.FullList;
    // // this.filteredList = [];
    // // this.tempFilteredList = [];
    // for (let item of this.FullList) {
    //   if (item.Duration >= this.minDuration) {
    //     this.tempFilteredList.push(item);
    //   }
    // }
    if (this.DateRange.length === 0) {
      this.SDAlertList = this.FullList;
      // this.showNote = true;
      this.showFilter = false;
    } else {
      this.DateRange[0] = new Date((this.DateRange[0]).setHours(0));
      this.DateRange[0] = new Date((this.DateRange[0]).setMinutes(0));
      this.DateRange[1] = new Date(this.DateRange[1].setHours(23));
      this.DateRange[1] = new Date(this.DateRange[1].setMinutes(59));
      this.SDAlertList = this.SDAlertList.filter((item: any) => {
        return new Date(item.StartTime).getTime() >= new Date(this.DateRange[0]).getTime() &&
          new Date(item.EndTime).getTime() <= new Date(this.DateRange[1]).getTime();
      })
      // // console.log(this.filteredList);
      this.showFilter = false;
      this.showLoader = false;
      this.showDate = true;
      // this.showNote = true;


    }
  }
  addNote() {
    if (this.noteText == '') {
      this.messageService.clear();
      this.messageService.add({ life: 4000, sticky: false, severity: 'warn', summary: 'EMPTY NOTE', detail: 'Note cannot be empty.Please provide a note for not considering this record' });
    } else {
      let payload = {
        "Note": this.noteText,
        "NotConsider": "True",
        "UniqueId": this.setRecord.UniqueId
      }
      // console.log(payload);
      this.app.addRecordNote(payload).subscribe(res => {
        this.messageService.clear();
        this.messageService.add({ life: 4000, sticky: false, severity: 'success', summary: 'Note Added', detail: 'Note for not considering this record is added successfully' });
        this.noteText = '';
        this.ngOnInit();
        this.showModal = false;
      }, err => {
        this.messageService.clear();
        this.messageService.add({ life: 4000, sticky: false, severity: 'error', summary: 'Could not add note', detail: 'Note for not considering this record is not added' });
      })
    }
  }


}
