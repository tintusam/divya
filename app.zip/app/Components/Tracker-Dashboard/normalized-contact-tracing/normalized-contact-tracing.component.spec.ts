import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NormalizedContactTracingComponent } from './normalized-contact-tracing.component';

describe('NormalizedContactTracingComponent', () => {
  let component: NormalizedContactTracingComponent;
  let fixture: ComponentFixture<NormalizedContactTracingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NormalizedContactTracingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NormalizedContactTracingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
