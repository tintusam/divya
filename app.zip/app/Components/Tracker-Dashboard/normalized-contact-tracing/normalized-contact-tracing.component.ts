import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-normalized-contact-tracing',
  templateUrl: './normalized-contact-tracing.component.html',
  styleUrls: ['./normalized-contact-tracing.component.scss']
})
export class NormalizedContactTracingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
