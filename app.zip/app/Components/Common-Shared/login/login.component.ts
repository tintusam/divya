import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from '../../../Services/app.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
// PrimeNG
import { MessageService } from 'primeng/api';
import { setTime } from 'ngx-bootstrap/chronos/utils/date-setters';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  email = '';
  password = '';
  showLoginButton = false;
  validEmail = false;
  showNote = false;
  showPasswordMismatch = false;
  showLoader = false;
  AuthResponse: any;
  Message: any;
  GenerateTokenResponse: any;
  showWelcomeMessage = true;

  loginForm: FormGroup;
  registerForm: FormGroup;

  constructor(
    private app: AppService,
    private router: Router,
    private fb: FormBuilder,
    private messageService: MessageService,
  ) {

  }

  ngOnInit() {


    if (this.app.isAuthenticated() != true) {
      setTimeout(() => {
        this.showWelcomeMessage = false;
      }, 5000)
      this.router.navigate([""]);


    } else {
      this.showWelcomeMessage = false;
      this.router.navigate(['managers-portal/site-management']);

    }

    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    })

    this.registerForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      fullName: ['', [Validators.required, Validators.minLength(2)]],
      password: ['', [Validators.required]],
      confirmPassword: ['', [Validators.required]],
    })
  }
  goToLogin() {
    this.messageService.clear('c');
    window.location.reload();

  }
  // showConfirm() {
  //   this.messageService.clear();
  //   this.messageService.add({ key: 'c', sticky: true, severity: 'success', summary: 'Registration Successful!', detail: 'Please login with your credentials.' });
  // }

  validateEmail() {
    this.showLoader = true;
    setTimeout(() => {
      let payload = {
        "Email": this.registerForm.controls['email'].value
      }
      this.app.validateEmail(payload).subscribe(res => {
        // console.log('Validate', res)
        this.AuthResponse = res;
        if (this.AuthResponse.Message === 'User Already Registered') {
          this.Message = "User with the provided Email is already registered. Please Login In with your credentials."
          this.showLoader = false;
          this.validEmail = false;
          this.showNote = true;
          setTimeout(() => {
            this.showNote = false;
          }, 8000)
        } else if (this.AuthResponse.Message === 'Valid Email') {
          // alert('Valid Email ID. Proceed Further and enter the following Details')
          this.showLoader = false;
          this.validEmail = true
        } else if (this.AuthResponse.Message === 'Email not registered') {
          this.showLoader = false;
          this.validEmail = false;
          this.showNote = true;
          setTimeout(() => {
            this.showNote = false;
          }, 8000)
          this.Message = 'Email not Found.. Please Contact Admin'
        }
      })
    }, 1000)

  }

  RegisterUser() {

    if (this.registerForm.controls['password'].value !== this.registerForm.controls['confirmPassword'].value) {
      this.Message = 'Password and Confirm Password Do Not Match'
      this.showPasswordMismatch = true
      setTimeout(() => {
        this.showPasswordMismatch = false
      }, 3000)
    } else {
      let payload = {
        "FullName": this.registerForm.controls['fullName'].value,
        "Email": this.registerForm.controls['email'].value,
        "Password": this.registerForm.controls['password'].value,
      }
      this.app.registerUser(payload).subscribe(res => {
        // // console.log(res);
        this.AuthResponse = res;
        if (this.AuthResponse.Message === 'User registered') {
          // this.validEmail = false;
          // this.email
          // alert('Registration Successful. Please Login with your credentials');
          this.messageService.clear();
          this.messageService.add({ key: 'c', sticky: true, severity: 'success', summary: 'Registration Successful!', detail: 'Please login with your credentials.' });
          this.router.navigate([''])
          // window.location.reload();
        }
      })
    }
  }
  Login() {
    console.log(this.loginForm.controls['email'].value)
    if (this.loginForm.controls['email'].value == '' || this.loginForm.controls['password'].value == '') {
      this.messageService.clear();
      this.messageService.add({ key: 'c1', sticky: true, severity: 'warn', summary: 'EMPTY FIELDS!', detail: 'You forgot to enter email or password.' });
    } else {
      this.showLoginButton = true;
      this.showLoader = true;
      // CALL API HERE - AUTHENTICATE USER
      let payload = {
        "Email": this.loginForm.controls['email'].value.trim(), //.trim()
        "Password": this.loginForm.controls['password'].value,
      }
      this.app.authenticateUser(payload).subscribe(res => {
        // // console.log('Auth', res);
        this.AuthResponse = res;

        if (this.AuthResponse.Message === 'Invalid username or password.') {
          // alert('Invalid Username and Password.Please Enter Valid Username and Password');
          this.messageService.clear();
          this.messageService.add({ key: 'c1', sticky: true, severity: 'error', summary: 'Login Failed!', detail: 'Invalid Username and Password' });
          this.email = '';
          this.password = '';
          this.showLoader = false;

        }
        if (this.AuthResponse.Message === 'User authenticated') {



          if (this.AuthResponse.Role === 'Admin' || this.AuthResponse.Role === 'Super Admin') {
            let payloadReq = {
              "EmployeeKey": this.loginForm.controls['email'].value
            }
            this.app.generateToken(payloadReq).subscribe(res => {
              this.GenerateTokenResponse = res;
              localStorage.setItem('Token', this.GenerateTokenResponse.Token)
              sessionStorage.setItem("Login", "1");
              sessionStorage.setItem("email", payload.Email);
              sessionStorage.setItem("userInfo", JSON.stringify(this.AuthResponse));
              sessionStorage.setItem("Sid", this.AuthResponse.Sid)
              this.app.setLogin(true);
              this.showLoader = false
              // this.router.navigate(['managers-portal/site-management']);
              this.router.navigate(['tracker'])

            })

          } else {
            this.messageService.clear();
            this.messageService.add({ key: 'c1', sticky: true, severity: 'warn', summary: 'ACCESS DENIED!', detail: 'You are not authorized to access the portal.' });
            this.email = '';
            this.password = '';
            this.showLoader = false
          }

          // this.router.navigate(['tracker'])
        }

      })
    }



  }

}
