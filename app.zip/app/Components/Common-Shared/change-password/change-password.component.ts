import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from '../../../Services/app.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
// PrimeNG
import { MessageService } from 'primeng/api';
@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss']
})
export class ChangePasswordComponent implements OnInit {


  email = '';
  password = '';
  showLoginButton = false;
  validEmail = false;
  showNote = false;
  showPasswordMismatch = false;
  showLoader = false;
  AuthResponse: any;
  Message: any;

  showWelcomeMessage = true;

  loginForm: FormGroup;
  registerForm: FormGroup;

  constructor(
    private app: AppService,
    private router: Router,
    private fb: FormBuilder,
    private messageService: MessageService,
  ) {

  }

  ngOnInit() {


    if (this.app.isAuthenticated() != true) {
      setTimeout(() => {
        this.showWelcomeMessage = false;
      }, 5000)
      this.router.navigate([""]);


    } else {
      this.showWelcomeMessage = false;
      // this.router.navigate(['managers-portal/site-management']);

    }

    this.registerForm = this.fb.group({
      // email: ['', [Validators.required, Validators.email]],
      oldpassword: ['', [Validators.required]],
      password: ['', [Validators.required]],
      confirmPassword: ['', [Validators.required]],
    })

    this.email = sessionStorage.getItem('email');
  }





  // changePassword() {

  //   if (this.registerForm.controls['password'].value !== this.registerForm.controls['confirmPassword'].value) {
  //     this.Message = 'Password and Confirm Password Do Not Match'
  //     this.showPasswordMismatch = true
  //     setTimeout(() => {
  //       this.showPasswordMismatch = false
  //     }, 3000)
  //   } else {
  //     let payload = {

  //       "Email": this.email,
  //       "OldPassword": this.registerForm.controls['oldpassword'].value,
  //       "Password": this.registerForm.controls['password'].value,
  //     }
  //     this.app.changePassword(payload).subscribe(res => {
  //       console.log(res);
  //       this.AuthResponse = res;
  //       if (this.AuthResponse.Message === 'Password not matched') {
  //         // this.validEmail = false;
  //         // this.email
  //         // alert('Registration Successful. Please Login with your credentials');
  //         this.messageService.clear();
  //         this.messageService.add({ key: 'c1', sticky: true, severity: 'error', summary: 'Password Change Failed!', detail: 'Password changed failed as the old password did not match with the one you provided' });
  //         // this.router.navigate([''])
  //       } else if (this.AuthResponse.Message === 'Password should not match with old password') {
  //         // this.validEmail = false;
  //         // this.email
  //         // alert('Registration Successful. Please Login with your credentials');
  //         this.messageService.clear();
  //         this.messageService.add({ key: 'c1', sticky: true, severity: 'warn', summary: 'Password Change Failed!', detail: 'New Password should not match with Old password' });
  //         // this.router.navigate([''])
  //       }

  //       else if (this.AuthResponse.Message === 'Password Updated') {
  //         // this.validEmail = false;
  //         // this.email
  //         // alert('Registration Successful. Please Login with your credentials');
  //         this.messageService.clear();
  //         this.messageService.add({ key: 'c', sticky: true, severity: 'success', summary: 'Password Change Successful!', detail: 'You have successfully changed your password' });
  //         // this.router.navigate([''])
  //       }
  //     })
  //   }
  // }

  abortChangePassword() {
    this.router.navigate([''])
  }

}
