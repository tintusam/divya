import { Component, OnInit } from '@angular/core';
import { AppService } from '../../../Services/app.service';
import { Router } from '@angular/router'

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {
  displayNavbars = false;
  login: any;
  userInfo: any;
  GenerateTokenResponse: any;
  constructor(private app: AppService, private router: Router) {
    // if (this.app.isAuthenticated() == true) {
    //   this.displayNavbars = true;
    //   this.userInfo = JSON.parse(sessionStorage.getItem('userInfo'))
    // } else {
    //   this.displayNavbars = false;
    //   this.router.navigate([''])
    // }
  }
  // deleteSite() {
  //   let payload = {
  //     Sid: 8
  //   }
  //   this.app.awsDeteteSite(payload).subscribe(res => {
  //     // console.log('AWS', res)
  //   })
  // }
  ngOnInit() {
    this.userInfo = JSON.parse(sessionStorage.getItem('userInfo'))
    this.app.getLogin.subscribe(login => {
      // alert(login)
      if (this.app.isAuthenticated() == true) {
        this.displayNavbars = true;
        this.userInfo = JSON.parse(sessionStorage.getItem('userInfo'))
      } else {
        this.displayNavbars = false;
        this.router.navigate([''])
      }
      this.login = sessionStorage.getItem('Login') || login;
      if (login) {
        this.displayNavbars = true;
        this.userInfo = JSON.parse(sessionStorage.getItem('userInfo'))
      }
      // else {
      //   // alert(' You Need To Login First!!');
      //   this.router.navigate([''])
      // }
    })
  }


  logOut() {
    this.login = false;
    sessionStorage.clear();
    localStorage.clear();
    this.app.setLogin(false);
    // this.router.navigate(['managers-portal/site-management'])
    this.router.navigate(['']);
    this.displayNavbars = false;
  }

  generateToken() {
    // console.log("HELLLLO")
    this.app.generateToken({ "EmployeeKey": sessionStorage.getItem("email") }).subscribe(response => {
      this.GenerateTokenResponse = response;
      localStorage.setItem('Token', this.GenerateTokenResponse.Token)
    })
  }
}
