import { Component, OnInit, ViewChild } from '@angular/core';
import { AppService } from '../../../Services/app.service';
import { Router } from '@angular/router';

import { MessageService } from 'primeng/api';
@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.scss']
})
export class NotificationsComponent implements OnInit {

  public notificationList = [];
  public userId;
  public email;
  public CustId;
  public imm = [];
  public hr = [];
  public dai = [];
  Immediate = 'N';
  Hourly = 'N';
  Daily = 'N';
  flag = false;
  frequency: any;
  hide = [];
  index: any;
  empKey: string;
  frequency1: string;
  frequency2: string;
  Selected: any;
  sub_heading = "Please Provide your Email to Subscribe to this notification service";
  unsub_heading = "Are you sure you want to unsubscribe this notification service?";

  validSessionToken = true;
  intervalTimer: any;
  localStrToken: any;
  sessionEmail: any;
  @ViewChild('content', { static: false }) content: any;
  modalflag: boolean;
  heading: any;
  loggeInUserEmail = '';
  GenerateTokenResponse: any;

  constructor(private service: AppService, private router: Router, private messageService: MessageService,) { }

  ngOnInit() {
    this.localStrToken = localStorage.getItem('Token')
    this.loggeInUserEmail = sessionStorage.getItem('email');
    // console.log(this.localStrToken)
    let payloadReq = {
      Token: this.localStrToken
    }
    this.service.validateToken(payloadReq).subscribe(res => {
      // console.log(res);
      this.validSessionToken = true;

      this.intervalTimer = setInterval(() => {
        this.localStrToken = localStorage.getItem('Token')
        let payloadReq = {
          Token: this.localStrToken
        }
        this.service.validateToken(payloadReq).subscribe(res => {
          // console.log(res);
          this.validSessionToken = true
        }, error => {
          // console.log('Session Expired', error)
          this.validSessionToken = false;
          clearInterval(this.intervalTimer)
          this.service.setLogin(false);
        })
      }, 60000)
    }, error => {
      // console.log('Session Expired', error)
      this.validSessionToken = false;
      clearInterval(this.intervalTimer)
      this.service.setLogin(false);
    })

    // this.userId = this.service.userID || sessionStorage.getItem('UserId');
    this.email = null;
    this.sessionEmail = sessionStorage.getItem('email');
    this.frequency = new Set();
    this.modalflag = false;
    this.flag = false;
    //this.CustId = this.service.userCustId || sessionStorage.getItem('UserCustId');
    // // console.log("userId", this.userId);
    let payload = {
      "LoggedEmail": this.loggeInUserEmail
    }
    this.service.getAlertType(payload)
      .subscribe((res: any) => {
        // console.log("rs", res);

        this.notificationList = res;
        let i = 0;
        for (let item of res) {

          if (item.Subscription == "yes") {
            this.hide[i] = true;
            // // console.log(item.AlertType);
            this.imm[i] = (item.Immediate == "Y") ? true : false;
            this.hr[i] = (item.Hourly == "Y") ? true : false;
            this.dai[i] = (item.Daily == "Y") ? true : false;
          }
          else {
            this.hide[i] = false;
            //   this.imm[i] = false;
            this.hr[i] = false; //changed here pleased change if required
            this.dai[i] = true;
          }
          i++;
        }
      })
    this.Immediate = "N";
    this.Hourly = "Y";
    this.Daily = "Y";

  }



  checkEmail() {
    if (this.email == null || this.email == "") {
      alert('Please Provide Email');
      this.messageService.clear();
      this.messageService.add({ key: 'c2', sticky: true, severity: 'success', summary: 'ERROR', detail: 'Please Provide Email.' });
      // Change to Message Service
      return false;
    } else {
      this.flag = true;
      return true;
    }
  }

  Subscribe() {
    if (this.Immediate == "N" && this.Hourly == "N" && this.Daily == "N") {
      // alert("Select atleast one frequency");
      this.messageService.clear();
      this.messageService.add({ key: 'c2', sticky: true, severity: 'success', summary: 'ERROR', detail: 'Please Select al least one frequency.' });
      // Change to Message Service

    }
    else {
      // // console.log("item", i, " ", this.notificationList[i]["AlertType"]);

      let payload = {
        "AlertType": this.notificationList[this.index]["AlertType"],
        "Email": this.email,
        "AlertId": this.notificationList[this.index]["AlertId"],
        "Immediate": this.Immediate,
        "Hourly": this.Hourly,
        "Daily": this.Daily,
        "LoggedEmail": this.loggeInUserEmail

      }

      // console.log("payload", payload);
      this.service.CreateSubscription(payload)
        .subscribe(res => {
          // console.log(res);
          this.messageService.clear();
          this.messageService.add({ key: 'c1', sticky: true, severity: 'success', summary: 'Alert Subscribed', detail: 'You have successfully subscribed to the notification service.' });

          // alert("You have successfully subscribed to " + this.notificationList[this.index]["AlertType"] + "alert");
          this.ngOnInit();
        }, err => {
          // console.log(err);
          //alert(err["error"]["Message"]);
          this.messageService.clear();
          this.messageService.add({ key: 'c2', sticky: true, severity: 'error', summary: err["error"]["Message"], detail: '' }); //err["error"]["Message"]

        })
    }
  }

  GoToLogin() {
    sessionStorage.clear();
    localStorage.clear();
    this.service.setLogin(false);
    // this.router.navigate(['managers-portal/site-management'])
    this.router.navigate(['']);
    // window.location.reload();
  }


  unsubscribe(item) {
    // // console.log("item", item);
    let payload = {
      //"Email": item.SubscriptionId
      "Email": this.email
    }
    this.service.unsubscribeAlert(payload)
      .subscribe(res => {
        // console.log(res);
        // alert("You have successfully unsubscribed to " + item.AlertType + "alert");
        this.messageService.clear();
        this.messageService.add({ key: 'c1', sticky: true, severity: 'success', summary: 'Alert Unsubscribed', detail: 'You have successfully unsubscribed the notification service.' });

        this.ngOnInit();
      }, err => {
        // console.log(err);
        // alert(err["error"]["Message"]);
        this.messageService.clear();
        this.messageService.add({ key: 'c2', sticky: true, severity: 'error', summary: err["error"]["Message"], detail: '' }); //err["error"]["Message"]

      })

  }


  onClick(event) {

    //flag=true;

    if (event.target.checked && event.target.id == "Immediate") {
      this.Immediate = "Y";
      this.frequency.add("Immediate");
    }
    if (!event.target.checked && event.target.id == "Immediate") {
      this.Immediate = "N"
    }
    if (event.target.checked && event.target.id == "Hourly") {
      this.Hourly = "Y";
      this.frequency.add("Hourly");
    }
    if (!event.target.checked && event.target.id == "Hourly") {
      this.Hourly = "N"
    }
    if (event.target.checked && event.target.id == "Daily") {
      this.Daily = "Y";
      this.frequency.add("Daily");
    }
    if (!event.target.checked && event.target.id == "Daily") {
      this.Daily = "N"
    }

  }

  onSubscribe(item, i) {

    if (this.Immediate == "N" && this.Hourly == "N" && this.Daily == "N") {
      alert("Select atleast one frequency");
    } else {
      //this.heading = (item.Subscription == "yes") ? this.unsub_heading : this.sub_heading;
      this.heading = this.sub_heading;
      // console.log(item.Subscription," ",this.heading);
      this.modalflag = true;
      this.index = i;
      this.Selected = item;
      this.frequency2 = Array.from(this.frequency).join(',');
    }



  }

  onUnsubscribe(item) {
    this.frequency = new Set();;
    this.frequency2 = "";
    if (item.Immediate == "Y") {
      this.frequency.add("Immediate");
    }
    if (item.Hourly == "Y") {
      this.frequency.add("Hourly");
    }
    if (item.Daily == "Y") {
      this.frequency.add("Daily");
    }
    //this.heading = (item.Subscription == "yes") ? this.unsub_heading : this.sub_heading;
    this.heading = this.unsub_heading;
    // console.log(item.Subscription," ",this.heading);
    this.modalflag = true;
    this.email = item.Email;
    //this.flag = true;
    this.Selected = item;
    this.frequency2 = Array.from(this.frequency).join(',');
  }

  subscribeAlert() {
    //this.flag=true;  
    this.ngOnInit();
  }

  generateToken() {
    // console.log("HELLLLO")
    this.service.generateToken({ "EmployeeKey": sessionStorage.getItem("email") }).subscribe(response => {
      this.GenerateTokenResponse = response;
      localStorage.setItem('Token', this.GenerateTokenResponse.Token)
    })
  }

}