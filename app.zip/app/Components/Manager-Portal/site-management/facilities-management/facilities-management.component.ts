/// <reference path="../../../../../../node_modules/bingmaps/types/MicrosoftMaps/Microsoft.Maps.All.d.ts" />

import { Component, OnInit, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { environment } from '../../../../../environments/environment.prod';
import { AssetService } from '../../../../Services/asset.service';
import { MapService } from '../../../../Services/map.service';

// Added By ABhishek
import { ISasToken } from '../azure-storage/azureStorage';
import { BlobStorageService } from '../azure-storage/blob-storage.service';
import { from, Observable } from 'rxjs';
import { combineAll, map } from 'rxjs/operators';
// Abhishek Declaration ENds Here

interface IUploadProgress {
  filename: string;
  progress: number;
}

@Component({
  selector: 'app-facilities-management',
  templateUrl: './facilities-management.component.html',
  styleUrls: ['./facilities-management.component.scss']
})
export class FacilitiesManagementComponent implements OnInit {

  url: string
  highlight: Array<boolean> = [];
  public pos = [];
  public image;
  public selected;
  public index;
  public facilityName;
  public Location;
  public ZoneForm: FormGroup;
  public zones = [];
  public posx;
  public posy;
  public facilityList = [];
  public showImage = false;
  public showHeader = true;
  public searchText;
  click: any;
  public FacilityID;

  // Asset Image Related Variables
  fileInfo: any;
  uploadProgress$: Observable<IUploadProgress[]>;
  filesSelected = false;
  fileName: String;
  blobAccessUrl = environment.blobAccessUrl;
  
  fileUploadProgress: number;
  showLoader: boolean;
  showUploadComplete: boolean;
  imageRefUrl = '';
  showImageUploaded: boolean;
  GatewayList: any;
  public new = true;

  constructor(private fb: FormBuilder,
    private _dataService: MapService,
    private _assetservice: AssetService,
    private blobStorage: BlobStorageService,
    private el: ElementRef) {

    this.showImageUploaded = false;
    this.ZoneForm = this.fb.group({
      zoneName: [null, Validators.required],
      bleGatewaySno: [null, Validators.required]
    });
  }


  ngOnInit() {
    this.listAllGateWays();
    this.getAllFacilityList();
  }

  // Method to list All Gateways
  listAllGateWays(){
    this._assetservice.GetGatewayList()
    .subscribe(res => {
      this.GatewayList = res;
    })
  }

  // Method to list all facilities
  getAllFacilityList() {
    this._assetservice.GetAllFacilityList()
      .subscribe(res => {
        this.facilityList = res;
        console.log(this.facilityList);
      })
  }


  // Upload Asset Image Section Here =================================================
  onFileChange(event: any): void {
    this.showLoader = true;
    this.showUploadComplete = false;
    this.filesSelected = true;
    this.uploadProgress$ = from(event.target.files as FileList).pipe(
      map(file => this.uploadFile(file)), // Getting FIle Details HEre
      combineAll()
    );
  }

  uploadFile(file: File): Observable<IUploadProgress> {
    this.fileName = file.name;
    const accessToken: ISasToken = {
      container: 'facilityimage',
      filename: file.name,
      storageAccessToken: environment.SAS_Token,
      storageUri: environment.storageLink + environment.SAS_Token,
    };
    this.imageRefUrl = this.blobAccessUrl + this.fileName;
    console.log(this.imageRefUrl);
    return this.blobStorage
      .uploadToBlobStorage(accessToken, file)
      .pipe(map(progress => this.mapProgress(file, progress)));
  }

  private mapProgress(file: File, progress: number): IUploadProgress {
    if (progress === 100) {
      this.showLoader = false;
      this.showUploadComplete = true;
      this.showImage = true;
      this.filesSelected = false;
      this.showImage = true;

      this.showImageUploaded = true;
    }
    return {
      filename: file.name,
      progress: progress
    };
  }
  // Upload Asset Image Section ENds Here =============================================

  // Method to get location point 
  onGetLocationPoints(e) {
    this.ZoneForm.reset();
    if (this.imageRefUrl) {
      var svg = this.el.nativeElement.querySelector('#mySvg');
      var pt = svg.createSVGPoint();
      pt.x = e.clientX; //x position within the element.
      pt.y = e.clientY;
      var svgP = pt.matrixTransform(svg.getScreenCTM().inverse());
      this.posx = svgP.x;
      this.posy = svgP.y;
      console.log(this.posx, this.posy)
    }
  }

 onHighlightOption(i, options) {
    this.highlight.fill(false);
    this.highlight[i] = !this.highlight[i]
    this.selected = options;
  }

  onGetFloorImage(floor) {
    this.imageRefUrl = floor.ImageUrl;
    this.zones = floor.Zones;
    this.facilityName = floor.FacilityName;
    this.Location = floor.Location;
    this.FacilityID = floor.FacilityID || '';
    this.showImage = true;
  }

 onSaveZones(post) {
    if (post.zoneName && post.bleGatewaySno) {
      this.pos.push({ x: this.posx, y: this.posy });
      this.zones.push({
        ZoneName: post.zoneName,
        GatewaySlNo: post.bleGatewaySno,
        Top: this.posy,
        Left: this.posx
      });
      this.onUpdateFacility()
    }
  }

  resetForm() {
    this.ZoneForm.reset();
  }

  onCreateFacility() {
    if (!this.facilityName) {
      window.alert('Provide a name for the facility');
    }
    else if (!this.imageRefUrl) {
      window.alert('Provide a facility map');
    }
    else {
      const payload = {
        FacilityName: this.facilityName,
        Location: this.Location,
        Zones: this.zones,
        ImageUrl: this.imageRefUrl,
      }
      //console.log(payload);
      this._assetservice.CreateFacility(payload)
        .subscribe(res => {
          //console.log(res)
          window.alert('Facility Created');
          this.Abort();
          this.showImage = false;
          this.getAllFacilityList();
        });
    }
  }

  public Abort() {
    this.facilityName = '';
    this.Location = '';
    this.imageRefUrl = '';
    this.pos = [];
    this.zones = [];
    this.showImage = false;
  }

  onUpdateFacility() {
    const payload = {
      FacilityName: this.facilityName,
      Location: this.Location,
      Zones: this.zones,
      ImageUrl: this.imageRefUrl,
      FacilityID: this.FacilityID
    }
    //console.log(payload);
    this._assetservice.UpdateFacility(payload)
      .subscribe(res => {
        window.alert('Facility Updated');
        this.getAllFacilityList();
        this.Abort();
      });
  }

  onDeleteFacility(FacId) {
    var r = confirm("Delete Facility?");
    if (r == true) {
      this._assetservice.DeleteFacility(FacId)
        .subscribe(res => {
          this.getAllFacilityList();
          this.Abort();
          this.new = false;
        })
    }
  }

  onRefreshPlan() {
    this.showImageUploaded = false;
    this.ZoneForm = this.fb.group({
      zoneName: [null, Validators.required],
      bleGatewaySno: [null, Validators.required]
    });
    this.facilityList = [];
    this.getAllFacilityList();
  }

  OnEdit(zone, i) {
    this.selected = zone;
    this.index = i;
  }
}
