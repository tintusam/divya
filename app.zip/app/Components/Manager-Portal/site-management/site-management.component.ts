import { Component, OnInit } from '@angular/core';
import * as atlas from 'azure-maps-control';
import * as atlasTool from 'azure-maps-drawing-tools';
import * as atlasService from 'azure-maps-rest';
import { AtlasMapComponent } from '@acaisoft/angular-azure-maps';
import { environment } from 'src/environments/environment.prod';
import { AppService } from '../../../Services/app.service'
import { MessageService } from 'primeng/api';
@Component({
  selector: 'app-site-management',
  templateUrl: './site-management.component.html',
  styleUrls: ['./site-management.component.scss']
})
export class SiteManagementComponent implements OnInit {
  term: string;
  storeList: any;
  showCreateSite = false;
  SiteClicked: any;
  SelectedStore: any;
  //map 
  key: string = environment.azureMapsPrimaryKey;
  authTypeValue = 'subscriptionKey';
  subscriptionKey: any
  map: any;
  position;
  marker;
  eventClick: any;
  searchText;
  view = true;
  sessionEmail = '';
  sessionSid = ''
  tempStoreList: any;
  public drawingManager: any;

  // public siteList:any=new Array();
  locationInfo: any;
  datasource; client: any; popup: any; searchInput: string; resultsPanel: any; searchInputLength: any; centerMapOnResults;

  //The minimum number of characters needed in the search input before a search is performed.
  minSearchInputLength = 2;

  //The number of ms between key strokes to wait before performing a search.
  keyStrokeDelay = 150;
  responseSearch = [];

  public config = {
    'zoom': 1.5,
    'center': [20, 20],
    'interactive': true,
  };
  location: string;
  lat: any;
  lng: any;
  map1: atlas.Map;
  country: any;
  state: any;
  selected: boolean;
  toolbar: atlasTool.control.DrawingToolbar;

  constructor(private app: AppService, private messageService: MessageService, ) {
    this.storeList = undefined
  }

  ngOnInit() {
    this.sessionEmail = sessionStorage.getItem("email");
    this.sessionSid = sessionStorage.getItem("Sid")
    this.getAllSites();
    this.SiteClicked = [];
    this.SiteClicked[0] = true;
    this.selected = false;
    this.responseSearch = [];



  }

  deleteSite(Sid) {
    let payload = {
      "Sid": Sid
    }
    this.app.deleteSite(payload).subscribe(res => {
      // alert(res);
      this.ngOnInit()
    }, err => {
      if (err.error.Message == 'Associates attached with site') {
        alert('Cannot Delete the Site as Associates are attached to it. Please Contact Admin..')
      }
    })
  }


  GetMap(Store) {
    //Initialize a map instance.
    this.map = new atlas.Map('myMap', {
      center: [parseFloat(Store.Latitude), parseFloat(Store.Longitude)],
      zoom: 14,
      view: 'Auto',

      //Add your Azure Maps subscription key to the map SDK. Get an Azure Maps key at https://azure.com/maps
      authOptions: {
        authType: atlas.AuthenticationType.subscriptionKey,
        subscriptionKey: 'i6AdgV8rulpPXVcK-6iWYY_PzomZjHXBijEXYgmFR2o'
      }
    });
    //Store a reference to the Search Info Panel.
    this.resultsPanel = document.getElementById("results-panel");

    //Add key up event to the search box. 
    // this.searchInput = document.getElementById("search-input");
    // this.searchInput.addEventListener("keyup", searchInputKeyup);

    //Create a popup which we can reuse for each result.
    this.popup = new atlas.Popup();

    //Wait until the map resources are ready.
    this.map.events.add('ready', () => {

      //Add the zoom control to the map.
      this.map.controls.add(new atlas.control.ZoomControl(), {
        position: 'top-right'
      });

      //Create a data source and add it to the map.
      this.datasource = new atlas.source.DataSource();
      this.map.sources.add(this.datasource);

      //Add a layer for rendering the results.
      var searchLayer = new atlas.layer.SymbolLayer(this.datasource, null, {
        iconOptions: {
          image: 'pin-round-darkblue',
          anchor: 'center',
          allowOverlap: true
        }
      });
      this.map.layers.add(searchLayer);

      //Add a click event to the search layer and show a popup when a result is clicked.
      this.map.events.add("click", searchLayer, function (e) {
        //Make sure the event occurred on a shape feature.
        if (e.shapes && e.shapes.length > 0) {
          this.showPopup(e.shapes[0]);
        }
      });
    });


    //   var marker = new atlas.HtmlMarker({
    //     color: 'DodgerBlue',
    //     text: '50',
    //     position: [0, 0],
    //     popup: new atlas.Popup({
    //         content: '<div style="padding:10px">Hello World</div>',
    //         pixelOffset: [0, -30]
    //     })
    // });

    // this.map.markers.add(marker);
  }


  searchInputKeyup(event: KeyboardEvent) {
    this.selected = false;
    //// console.log('EVENT: ' + event.target['value']);
    this.responseSearch = [];
    // this.searchInput = '';
    this.searchInput = event.target['value'];
    // // console.log('EVENT2: ' + (this.searchInput.length));
    this.centerMapOnResults = false;
    if (this.searchInput.length >= this.minSearchInputLength) {
      if (event.keyCode === 13) {
        this.centerMapOnResults = true;
      }
      //Wait 100ms and see if the input length is unchanged before performing a search. 
      //This will reduce the number of queries being made on each character typed.
      // setTimeout(function () {

      //   if (this.searchInputLength === this.searchInput.length) {
      //     this.search();
      //   }
      // }, this.keyStrokeDelay);
      this.search();
    } else {
      this.resultsPanel = '';
    }
    this.searchInputLength = this.searchInput.length;
    // // console.log(this.searchInputLength);
  }

  search() {
    //Remove any previous results from the map.
    this.datasource = {};
    this.popup.close();
    this.resultsPanel = '';
    // this.resultsPanel.innerHTML = '';

    //Use SubscriptionKeyCredential with a subscription key
    var subscriptionKeyCredential = new atlasService.SubscriptionKeyCredential(atlas.getSubscriptionKey());

    //Use subscriptionKeyCredential to create a pipeline
    var pipeline = atlasService.MapsURL.newPipeline(subscriptionKeyCredential);

    //Construct the SearchURL object
    var searchURL = new atlasService.SearchURL(pipeline);

    var query = this.searchInput;
    searchURL.searchPOI(atlasService.Aborter.timeout(10000), query, {
      lon: this.map.getCamera().center[0],
      lat: this.map.getCamera().center[1],
      maxFuzzyLevel: 4,
      view: 'Auto'
    }).then((results) => {

      //Extract GeoJSON feature collection from the response and add it to the datasource
      var data = results.geojson.getFeatures();
      //// console.log('RESPONSE: ' + JSON.stringify(data));
      this.datasource = (data);

      if (this.centerMapOnResults) {
        this.map.setCamera({
          bounds: data.bbox
        });
      }
      // // console.log(data);
      //Create the HTML for the results list.
      var html = [];
      this.responseSearch = data.features;
      // for (var i = 0; i < data.features.length; i++) {
      //   var r = data.features[i];
      //   html.push('<li onclick="itemClicked(\'', r.id, '\')" onmouseover="itemHovered(\'', r.id, '\')">')
      //   html.push('<div class="title">');
      //   if (r.properties.poi && r.properties.poi.name) {
      //     html.push(r.properties.poi.name);
      //   } else {
      //     html.push(r.properties.address.freeformAddress);
      //   }
      //   html.push('</div><div class="info">', r.properties.type, ': ', r.properties.address.freeformAddress, '</div>');
      //   if (r.properties.poi) {
      //     if (r.properties.phone) {
      //       html.push('<div class="info">phone: ', r.properties.poi.phone, '</div>');
      //     }
      //     if (r.properties.poi.url) {
      //       html.push('<div class="info"><a href="http://', r.properties.poi.url, '">http://', r.properties.poi.url, '</a></div>');
      //     }
      //   }
      //   html.push('</li>');
      //   // this.resultsPanel.innerHTML = html.join('');
      // }

    });

  }

  showClickedPlace(response) {
    // // alert(coordinates);
    // // console.log("response", response);
    this.searchText = response.properties.poi.name + ',' + response.properties.address.freeformAddress;
    // // console.log("searchtext: " + this.searchText);
    this.selected = true;

    this.location = response.properties.poi.name + ',' + response.properties.address.freeformAddress;
    this.lat = response.geometry.coordinates[1];
    this.lng = response.geometry.coordinates[0];

    this.country = response.properties.address.country;
    this.state = response.properties.address.countrySubdivision;

    // // console.log(this.country, this.state);

    //  this.service.getTimezone(this.lat, this.lng).subscribe(res => {
    //    // console.log("Timezone res", res["TimeZones"][0]["ReferenceTime"]["Tag"]);
    //    this.timezone = res["TimeZones"][0]["ReferenceTime"]["Tag"];
    //  });;

    this.map = new atlas.Map('myMap', {
      center: [response.geometry.coordinates[0], response.geometry.coordinates[1]],
      zoom: 14,
      view: 'Auto',
    });

    // // console.log(this.map.getCamera());


    //Wait until the map resources are ready.
    this.map.events.add('ready', () => {
      this.toolbar = new atlasTool.control.DrawingToolbar({
        position: 'top-right',
        style: 'dark',
        buttons: ["draw-point", "edit-geometry"]
      });
      //Create an instance of the drawing manager and display the drawing toolbar.
      this.drawingManager = new atlasTool.drawing.DrawingManager(this.map, {
        toolbar: this.toolbar
      });
      // // console.log(this.toolbar.getOptions());

    });


  }

  clear() {
    this.searchText = "";
    this.location = "";
    this.responseSearch = [];
  }

  SetSite(store) {
    // console.log("hai", this.showCreateSite);
    this.SelectedStore = store;
    this.selected = false;
    this.view = true;
    this.app.setSiteId(this.SelectedStore.Sid)
    sessionStorage.setItem("SiteId", this.SelectedStore.Sid);
    // // console.log('STORE', store)
    this.lat = this.SelectedStore.Latitude;
    this.lng = this.SelectedStore.Longitude;

    this.country = this.SelectedStore.Country;
    this.state = this.SelectedStore.State;

    this.location = this.SelectedStore.Location;

    let time = 0;
    if (this.showCreateSite)
      time = 1000;

    setTimeout(() => {

      this.GetMap(store);


      this.map = new atlas.Map('myMap', {
        center: [parseFloat(this.SelectedStore.Longitude), parseFloat(this.SelectedStore.Latitude)],
        zoom: 14,
        view: 'Auto',
      });


      // // console.log(this.map.getCamera());

      this.map.events.add("ready", () => {


        this.marker = new atlas.HtmlMarker({
          color: 'blue',
          // text: '10',
          position: [parseFloat(this.lng), parseFloat(this.lat)]
        });
        // // console.log("marker", this.marker);
        this.map.markers.add(this.marker);
        // // console.log("markers", this.map.markers);

      });

    }, time);

    // let payload = {
    //   "GeofenceName": this.SelectedStore.Geofencename
    // }

    // // console.log(payload);

    // this.app.getGeofence(JSON.stringify(payload)).subscribe(res => {

    //   // console.log("GEOFENCE DATA: " + JSON.stringify(res));
    //   // console.log(res["res"][0]["type"]);

    //   this.map.events.add("ready", () => {

    //     /*Create a data source and add it to the map*/
    //     var dataSource = new atlas.source.DataSource();
    //     this.map.sources.add(dataSource);

    //     /*Create a rectangle*/
    //     dataSource.add(new atlas.Shape(new atlas.data.Feature(
    //       new atlas.data.Polygon(res["res"][0]["coordinates"])
    //     )));

    //     /*Create and add a polygon layer to render the polygon to the map*/
    //     this.map.layers.add(new atlas.layer.PolygonLayer(dataSource, null, {
    //       fillColor: "rgba(55, 134, 165, 0.774)",
    //       fillOpacity: 0.7
    //     }), 'labels');

    //   });

    // },
    //   err => {
    //     // console.log(err);
    //   });


  }

  getAllSites() {
    this.app.GetAllStore().subscribe(res => {
      this.storeList = [];
      // this.storeList = res;
      this.tempStoreList = res;


      // // Addedd this for US Foods

      if (this.sessionSid == '0') {
        this.storeList = this.tempStoreList;
      } else {
        for (let item of this.tempStoreList) {
          // console.log(item)
          if (item.Sid == parseInt(this.sessionSid)) {
            this.storeList.push(item)
          }
        }
      }



      // US FOODS Update Ends here

      // this.SelectedStore = this.storeList[0];
      setTimeout(() => {
        this.SetSite(this.storeList[0]);
      }, 1500)

      // this.SelectedStore = this.storeList[0];
      // this.app.setSiteId(this.SelectedStore.Sid);
      // sessionStorage.setItem("SiteId", this.SelectedStore.Sid)
    })
  }

  onSiteAdd(event) {
    this.showCreateSite = false;
    this.ngOnInit();
  }



  editSite() {
    // console.log(this.SelectedStore);

    if (this.selected) {
      var source = this.drawingManager.getSource();
      // console.log("GEOFENCE DATA: " + JSON.stringify(source.toJson(), null, '    '));


      let i;
      if (source.toJson().features[0].geometry.type == "Point") {
        this.lng = source.toJson().features[0].geometry.coordinates[0];
        this.lat = source.toJson().features[0].geometry.coordinates[1];
        i = 1;
      }
      // else {
      //   this.lng = source.toJson().features[1].geometry.coordinates[0];
      //   this.lat = source.toJson().features[1].geometry.coordinates[1];
      //   i = 0;
      // }
      // let geopayload = source.toJson().features[i].geometry;

      //Add Geofence 

      //  geopayload["GeofenceName"] = this.SelectedStore.StoreId;
      // console.log(geopayload);

      // this.app.addGeofence(geopayload)
      //   .subscribe(res => {
      //     // console.log(res);
      //     this.drawingManager.setOptions({
      //       toolbar: null
      //     });
      //   }, err => {
      //     // console.log(err);
      //   });

    }
    // // console.log(geopayload.coordinates[0][0][0]);

    let payload = {
      "StoreType": this.SelectedStore.Type,
      "StoreId": this.SelectedStore.StoreId,
      "Location": this.location,
      "Description": "des",
      "Latitude": this.lat,
      "Longitude": this.lng,
      "StoreManager": this.SelectedStore.StoreManager,
      "ManagerEmail": this.SelectedStore.ManagerEmail,
      "Geofencename": this.SelectedStore.StoreId,
      "State": this.state,
      "Country": this.country,
      // "TempThreshold": this.SelectedStore.TempThreshold.toString(),
      // "PeopleLimit": this.SelectedStore.PeopleLimit.toString(),
      "TempThreshold": 0,
      "PeopleLimit": 0,
      "Sid": this.SelectedStore.Sid.toString()
    }
    // console.log("payload", payload);
    this.app.editSite(payload)
      .subscribe(res => {
        // console.log(res);
        // alert("Site successfully updated");
        this.location = "";
        this.view = true;
        this.ngOnInit();
        this.messageService.clear();
        this.messageService.add({ key: 'c', severity: 'success', summary: 'Site Update Successful!!', life: 5000, closable: true, detail: 'The Site has been updated/edited successfully..' });
        // sessionStorage.setItem('SiteId',this.SId)
      }, err => {
        // console.log(err);
      });




  }

}


