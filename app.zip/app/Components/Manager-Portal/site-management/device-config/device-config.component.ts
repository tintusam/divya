import { Component, OnInit } from '@angular/core';
import { AppService } from '../../../../Services/app.service'
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-device-config',
  templateUrl: './device-config.component.html',
  styleUrls: ['./device-config.component.scss']
})
export class DeviceConfigComponent implements OnInit {
  isCheckedBuzzer = false;
  isCheckedVibration = true;
  isCheckedLed = true;
  EditConfig = false;
  deviceRSSI = 99;
  newRSSI = 44;
  SiteId: any;
  sessionSiteId: any;
  showLoader = false;
  GatewayList: any;
  newGatewayId = '';
  setGateway: any;
  newGatewayStatus = false
  newStatusString = '';
  newGatewayActivityState = 'Choose Gateway State';
  constructor(private app: AppService, private messageService: MessageService) {
    this.sessionSiteId = sessionStorage.getItem('SiteId')
  }
  ngOnInit() {
    this.GatewayList = []
    this.app.getSiteId.subscribe(siteId => {
      // this.ngOnInit()

      this.showLoader = true;

      this.SiteId = siteId || this.sessionSiteId;
      let payload = {
        "Sid": this.SiteId
      }
      this.app.getGatewayList(payload).subscribe(res => {
        // this.list = res;
        this.GatewayList = res
        this.showLoader = false;
      })


      this.app.getAvailableDevices(payload).subscribe(res => {
        // this.availableWearableList = res;
        // console.log(res);
        // console.log(this.availableWearableList)
      })
    })
  }

  changeStateforGateway(gatewayId) {
    let payload = {
      "gatewayId": gatewayId,
      "newState": this.newGatewayActivityState
    }

    // console.log(payload)
  }

  addGateway() {
    let payload = {
      "gatewayId": this.newGatewayId,
      "Sid": this.SiteId
    }

    this.app.addGateway(payload).subscribe(res => {
      this.messageService.clear();
      this.messageService.add({ life: 4000, sticky: false, severity: 'success', summary: 'Gateway Added', detail: 'The Gateway is onboarded on the Site.' });
      this.ngOnInit();
      this.newGatewayId = ""
    })
    // console.log('New Gateway ', payload)
  }

  editGateway() {

    let payload = {
      "gatewayId": this.setGateway.gatewayId,

      "State": this.newGatewayActivityState
    }
    //console.log(payload)
    this.app.editGateway(payload).subscribe(res => {
      this.messageService.clear();
      this.messageService.add({ life: 4000, sticky: false, severity: 'success', summary: 'Gateway Status Modified', detail: 'The Gateway Status is modified succesfully.' });
      this.ngOnInit()
    }, error => {
      this.messageService.clear();
      this.messageService.add({ life: 4000, sticky: false, severity: 'error', summary: 'Gateway Modification Failed', detail: 'The Gateway Status is not modified.' });
      this.ngOnInit()
    })
    this.newGatewayActivityState = 'Choose Gateway State';
  }

  setNewStatusSting() {
    this.newGatewayStatus = this.setGateway.Status
    // console.log("Inside", this.newGatewayStatus)
    if (this.newGatewayStatus) {
      // console.log("Inside IF")
      this.newStatusString = 'Online'
    } else {
      // console.log("Inside Else")
      this.newStatusString = 'Offline'
    }
  }

  deleteGateway() {
    let payload = {
      "gatewayId": this.setGateway.gatewayId
    }
    this.app.deleteGateway(payload).subscribe(res => {
      // console.log(res);
      this.ngOnInit()
    })
  }
}






