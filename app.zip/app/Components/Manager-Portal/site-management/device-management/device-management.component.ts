import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { AppService } from '../../../../Services/app.service'
import { environment } from '../../../../../environments/environment.prod'
import { from, Observable } from 'rxjs';
import { combineAll, map } from 'rxjs/operators';
import { ISasToken } from '../azure-storage/azureStorage';
import { BlobStorageService } from '../azure-storage/blob-storage.service';
interface IUploadProgress {
  filename: string;
  progress: number;
};

import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-device-management',
  templateUrl: './device-management.component.html',
  styleUrls: ['./device-management.component.scss']
})
export class DeviceManagementComponent implements OnInit {


  fileInfo: any;
  showLoader2 = false;
  list: any;
  @Output() onExit = new EventEmitter<any>();
  uploadProgress$: Observable<IUploadProgress[]>;
  filesSelected = false;
  fileName: String;
  setAssociate: any;

  showLoader = false;
  showCreateFloor = false;
  fileUploadSuccess = false;
  showUploadComplete = false;
  showUploader = true
  storageUrl = '';
  showButton = false;
  showErrorCsv = false;
  SiteId: any;
  sessionSiteId: any
  fileExtenstion: any;
  showInvalidFileExtensionMsg = false;
  fileType: String = '';
  SelectedReason: String = 'Select Reason for Change';
  SelectedWearable: String = 'Select Wearable from the list';
  newMacId: String = 'Select New Device From Dropdown Above';
  newWearableDeviceId: any;
  searchWearable = '';
  WearableSearchTerm = ''
  availableWearableList: any;

  // Wearable COnfig
  isCheckedBuzzer = false;
  isCheckedVibration = false;
  isCheckedLed = false;
  EditConfig = false;
  deviceRSSI = 0;
  newRSSI = 0;
  JSONRes: any
  constructor(
    private app: AppService,
    private blobStorage: BlobStorageService,
    private messageService: MessageService
  ) {
    this.sessionSiteId = sessionStorage.getItem('SiteId')
  }

  ngOnInit() {
    // this.availableWearableList = [];
    this.app.getSiteId.subscribe(siteId => {
      this.availableWearableList = []
      // this.ngOnInit()
      this.showLoader = true;
      this.list = []
      this.SiteId = siteId || this.sessionSiteId;
      let payload = {
        "Sid": this.SiteId
      }
      this.app.getAssociateList(payload).subscribe(res => {
        this.list = res;
        this.showLoader = false;
      })

      this.app.getAllSiteDevices(payload).subscribe(res => {
        this.availableWearableList = res;
        // console.log(res);
        // console.log(this.availableWearableList)
      })
      //  Also Call Wearable Configuration Here
      this.app.getWearableConfigurations(payload).subscribe(res => {
        // console.log('Configurations ', res);
        this.JSONRes = res
        this.isCheckedBuzzer = this.JSONRes.Buzzer;
        this.isCheckedVibration = this.JSONRes.Vibration;
        this.isCheckedLed = this.JSONRes.Led;
        this.deviceRSSI = this.JSONRes.Rssi;
        this.newRSSI = this.deviceRSSI;
      })
    })
  }
  getWearableConfigurations() {
    let payload = {
      Sid: this.SiteId
    }
    this.app.getWearableConfigurations(payload).subscribe(res => {
      // console.log('Configurations ', res);
      this.JSONRes = res
      this.isCheckedBuzzer = this.JSONRes.Buzzer;
      this.isCheckedVibration = this.JSONRes.Vibration;
      this.isCheckedLed = this.JSONRes.Led;
      this.deviceRSSI = this.JSONRes.Rssi;
      this.newRSSI = this.deviceRSSI;
    })
  }
  EditWearableConfiguration() {
    // check maximum RSSI is 90
    if (this.newRSSI < 20 || this.newRSSI > 65) {
      this.messageService.clear();
      this.messageService.add({ key: 'tl4', life: 8000, sticky: true, severity: 'error', summary: 'Value Out Of Range', detail: 'The Specified RSSI Value is out of range.The RSSI Value should be between 20 and 65' });
    } else {
      let payload = {
        "Rssi": this.newRSSI,
        "Led": this.isCheckedLed,
        "Vibration": this.isCheckedVibration,
        "Buzzer": this.isCheckedBuzzer,
        "Sid": this.SiteId
      }

      // console.log("New Wearable Configuration: ", payload)

      this.app.updateWearableConfiguration(payload).subscribe(res => {
        // console.log(res);
        this.messageService.add({ severity: 'success', summary: 'Configuration Modified', detail: 'Device Configuration was modified Successfully!' });

        this.getWearableConfigurations();
        this.EditConfig = false;
      }, err => {
        // console.log(err)
        this.EditConfig = false;
        this.messageService.add({ severity: 'error', summary: 'Modification Failed', detail: 'Device Configuration was not modified!' });
      })
    }

  }

  SetAssociate(emp) {
    // alert(JSON.stringify(emp))
    this.setAssociate = emp
  }
  deleteAssociate() {
    let payload = {
      "Email": this.setAssociate.Email,
      "Sid": null
    }
    this.app.deleteAssociate(payload).subscribe(res => {
      // console.log(res);
      let payload2 = {
        "Sid": this.SiteId
      }
      this.app.getAssociateList(payload2).subscribe(res => {
        this.list = res;
        this.showLoader = false;
        this.onExit.emit(false);
      })
    }, error => {
      console.log(error);
    }
    )
  }

  deleteAllAssociates() {
    // alert('SiteId' + this.SiteId);
    let payload = {
      "Email": null,
      "Sid": this.SiteId
    }
    this.app.deleteAllAssociate(payload).subscribe(res => {
      // console.log(res);
      let payload2 = {
        "Sid": this.SiteId
      }
      this.app.getAssociateList(payload2).subscribe(res => {
        this.list = res;
        this.showLoader = false;
        this.onExit.emit(false);
      })
    }, err => {
      // console.log(err)
    })
  }
  onFileChange(event: any): void {
    this.showLoader = true;
    this.showUploadComplete = false;
    this.filesSelected = true;

    this.uploadProgress$ = from(event.target.files as FileList).pipe(
      map(file => this.uploadFile(file)), // Getting FIle Details HEre
      combineAll()
    );


  }

  uploadFile(file: File): Observable<IUploadProgress> {

    // console.log('FILE TYPE CHECK HERE: ', file)
    this.fileType = file.type.toString();
    // console.log(typeof (this.fileType))
    // console.log('FILE TYPE CHECK HERE: ', this.fileType, typeof (this.fileType))
    if (!(this.fileType === "text/csv" || this.fileType === "application/vnd.ms-excel")) {
      // alert('Please Choose a file with .csv Extension only.');
      this.showLoader = false;
      this.showButton = false;
      this.showInvalidFileExtensionMsg = true;
      this.messageService.clear();
      this.messageService.add({ key: 'c1', sticky: true, severity: 'error', summary: 'INVALID FILE FORMAT', detail: 'Please Choose a file with .csv extension only' });
    } else {
      // console.log(file.type); // Check File Extension Here
      this.fileName = file.name;
      this.storageUrl = environment.blobAccessUrl + this.fileName + environment.SAS_Token

      const accessToken: ISasToken = {
        container: 'wearablecsvupload',
        filename: file.name,
        storageAccessToken: environment.SAS_Token,
        // tslint:disable-next-line:max-line-length
        // storageUri: 'https://titanstorageaccnt.blob.core.windows.net/' + AppSetting.SAS_Token,
        storageUri: environment.storageLink + environment.SAS_Token,
        // Add SAS Token After .net/ --> If the token Expires in Future
      };

      // // console.log(accessToken.storageUri);
      return this.blobStorage
        .uploadToBlobStorage(accessToken, file)
        .pipe(map(progress => this.mapProgress(file, progress)));
    }
  }
  private mapProgress(file: File, progress: number): IUploadProgress {
    // console.log(progress);

    if (progress === 100) {
      this.showLoader = false;
      this.showUploadComplete = true;
      this.fileUploadSuccess = true;
      this.filesSelected = false;
      this.showButton = true;
    }
    // console.log(progress);
    return {
      filename: file.name,
      progress: progress,
      // storageUri: this.storageUri
    };
  }


  UploadCSV() {

    // Check File Extension here first
    let payload = {
      "sourceBlobFileName": this.fileName,
      "Sid": this.SiteId
    }
    this.showLoader2 = true;
    // console.log(payload);
    this.app.wearableCsvUpload(payload).subscribe(res => {
      // console.log('CSV', res);
      this.showLoader2 = false;
      this.showErrorCsv = false;
      this.ngOnInit();
      this.onExit.emit(false);
    }, error => {
      // console.log(error);
      this.showLoader2 = false;
      this.showErrorCsv = true;
      this.showLoader = false;
      this.showButton = false;
    })
  }

}
