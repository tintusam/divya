import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from '../../../Services/app.service'
@Component({
  selector: 'app-manager-portal-landing-page',
  templateUrl: './manager-portal-landing-page.component.html',
  styleUrls: ['./manager-portal-landing-page.component.scss']
})
export class ManagerPortalLandingPageComponent implements OnInit {
  validSessionToken = true;
  intervalTimer: any;
  localStrToken: any;
  GenerateTokenResponse: any;


  constructor(private router: Router, private app: AppService) { }

  ngOnInit() {
    // this.router.navigate(['/managers-portal/site-management'])

    this.localStrToken = localStorage.getItem('Token')
    // console.log(this.localStrToken)
    let payload = {
      Token: this.localStrToken
    }
    this.app.validateToken(payload).subscribe(res => {
      // console.log(res);
      this.validSessionToken = true;

      this.intervalTimer = setInterval(() => {
        this.localStrToken = localStorage.getItem('Token')
        // console.log(this.localStrToken)
        let payload = {
          Token: this.localStrToken
        }

        // console.log("Please Check Payload Here", payload)

        this.app.validateToken(payload).subscribe(res => {
          // console.log(res);
          this.validSessionToken = true
        }, error => {
          // console.log('Session Expired', error)
          this.validSessionToken = false;
          clearInterval(this.intervalTimer)
          this.app.setLogin(false);
        })
      }, 60000)
    }, error => {
      // console.log('Session Expired', error)
      this.validSessionToken = false;
      clearInterval(this.intervalTimer)
      this.app.setLogin(false);
    })

    // 120000

  }
  GoToLogin() {
    sessionStorage.clear();
    localStorage.clear();
    this.app.setLogin(false);
    // this.router.navigate(['managers-portal/site-management'])
    this.router.navigate(['']);
    // window.location.reload();
  }

  generateToken() {

    this.app.generateToken({ "EmployeeKey": sessionStorage.getItem("email") }).subscribe(response => {
      this.GenerateTokenResponse = response;
      localStorage.clear();
      localStorage.setItem('Token', this.GenerateTokenResponse.Token)
    })
  }



}
