
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
// const ApiUrl = "https://covwebapi.azurewebsites.net/api/";

// const ApiUrl = "https://covwebapim.azure-api.net/CovWebApi/";
// const ApiUrl = "https://usfoodswebfunction.azurewebsites.net/api/";

// USFOOD ACTUAL API
// const ApiUrl = "https://usfoodsapim.azure-api.net/UsFoodsWebFunction/";

// USFOOD TEST API
const ApiUrl = "https://usfooodstestweb.azurewebsites.net/api/";

const CustomHeaders = { 'Ocp-Apim-Subscription-Key': 'b49c1abc86594417b2491f3aac53ea8d' }

// POST https://usfoodsapim.azure-api.net/UsFoodsWebFunction/AuthenticateUser HTTP/1.1
// Host: usfoodsapim.azure-api.net
// Ocp-Apim-Subscription-Key: b49c1abc86594417b2491f3aac53ea8d
// Ocp-Apim-Trace: true



@Injectable({
  providedIn: 'root'
})


export class AppService {

  constructor(private http: HttpClient) {
    // console.log('App Service Initialized......')
  }
  // For Login Sessions
  private loginSource = new BehaviorSubject(false);
  getLogin = this.loginSource.asObservable();

  setLogin(log: boolean) {
    this.loginSource.next(log);
  }

  isAuthenticated() {
    if (sessionStorage.getItem("Login")) {
      return true;
    }
    else {
      return false;
    }
  }


  private SiteId = new BehaviorSubject('');
  getSiteId = this.SiteId.asObservable();

  setSiteId(log: string) {
    this.SiteId.next(log);
  }

  private EmailId = new BehaviorSubject('');
  getEmailId = this.EmailId.asObservable();

  setEmailId(log: string) {
    this.EmailId.next(log);
  }

  setNavbar(log: boolean) {
    this.DisplayNavbar.next(log);
  }

  private DisplayNavbar = new BehaviorSubject(false);
  getNavbar = this.EmailId.asObservable();

  getAllCountries() {
    return this.http.get(ApiUrl + 'GetAllCountries', { headers: CustomHeaders })
  }

  // https://restcountries.eu/rest/v2/region/asia
  getAllRegions() {
    return this.http.get(' https://restcountries.eu/rest/v2/region/asia')
  }

  createSite(params) {
    // console.log("create Site data ", JSON.stringify(params));
    return this.http.post(ApiUrl + 'CreateStore', JSON.stringify(params));
  }

  editSite(params) {
    // console.log("edit Site data ", JSON.stringify(params));
    return this.http.post(ApiUrl + 'UpdateSite', JSON.stringify(params));
  }

  test(params) {
    // console.log("create Site data ", JSON.stringify(params));
    return this.http.post(ApiUrl + 'CreateSocialDistanceAlert', JSON.stringify(params));
  }

  addGeofence(params) {
    // console.log("add geofence ", JSON.stringify(params));
    return this.http.post('https://covidgeofencefunapi.azurewebsites.net/api/CreateGeofence', JSON.stringify(params));
  }


  getGeofence(params) {
    // console.log("get geofence ", params);
    return this.http.post('https://covidgeofencefunapi.azurewebsites.net/api/getGeofence', params);
  }

  GetAllStore() {
    return this.http.get(ApiUrl + 'GetAllStores')
  }

  getAlertType(email) {
    return this.http.post(ApiUrl + 'GetAlertType', email)
  }

  CreateSubscription(payload) {
    return this.http.post(ApiUrl + 'CreateSubscription', payload)
  }
  // https://covwebapi.azurewebsites.net/api/UnsubscribeAlert?SubscriptionId=2
  unsubscribeAlert(subId) {
    return this.http.post(ApiUrl + 'UnsubscribeAlert', subId)
  }

  //  https://covidgeofencefunapi.azurewebsites.net/api/employeeCsvUpload
  employeeCsvUpload(payload) {
    // This will change
    //https://covidgeofencefunapi.azurewebsites.net/api/employeeCsvUpload
    // 'https://us-foods-node-api.azurewebsites.net/api/employeeCsvUpload'   https://usfoodsuploadapi.azurewebsites.net/api/UploadEmployeeCSV
    return this.http.post('https://usfuploadcsvtest.azurewebsites.net/api/UploadEmployeeCSV', payload);
  }

  authenticateUser(payload) {
    // )  https://covwebapi.azurewebsites.net/api/AuthenticateUser
    return this.http.post(ApiUrl + 'AuthenticateUser', payload)
  }
  registerUser(payload) {
    // )  https://covwebapi.azurewebsites.net/api/AuthenticateUser
    return this.http.post(ApiUrl + 'RegisterUser', payload)
  }

  validateEmail(email) {
    // https://covwebapi.azurewebsites.net/api/ValidateEmail?Email=remil.jose@wipro.com
    return this.http.post(ApiUrl + 'ValidateEmail', email)
  }

  deleteSite(Sid) {
    return this.http.post(ApiUrl + "DeleteStore", Sid)
  }

  // https://covwebapi.azurewebsites.net/api/DeleteAssociate?Email=kotha.valli@wipro.com
  deleteAssociate(emailId) {
    return this.http.post(ApiUrl + "DeleteAssociate", emailId)
  }
  deleteAllAssociate(SiteId) {
    return this.http.post(ApiUrl + "DeleteAssociate", SiteId)
  }

  // http://covwebapi.azurewebsites.net/api/GetAllStoreEmployeeDasboard
  getAllStoreEmployeeDashboard(payload) {
    return this.http.post(ApiUrl + 'GetAllStoreEmployeeDasboard', payload)
  }

  // http://localhost:7071/api/UpdateEmployeeStatus
  updateEmployeeStatus(payload) {
    return this.http.post(ApiUrl + 'UpdateEmployeeStatus', payload)
  }
  // GetEmployeeDetailsBasedonStoreId
  //  http://covwebapi.azurewebsites.net/api/GetAllStoreEmployees?Sid=8
  getAllStoreEmployees(StoreId) {
    return this.http.post(ApiUrl + 'GetAllStoreEmployees', StoreId)
  }

  // Social Distancing Alerts
  // https://covwebapi.azurewebsites.net/api/GetSocialDistanceAlertData?Email=Z-Mart-Associate-1@Z-Mart.com

  getSocialDistancingAlerts(Email) {
    return this.http.post(ApiUrl + 'GetSocialDistanceAlertData', Email)
  }

  // GetAssociate List

  getAssociateList(StoreId) {
    return this.http.post(ApiUrl + 'GetAllAsocciates', StoreId)
  }
  // http://covwebapi.azurewebsites.net/api/GetRegionList?Country=India
  getRegionList(Country) {
    return this.http.post(ApiUrl + 'GetRegionList', Country)
  }

  // http://covwebapi.azurewebsites.net/api/GetStoreList?Country=India&Region=Ap
  getStoreList(payload) {
    return this.http.post(ApiUrl + 'GetStoreList', payload)
  }

  // http://covwebapi.azurewebsites.net/api/GetTemperatureGraph?Email=nadavati.siva@wipro.com
  getTemperatureGraphForEmployee(email) {
    return this.http.post(ApiUrl + 'GetTemperatureGraph', email)
  }

  // https://covwebapi.azurewebsites.net/api/GetAssociateAlertList?Status=Alert
  getEmployeeListforlabels(payload) {
    return this.http.post(ApiUrl + 'GetAssociateAlertList', payload)
    // return this.http.post('https://usfoodswebfunction.azurewebsites.net/api/GetAssociateAlertList', payload)
  }



  generateToken(payload) {
    return this.http.post('https://us-foods-node-api.azurewebsites.net/api/createToken', payload)
  }

  validateToken(payload) {
    return this.http.post('https://us-foods-node-api.azurewebsites.net/api/verifyToken', payload)
  }

  // https://usfoodswebfunction.azurewebsites.net/api/GetDeviceData
  getAvailableDevices(payload) {
    return this.http.post(ApiUrl + 'GetDeviceData', payload) //, { headers: CustomHeaders }
  }

  getAllSiteDevices(payload) {
    return this.http.post(ApiUrl + 'GetAllDevices', payload) //, { headers: CustomHeaders }
  }

  updateEmployee(payload) {
    return this.http.post(ApiUrl + 'UpdateWearable', payload) //, { headers: CustomHeaders }

  }

  // https://usfoodswebfunction.azurewebsites.net/api/SDAlerts15Mins
  getSDAlerts15Mins(payload) {
    return this.http.post(ApiUrl + 'SDAlerts15Mins', payload) //, { headers: CustomHeaders }
  }
  getSDAlerts15MinsByDays(payload) {
    console.log(payload);
    return this.http.post(ApiUrl + 'GetSd15minData', payload) //, { headers: CustomHeaders }
  }

  // getSDAlerts15MinsByDays(payload) {
  //   return this.http.post(ApiUrl + 'GetSdDatainDays', payload) //, { headers: CustomHeaders }
  // }

  updateWearableConfiguration(payload) {
    return this.http.post(ApiUrl + 'UpdateWearableConfig', payload) //, { headers: CustomHeaders }

  }

  wearableCsvUpload(payload) {
    return this.http.post('https://usfuploadcsvtest.azurewebsites.net/api/UploadWearableCSV', payload);
  }

  getWearableConfigurations(payload) {
    // https://usfoodswebfunction.azurewebsites.net/api/GetRssiforWeb
    return this.http.post(ApiUrl + 'GetRssiforWeb', payload);//, { headers: CustomHeaders }
  }

  getGatewayList(payload) {
    // https://usfoodswebfunction.azurewebsites.net/api/GetRssiforWeb
    return this.http.post(ApiUrl + 'GetGatewayData', payload);//, { headers: CustomHeaders }
  }


  deleteGateway(payload) {
    // https://usfoodswebfunction.azurewebsites.net/api/GetRssiforWeb
    return this.http.post(ApiUrl + 'DeleteGateway', payload);//, { headers: CustomHeaders }
  }


  editGateway(payload) {
    // https://usfoodswebfunction.azurewebsites.net/api/GetRssiforWeb
    return this.http.post(ApiUrl + 'UpdateGateway', payload);//, { headers: CustomHeaders }
  }

  addGateway(payload) {
    // https://usfoodswebfunction.azurewebsites.net/api/GetRssiforWeb
    return this.http.post(ApiUrl + 'CreateGateway', payload);//, { headers: CustomHeaders }
  }

  // https://usfoodswebfunction.azurewebsites.net/api/UpdateConsideration
  addRecordNote(payload) {
    return this.http.post(ApiUrl + 'UpdateConsideration', payload);//, { headers: CustomHeaders }
    // return this.http.post('https://usfoodswebfunction.azurewebsites.net/api/UpdateConsideration', payload);//, { headers: CustomHeaders }

  }

}




