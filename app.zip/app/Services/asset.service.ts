import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import { map, switchMap } from 'rxjs/operators';
import { BehaviorSubject, Observable } from 'rxjs';

import { getFacilityList,GetGatewayList,GetAllAccounts,GetZonebyFacility,CreateAsset,GetAllAssets , 
  GetZoneAssetDetails,CreateGeofence, CreateUser, DeleteUser, GetGeofenceList,GetGeofenceName,GetMapDetails,GetUtilizationData,GetUserList,
  CreateDevices,DeleteAsset,GetTagLists,GetAllUsers,GetAllAssetStatusforDashBoard,GetAllAssetsInFacilities, GetTrackerLists,DeleteDevices,DeleteGeofence,UpdateFacility,
   CreateFacility, AssociateAssetUser,DeleteFacility,GetAllFacilityInfo,EditDevices,
  CreateGateway,DeleteGateway,PeopleAttendance,
  GetAssetStatusDetailsDashboard,GetPersonStatusDetailsforDashboard,
  GetAssetHistory,GetTotalAssetStatus,GetAssetAlertHistory,GetHoldingAsset,ReleaseAsset,GetAssetOutdoorHistory,
  UpdateAsset} from '../constants/ApiUrlTNT';
  

import { interval } from 'rxjs';

@Injectable()
export class AssetService {
  constructor(
    private http: Http) { }
   public loadPromise: Promise<void>;
   public loadAPI: Promise<any>;
  // Abhishek's Variable Declaration
  public assetName: string;
  public assetId: number;
  public device: string;
  public selectedZones:any;
  public searchAdminText:any;
  public editAsset:object;

  private AssetName = new BehaviorSubject('');
  GetAssetName = this.AssetName.asObservable();

  setAssetName(message: any) {
    this.AssetName.next(message);

  }
  private search = new BehaviorSubject('');
  GetSearchText = this.search.asObservable();

  setSearchText(message: any) {
    this.search.next(message);

  }

  private refreshPeople = new BehaviorSubject('');
  GetRefreshData = this.refreshPeople.asObservable();

  setRefreshData(message: any) {
    this.refreshPeople.next(message);

  }
  // Abhishek's Declaration Ends HEre ++++++++++++++++++++++++



 public load(): Promise<void> {
        if (this.loadPromise) {
            return this.loadPromise;
        }

        const script = document.createElement('script');
        script.type = 'text/javascript';
        script.async = true;
        script.defer = true;

        const mapsCallback = 'mapOnInit';
        script.src = 'http://www.bing.com/api/maps/mapcontrol?callback=mapOnInit&key=Avh43rwIxMpHSkLOHeo7MeaFNwaQgk8BsehjzGxYxscXNvi6VH_VlUnX_MHAyFzw';

        this.loadPromise = new Promise<
            void
            >((resolve: Function, reject: Function) => {
                window[mapsCallback] = () => {
                    resolve();
                };
                script.onerror = (error: Event) => {
                    console.error('maps script error' + error);
                    reject(error);
                };
            });

        document.body.appendChild(script);

        return this.loadPromise;
    }

    public googleMapload(): Promise<void> {
      if (this.loadPromise) {
          return this.loadPromise;
      }
      console.log("Inside map service");
      
      const script = document.createElement('script');
      script.type = 'text/javascript';
      script.async = true;
      script.defer = true;
  
      const mapsCallback = 'mapOnInit';
      script.src = 'https://maps.googleapis.com/maps/api/js?callback=mapOnInit&libraries=places,drawing&key=AIzaSyD-W6KsE2J565Qzd_JUt979unv8NpaYXD4';
      
  
      this.loadPromise = new Promise<
          void
          >((resolve: Function, reject: Function) => {
              window[mapsCallback] = () => {
                  resolve();
              };
              script.onerror = (error: Event) => {
                  console.error('maps script error' + error);
                  reject(error);
              };
          });
  
      document.body.appendChild(script);
  
      return this.loadPromise;
  }
  

  public setRequestObject(apiUrl) {
    const headers = new Headers({ 'Content-Type': 'application/json' });
    headers.append('APIKey', '16d49c9b-de55-4492-99d4-68b7ef1edc83');
    const options = new RequestOptions({ headers });
    const requestObj = this.http.get(apiUrl, options);
    console.log('inside the service', requestObj);
    return requestObj;
  }

  public createGateway(payload) {
    const headers = new Headers({ 'Content-Type': 'application/json' });
    const options = new RequestOptions({ headers: headers });
    return this.http.post(CreateGateway, payload, options)
      .pipe(map(result => result));
  }

  public getAssetList(apiUrl) {
    return this.setRequestObject(apiUrl)
      .pipe(map((response) => (response.json())));
  }

  // public GetMapDetails(payload) {
  //   return this.http.post(GetMapDetails, {})
  //   .pipe(map(res => res.json()));
  // }

  public GetMapDetails2(payload) {
    const headers = new Headers();
    headers.append('Content-Type', 'application/json');
    // headers.append('Authorization',this.basic);
    const options = new RequestOptions({ headers: headers });

    return interval(30000).pipe(switchMap(() => this.http.post(GetMapDetails, {}))
      , map(res => res.json()));
  }
  public createAsset(payload) {
    const headers = new Headers({ 'Content-Type': 'application/json' });
    const options = new RequestOptions({ headers: headers });
    return this.http.post(CreateAsset, payload, options)
      .pipe(map(result => result));
  }

 
  public createUser(payload) {
    const headers = new Headers({ 'Content-Type': 'application/json' });
    const options = new RequestOptions({ headers: headers });
    return this.http.post(CreateUser, payload, options)
      .pipe(map(result => result));
  }

  public createDevices(payload) {
    const headers = new Headers({ 'Content-Type': 'application/json' });
    const options = new RequestOptions({ headers: headers });
    return this.http.post(CreateDevices, payload, options)
      .pipe(map(result => result));
  }

  public DeleteDevice(payload) {
    return this.http.post(DeleteDevices, payload)
      .pipe(map(res => res));
  }
  public DeleteUser(payload) {
    return this.http.post(DeleteUser, payload)
      .pipe(map(res => res.json()));
  }
  public EditDevice(payload) {
    return this.http.post(EditDevices, payload)
      .pipe(map(res => res.json()));
  }

  public DeleteGeofence(payload) {
    return this.http.post(DeleteGeofence, payload)
      .pipe(map(res => res.json()));
  }
  public DeleteGateway(payload) {
    return this.http.post(DeleteGateway, payload)
      .pipe(map(res => res));
  }

  public GetTaglist() {
    return this.http.post(GetTagLists, {})
      .pipe(map(res => res.json()));
  }
  // public GetGatewayList(){
  //   return this.http.post(GetAllGateways, {})
  //     .pipe(map(res => res.json()));
  // }
  public GetAllAssetsInFacilities(category) {
    return this.http.post(GetAllAssetsInFacilities + category, {})
      .pipe(map(res => res.json()));
  }
  public GetTrackerList() {
    return this.http.post(GetTrackerLists, {})
      .pipe(map(res => res.json()));
  }

  public GetUserList() {
    return this.http.post(GetUserList, {})
      .pipe(map(res => res.json()));
  }
  public GetFacilityList() {
    return this.http.post(getFacilityList, {})
      .pipe(map(res => res.json()));
  }





  
  //  public GetGeofenceList() {
  //     return this.http.post(GetGeofenceList, {})
  //     .pipe(map(res => res.json()));
  //   }

  //  public GetGeofenceNameList() {
  //     return this.http.post(GetGeofenceName, {})
  //     .pipe(map(res => res.json()));
  //   }
  public GetAllAssetList(category) {
    return this.http.post(GetAllAssets + category, {})
      .pipe(map(res => res.json()));
  }
  public getUtilizationData(category) {
    return this.http.post(GetUtilizationData + category, {})
      .pipe(map(res => res.json()));
  }
  public AssociateAssetUser(payload) {
    return this.http.post(AssociateAssetUser, payload)
      .pipe(map(res => res.json()));
  }
  public UpdateAsset(payload) {
    const headers = new Headers({ 'Content-Type': 'application/json' });
    const options = new RequestOptions({ headers: headers });
    return this.http.post(UpdateAsset, payload, options)
      .pipe(map(result => result));
  }

  public GetAllAssetList2() {
    const headers = new Headers();
    headers.append('Content-Type', 'application/json');
    // headers.append('Authorization',this.basic);
    const options = new RequestOptions({ headers: headers });

    return interval(30000).pipe(switchMap(() => this.http.post(GetAllAssets, {}))
      , map(res => res.json()));
  }

  public GetAccountList() {
    return this.http.post(GetAllAccounts, {})
      .pipe(map(res => res.json()));
  }

  public GetZonebyFacility(facName) {
    return this.http.post(GetZonebyFacility + facName, {})
      .pipe(map(res => res.json()));
  }


  public GetUsersList() {
    return this.http.post(GetAllUsers, {})
      .pipe(map(res => res.json()));
  }

  public GetZoneAssetDetailsPoll(facilityName) {
    return interval(15000).pipe(switchMap(() =>
      this.http.post(GetZoneAssetDetails + facilityName, {})),
      map(res => res.json()));
  }

  public GetZoneAssetDetails(facilityName) {
    return this.http.post(GetZoneAssetDetails + 'FacilityName='+facilityName + '&Category=Material', {})
      .pipe(map(res => res.json()));
  }
  public GetZoneAssetDetails2(facilityName) {
    return this.http.post(GetZoneAssetDetails + 'FacilityName='+facilityName + '&Category=People', {})
      .pipe(map(res => res.json()));
  }

  // public GetAllAssetList2(){
  //   let headers = new Headers();
  //   headers.append('Content-Type', 'application/json');
  //   // headers.append('Authorization',this.basic);
  //   let options = new RequestOptions({headers: headers});

  // return  interval(30000).pipe(switchMap (() => this.http.post(GetAllAssets, {}))
  //   , map(res => res.json()));
  // }

  public GetGeofenceList() {
    return this.http.post(GetGeofenceList, {})
      .pipe(map(res => res.json()));
  }

  public GetGeofenceNameList() {
    return this.http.post(GetGeofenceName, {})
      .pipe(map(res => res.json()));
  }

  public createGeofence(payload) {
    console.log('inside create geofence');
    const headers = new Headers({ 'Content-Type': 'application/json' });
    const options = new RequestOptions({ headers: headers });
    return this.http.post('https://trackandtracefuncapp.azurewebsites.net/api/createGeofence', payload)
      .pipe(map(result => result));
  }

  public GetMapDetails(payload) {
    return this.http.post(GetMapDetails, {})
      .pipe(map(res => res.json()));
  }

  // public GetMapDetails2(payload){
  //       let headers = new Headers();
  //      headers.append('Content-Type','application/json');
  //       // headers.append('Authorization',this.basic);
  //       let options = new RequestOptions({headers:headers});

  //     return  interval(30000).pipe(switchMap (()=>this.http.post(GetMapDetails,{}))
  //       ,map(res => res.json()));
  // }

  public DeleteAsset(payload) {
    return this.http.post(DeleteAsset, payload)
      .pipe(map(res => res.json()));
  }

   // ***********Abhishek's Service STARTS Here******************
  public GetAllAssets( category) {
    return this.http.get(GetAllAssets+category)
      .pipe(map(res => res));
  }

  public GetAllAssetStatusforDashBoard(category) {
    return this.http.get(GetAllAssetStatusforDashBoard + category)
      .pipe(map(res => res.json()));
  }


  public GetAssetStatusDetailsforDashboard(AssetId) {
    return this.http.get(GetAssetStatusDetailsDashboard + AssetId)
      .pipe(map(res => res));
  }

  public GetPersonStatusDetailsforDashboard(AssetId) {
    return this.http.get(GetPersonStatusDetailsforDashboard + AssetId)
      .pipe(map(res => res.json()));
  }
  public GetPersonAttendanceDetailsforDashboard(AssetName) {
    return this.http.get( PeopleAttendance + AssetName)
      .pipe(map(res => res.json()));
  }
  public GetAssetHistory(AssetName) {
    return this.http.get(GetAssetHistory + AssetName)
      .pipe(map(res => res));
  }

  public GetAssetOutdoorHistory(AssetName) {
    return this.http.get(GetAssetOutdoorHistory + AssetName)
      .pipe(map(res => res));
  }

public GetTotalAssetStatus() {
  return this.http.get(GetTotalAssetStatus)
      .pipe(map(res => res));
  }

  public GetAssetAlertHistory(AssetName) {
    return this.http.get(GetAssetAlertHistory + AssetName)
    .pipe(map(res => res));
  }

  public GetHoldingAsset(AssetName) {
    return this.http.get(GetHoldingAsset+AssetName)
      .pipe(map(res => res.json()));
  }
  public releaseAsset(payload) {
    console.log('inside RELEASE ASSET');
    const headers = new Headers({ 'Content-Type': 'application/json' });
    const options = new RequestOptions({ headers: headers });
    return this.http.post(ReleaseAsset, payload)
      .pipe(map(result => result));
  }

  public geofenceCount() {
    return this.http.get('https://trackandtracefuncapp.azurewebsites.net/api/geofenceCount')
    .pipe(map(res => res));
  }
  // ***********Abhishek's Service Ends Here******************




// Modified and Structured As the part of integrating with US Foods  
// Divya

  // Method for Listing gateways as dropdown while clicking a green dot
  public GetGatewayList(){
    return this.http.post(GetGatewayList, {})
    .pipe(map(res => res.json()));
  }

  // Facilties related services starts here

  // Method to list all facilities 
  public GetAllFacilityList() {
    return this.http.post(GetAllFacilityInfo, {})
      .pipe(map(res => res.json()));
  }

  public CreateFacility(facility) {
    return this.http.post(CreateFacility, facility)
      .pipe(map(res => res.json()));
  }

  public DeleteFacility(facId) {
    return this.http.post(DeleteFacility + facId, {})
      .pipe(map(res => res.json()));
  }

  public UpdateFacility(facility) {
    return this.http.post(UpdateFacility, facility)
      .pipe(map(res => res.json()));
  }

}


