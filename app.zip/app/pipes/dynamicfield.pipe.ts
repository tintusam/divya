import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'dynamicfield'
})
export class DynamicfieldPipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    for (var i in value){
      return i + " is " + value[i];
    }
   
  }

}
