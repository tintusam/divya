import { BeautifierPipe } from './beautifier.pipe';

describe('BeautifierPipe', () => {
  it('create an instance', () => {
    const pipe = new BeautifierPipe();
    expect(pipe).toBeTruthy();
  });
});
