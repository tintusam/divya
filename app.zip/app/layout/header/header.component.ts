import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(private userService: UserService, private router: Router) { }

  public username:string;
  public userRole:string;

  ngOnInit() {
    this.username = localStorage.getItem("userName");
    this.userRole = localStorage.getItem("userRole");
    console.log(this.userRole);
  }

    // function for logging out and clearing the local storage items
    logout() {
      localStorage.removeItem("Login");
      localStorage.removeItem("userID");
      localStorage.removeItem("userName");
      localStorage.removeItem("userEmail");
      localStorage.removeItem("userRole");
      this.userService.setLogin(false);
      this.router.navigate(['/sign-in']);
    }

}
