import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(private userService: UserService, private router: Router) { }

  public username: string;
  public userRole: string;
  public showSubscribeBox: boolean = false;
  public subscriptionModel: any = {};
  public showEmailBox:boolean = false;
  public subscriberEmail:string;
  public params:any;
  public subscriptionResponse:any;
  public hasSubscriptionResponse:boolean = false;


  ngOnInit() {
    this.username = localStorage.getItem("userName");
    this.userRole = localStorage.getItem("userRole");
    this.subscriptionModel.subscribefrequency = 'immediate'
    //console.log(this.userRole);
  }

  

  // Method for showing subcription box
  onShowSubscribe() {
    this.showSubscribeBox = true;
  }

  // Method for hiding subcription box
  onCloseSubscribe(event) {
    event.stopPropagation();
    this.showSubscribeBox = false;
    this.showEmailBox = false;
    this.params = {};
  }

  onSendSubscription(event){
    this.subscriberEmail = event.value.subscribeEmail;
    this.params.SubscribedEmail = this.subscriberEmail;
    this.hasSubscriptionResponse = false;
    console.log(this.params);
    // api call should be done here
    this.userService.alertSubscription(this.params).subscribe(
      res => {
        this.subscriptionResponse = res;
        //console.log(res);
        this.subscriptionResponse = this.subscriptionResponse._body.toString().replace(/"/g, "");
        this.hasSubscriptionResponse = true;
        //console.log(this.subscriptionResponse);
      },
      err => {
        console.log(err);
      }
    )
  }

  // Method for subscribing alerts
  onSubscribeAlerts() {
    this.showEmailBox = true;
    this.params = {
      LoggedEmail: localStorage.getItem("userEmail"),
      SubscribedEmail: '',
      CustId: localStorage.getItem("customerID"),
      Mode: "subscribe",
      redAlert: this.subscriptionModel.subscriptionRedAlert ? "yes" : "no",
      amberAlert: this.subscriptionModel.subscriptionAmberAlert ? "yes" : "no",
      Frequency: this.subscriptionModel.subscribefrequency
    }
    //console.log(this.params);
  }

  // Method for unsubscribing alerts
  onUnSubscribeAlerts() {
    this.showEmailBox = true;
    this.params = {
      LoggedEmail: localStorage.getItem("userEmail"),
      SubscribedEmail: '',
      CustId: localStorage.getItem("customerID"),
      Mode: "unsubscribe",
      redAlert: this.subscriptionModel.subscriptionRedAlert ? "yes" : "no",
      amberAlert: this.subscriptionModel.subscriptionAmberAlert ? "yes" : "no",
      Frequency: this.subscriptionModel.subscribefrequency
    }
    //console.log(this.params);
  }

  // Method for logging out and clearing the local storage items
  logout() {
    localStorage.removeItem("Login");
    localStorage.removeItem("userID");
    localStorage.removeItem("userName");
    localStorage.removeItem("userEmail");
    localStorage.removeItem("userRole");
    localStorage.clear();
    this.userService.setLogin(false);
    sessionStorage.clear();
    this.router.navigate(['/sign-in']);
  }

}
