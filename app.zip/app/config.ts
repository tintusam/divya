export const Config = Object.freeze({
     // BASE_API_URL: 'https://halliburtonfuncapp.azurewebsites.net/',
     // SECOND_API_URL: 'https://localhost:3005/',
     // API_PATH: 'api/' 

     BASE_API_URL: 'https://itrackapimngr.azure-api.net/',
     SECOND_API_URL: 'https://localhost:3005/',
     API_PATH: 'iTrackFunctionApp/' 
});        
