export const Config = Object.freeze({
     //BASE_API_URL: 'https://ramfuncapi.azurewebsites.net/',
     BASE_API_URL: 'https://assetradarfuncapi.azurewebsites.net/',
     //SECOND_API_URL: 'https://ramsolutionfunction.azurewebsites.net/',
     SECOND_API_URL:'https://assetradarlocalfuncapp.azurewebsites.net/',
     API_PATH: 'api/' 
});        
