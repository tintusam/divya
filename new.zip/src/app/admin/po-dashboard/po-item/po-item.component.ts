import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'app-po-item',
  templateUrl: './po-item.component.html',
  styleUrls: ['./po-item.component.css']
})
export class PoItemComponent implements OnInit {

  public toggleStatus: boolean = false;
  public toggleFlag: boolean;
  public materialSteps: any;
  public poContent: any;
  public selectedItem: any;

  constructor(private _router:Router) { }

  ngOnInit(): void {

    this.poContent = [
      {
        "M_No_of_steps":3,
        "toggleFlag": false,
        "Material_Info":{
            "M_Item_Num":1,
            "M_Material_Num":"13453466",
            "M_Item_Desc":"COM SWITCH BOX",
            "M_Order_Qty":12,
            "M_Unit":"Each",
            "M_Unit_Price":250,
            "M_Currency":"USD",
            "M_Status":"Green",
            "M_Due_date":"09/08/2020",
            "M_Projected_Due_Date":"09/07/2020",
            "M_Current_Step":"Send-outs / Secondary Processes",
            "M_Current_Step_Due_date":"02/07/2020",
            "M_Shipment_Tracking_ID":""              
        } ,   
        "Actual_Steps": [
          {
            "P_Step_order": 1,
            "P_Step_name": "Receive PO"
          },
          {
            "P_Step_order": 2,
            "P_Step_name": "Receive Raw Material"
          },
          {
            "P_Step_order": 3,
            "P_Step_name": "Machining"
          },
          {
            "P_Step_order": 4,
            "P_Step_name": "Send-outs/Secondary Process"
          },
          {
            "P_Step_order": 5,
            "P_Step_name": "Return Inspection"
          },
          {
            "P_Step_order": 6,
            "P_Step_name": "Final Inspection"
          },
          {
            "P_Step_order": 7,
            "P_Step_name": "Paper Work"
          },
          {
            "P_Step_order": 8,
            "P_Step_name": "Crate/Ship"
          }
        ],
        "Updated_Steps": [
          {
            "I_Step_Order": 1,
            "I_Step_Name": "Receive PO",
            "I_Status": "Green",
            "I_Step_Start_Date": "09/07/2020",
            "I_Step_due_Date": "09/07/2020",
            "I_Step_Completion_due_date": "09/07/2020"
          },
          {
            "I_Step_Order": 2,
            "I_Step_Name": "Receive Raw Material",
            "I_Status": "Red",
            "I_Step_Start_Date": "09/07/2020",
            "I_Step_due_Date": "09/07/2020",
            "I_Step_Completion_due_date": "09/07/2020"
          },
          {
            "I_Step_Order": 3,
            "I_Step_Name": "Machining",
            "I_Status": "Orange",
            "I_Step_Start_Date": "09/07/2020",
            "I_Step_due_Date": "09/07/2020",
            "I_Step_Completion_due_date": "09/07/2020"
          },
          {
            "I_Step_Order": 4,
            "I_Step_Name": "Send-outs/Secondary Process",
            "I_Status": "Green",
            "I_Step_Start_Date": "09/07/2020",
            "I_Step_due_Date": "09/07/2020",
            "I_Step_Completion_due_date": "09/07/2020"
          }
        ]
      },
      {
        "M_No_of_steps":3,
        "toggleFlag": false,
        "Material_Info":{
            "M_Item_Num":1,
            "M_Material_Num":"13453466",
            "M_Item_Desc":"AIR MUF,AC980,1/4 IN NPT",
            "M_Order_Qty":12,
            "M_Unit":"Each",
            "M_Unit_Price":250,
            "M_Currency":"USD",
            "M_Status":"Green",
            "M_Due_date":"09/07/2020",
            "M_Projected_Due_Date":"09/07/2020",
            "M_Current_Step":"Crate Ship",
            "M_Current_Step_Due_date":"09/07/2020",
            "M_Shipment_Tracking_ID":"AWB34231235"              
        },    
        "Actual_Steps":[
          {
            "P_Step_order": 1,
            "P_Step_name": "Receive PO"
          },
          {
            "P_Step_order": 2,
            "P_Step_name": "Receive Raw Material"
          },
          {
            "P_Step_order": 3,
            "P_Step_name": "Machining"
          },
          {
            "P_Step_order": 4,
            "P_Step_name": "Send-outs/Secondary Process"
          },
          {
            "P_Step_order": 5,
            "P_Step_name": "Return Inspection"
          },
          {
            "P_Step_order": 6,
            "P_Step_name": "Final Inspection"
          },
          {
            "P_Step_order": 7,
            "P_Step_name": "Paper Work"
          },
          {
            "P_Step_order": 8,
            "P_Step_name": "Crate/Ship"
          }                                                  
        ],
        "Updated_Steps": [
          {
            "I_Step_Order": 1,
            "I_Step_Name": "Receive PO",
            "I_Status": "Green",
            "I_Step_Start_Date": "09/07/2020",
            "I_Step_due_Date": "09/07/2020",
            "I_Step_Completion_due_date": "09/07/2020"
          },
          {
            "I_Step_Order": 2,
            "I_Step_Name": "Receive Raw Material",
            "I_Status": "Red",
            "I_Step_Start_Date": "09/07/2020",
            "I_Step_due_Date": "09/07/2020",
            "I_Step_Completion_due_date": "09/07/2020"
          },
          {
            "I_Step_Order": 3,
            "I_Step_Name": "Machining",
            "I_Status": "Orange",
            "I_Step_Start_Date": "09/07/2020",
            "I_Step_due_Date": "09/07/2020",
            "I_Step_Completion_due_date": "09/07/2020"
          },
          {
            "I_Step_Order": 4,
            "I_Step_Name": "Send-outs/Secondary Process",
            "I_Status": "Red",
            "I_Step_Start_Date": "09/07/2020",
            "I_Step_due_Date": "09/07/2020",
            "I_Step_Completion_due_date": "09/07/2020"
          },
          {
            "I_Step_Order": 5,
            "I_Step_Name": "Return Inspection",
            "I_Status": "Orange",
            "I_Step_Start_Date": "09/07/2020",
            "I_Step_due_Date": "09/07/2020",
            "I_Step_Completion_due_date": "09/07/2020"
          },
          {
            "I_Step_Order": 6,
            "I_Step_Name": "Final Inspection",
            "I_Status": "Red",
            "I_Step_Start_Date": "09/07/2020",
            "I_Step_due_Date": "09/07/2020",
            "I_Step_Completion_due_date": "09/07/2020"
          },
          {
            "I_Step_Order": 7,
            "I_Step_Name": "Paper Work",
            "I_Status": "Orange",
            "I_Step_Start_Date": "09/07/2020",
            "I_Step_due_Date": "09/07/2020",
            "I_Step_Completion_due_date": "09/07/2020"
          },                    
          {
            "I_Step_Order": 8,
            "I_Step_Name": "Crate/Ship",
            "I_Status": "Finish",
            "I_Step_Start_Date": "09/07/2020",
            "I_Step_due_Date": "09/07/2020",
            "I_Step_Completion_due_date": "09/07/2020"
          }]
      }
  ];

    }
 
    toggleItems() {
      for (let i = 0; i < this.poContent.length; i++) {
        this.poContent[i]['toggleFlag'] = !this.poContent[i]['toggleFlag'];
      }
      this.toggleStatus = !this.toggleStatus;
      console.log(this.poContent);
    }
  
    toggleSelectedItem(selectedItem) {
      this.poContent[selectedItem]['toggleFlag'] = !this.poContent[selectedItem]['toggleFlag'];
      console.log(this.poContent);
    }
  
  backToDashboard(){
    this._router.navigateByUrl('dashboard');
  }

}
