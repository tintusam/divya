import { Component, OnInit } from '@angular/core';
import { AppService } from '../../Services/app.service';
import { AssetService } from '../../Services/asset.service';

@Component({
  selector: 'app-tnt-dashboard',
  templateUrl: './tnt-dashboard.component.html',
  styleUrls: ['./tnt-dashboard.component.scss']
})
export class TNTDashboardComponent implements OnInit {

  public siteList:any;
  public selectedSiteID:any;
  public data;
  public facilityList:any;
  public imageRefUrl; zones; facilityName;Location;FacilityID;showImage

  constructor(private _appService:AppService, private _assetservice:AssetService) { }

  ngOnInit() {
    this.getAllSites();
    this.data = { max: 5, data: [{ x: 10, y: 15, value: 5}, { x: 5, y: 20, value: 4}] }
  }

  selectedSite(siteInfo){
    this.selectedSiteID = siteInfo.target.value;
    console.log(this.selectedSiteID);
    this.getAllFacilityList(this.selectedSiteID);
  }


    // Method to list all facilities
    getAllFacilityList(siteId) {
      let payload = {
        SiteID:JSON.parse(siteId)  
      }
      this._assetservice.GetAllFacilityList(payload)
        .subscribe(res => {
          this.facilityList = res[0]; // taking only first item
          this.onGetFloorImage(this.facilityList);
          
          // console.log(res);
          // console.log(this.facilityList);
        })
    }


    onGetFloorImage(floor) {
      //console.log(floor);
      this.imageRefUrl = floor.ImageUrl;
      this.zones = floor.Zones;
      this.facilityName = floor.FacilityName;
      this.Location = floor.Location;
      this.FacilityID = floor.FacilityID || '';
      this.showImage = true;
    }


  getAllSites(){
    this._appService.GetAllStore().subscribe(
      res => {
        this.siteList = res;
        //console.log(this.siteList);
        if(this.siteList){
          this.getAllFacilityList(sessionStorage.getItem("SiteId"));
        }
        
      },
      err => {
        console.log(err);
      }
    )
  }

}
