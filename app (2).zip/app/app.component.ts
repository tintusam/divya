import { Component, OnInit, DoCheck } from '@angular/core';
import {Router} from '@angular/router'
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html'
})

export class AppComponent implements OnInit, DoCheck {
  router: string;
  routeUrl: string;
  baseUrl:string;
  currentUrl:string;
  hideMenu: boolean;

  constructor(
      public _router: Router
  ) {
      // subscribe to the router events in order to always get the current url
      this._router.events.subscribe(() => this.routeUrl = this._router.url ); 
  }

  ngOnInit() {
  }

  ngDoCheck(){
    this.baseUrl = location.origin+'/';
    this.currentUrl= window.location.href;
    if ( this.baseUrl.trim() === this.currentUrl.trim()){
      this.hideMenu = true;
    }else{
      this.hideMenu = false;
    }
  }

  public hasMatches(...values: string[]): boolean {
      let matchFound: boolean = false;
  
      // check for null or undefined first
      if(this.routeUrl){ 
          for (var i=0; i<values.length; i++){
               if(this.routeUrl.indexOf(values[i]) > -1){
                  matchFound = true;
                  break;
               }
          }        
      }
  
      return matchFound;
  } 
}
