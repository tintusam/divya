import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-service-sidebar',
  templateUrl: './service-sidebar.component.html',
  styleUrls: ['./service-sidebar.component.css']
})
export class ServiceSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
