import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NotFoundComponent } from './shared/not-found/not-found.component';
import { LoginComponent } from './shared/login/login.component';
import { ManagementPortalComponent } from './admin/management-portal/management-portal.component';
import { PoDashboardComponent } from './admin/po-dashboard/po-dashboard.component';


const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: '',   redirectTo: '/LoginComponent',pathMatch: 'full'},
  { path:'admin/management', component:ManagementPortalComponent},
  { path:'admin/po-dashboard', component:PoDashboardComponent},
  { path: '**', component: NotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
