import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardLandingPageComponent } from './Components/Dashboard/dashboard-landing-page/dashboard-landing-page.component';
import { AuthGuard} from './Utilities/auth.guard';
import { LoginComponent } from './Components/login/login.component';

const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'sign-in', component: LoginComponent }, 
  { path: '',   redirectTo: '/LoginComponent',pathMatch: 'full'},
  { path: 'dashboard', component: DashboardLandingPageComponent, canActivate: [AuthGuard] }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
