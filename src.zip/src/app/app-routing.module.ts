import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardLandingPageComponent } from './Components/Dashboard/dashboard-landing-page/dashboard-landing-page.component';
import { AuthGuard} from './Utilities/auth.guard';
import { LoginComponent } from './Components/login/login.component';
import { SetpassordComponent } from './Components/setpassord/setpassord.component';
import { NotfoundComponent } from './Components/notfound/notfound.component';

const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'sign-in', component: LoginComponent }, 
  { path: '',   redirectTo: '/LoginComponent',pathMatch: 'full'},
  { path: 'set-password/:id', component: SetpassordComponent },
  { path: 'dashboard', component: DashboardLandingPageComponent, canActivate: [AuthGuard] },
  { path: '**', component: NotfoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
