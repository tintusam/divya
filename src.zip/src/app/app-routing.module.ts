import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { NotFoundComponent } from './not-found/not-found.component';
import { AppComponent } from './app.component';

const appRoutes: Routes = [
  { path: '**', component: NotFoundComponent },
  { path: '', component: AppComponent },
  //{ path: '',   redirectTo: '/AppComponent',pathMatch: 'full'},
];

@NgModule({
  imports: [
    RouterModule.forRoot(
      appRoutes,
      { enableTracing: false }
    )
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
