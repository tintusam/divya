import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NotFoundComponent } from './shared/not-found/not-found.component';
import { LoginComponent } from './shared/login/login.component';
import { ManagementPortalComponent } from './admin/management-portal/management-portal.component';
import { PoDashboardComponent } from './admin/po-dashboard/po-dashboard.component';
import { PoItemComponent } from './admin/po-dashboard/po-item/po-item.component';
import { ItemManagementComponent } from './admin/management-portal/item-management/item-management.component';
import { VendorManagementComponent } from './admin/management-portal/vendor-management/vendor-management.component';

const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'login', component: LoginComponent },
  { path: '',   redirectTo: '/LoginComponent',pathMatch: 'full'},
  { path:'management', component:ManagementPortalComponent},
  { path:'management/vendors', component:VendorManagementComponent},
  { path:'management/products', component:ItemManagementComponent},
  { path:'dashboard', component:PoDashboardComponent},
  { path:'dashboard/po', component:PoItemComponent},
  { path: '**', component: NotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
