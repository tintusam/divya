import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './Components/Shared Components/home/home.component';

const routes: Routes = [
  {
    path: 'facility-center',
    loadChildren: () =>
      import('./Components/facility-centre/facility-centre.module').then((m) => m.FacilityCentreModule),
  },
  {
    path: 'community-center',
    loadChildren: () =>
      import('./Components/community-centre/community-centre.module').then((m) => m.CommunityCentreModule),
  },
  {
    path: 'patient-provisioning',
    loadChildren: () =>
      import('./Components/patient-provisioning/patient-provisioning.module').then((m) => m.PatientProvisioningModule),
  },
  {
    path: 'admin',
    loadChildren: () =>
      import('./Components/admin-portal/admin-portal.module').then((m) => m.AdminPortalModule),
  },
  {
    path: '',
    component: HomeComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
