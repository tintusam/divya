import { Component } from '@angular/core';
import { Router } from '@angular/router'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'WFO-Associate';
  constructor(private router: Router) {

    this.router.navigate(['landing-page'])
    // this.router.navigate(['action-center'])

  }
}
