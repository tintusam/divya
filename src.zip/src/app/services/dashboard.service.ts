import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  constructor(private http: HttpClient) { }

  getWidgetCount(payload){
    return this.http.post('https://philipsrfidshipfn.azurewebsites.net/api/getCount',payload)
  }

  getGraphData(payload){
    return this.http.post('https://philipsrfidshipfn.azurewebsites.net/api/GetGraphData',payload)
  }

  getLocationFromBigData(latitude,longitude){
    return this.http.get('https://api.bigdatacloud.net/data/reverse-geocode-client?latitude='+latitude+'&longitude='+longitude)
  }

  getHandheldReaderData(payload){
    return this.http.post('https://philipsrfidshipfn.azurewebsites.net/api/GetHandheldReaderData',payload)
  }

  getTemperatureData(payload){
    return this.http.post('https://philipsrfidshipfn.azurewebsites.net/api/GetHandheldReaderData',payload)
  }

  getShipmentInfo(payload){
    return this.http.post('https://philipsrfidshipfn.azurewebsites.net/api/GetParticularShipmentData',payload)
  }

  deleteShipment(payload){
    return this.http.post('https://philipsrfidshipfn.azurewebsites.net/api/DeleteShipment',payload)
  }


}
