import { Injectable } from '@angular/core';
import { Http, Headers ,RequestOptions } from '@angular/http';
import { map } from 'rxjs/operators';
import { Config } from "./../config";
@Injectable({
  providedIn: 'root'
})
export class AssetsService {

  constructor(private http: Http) { }
  public assetId;

  postAssetData(params){
    //params.RAM_Latitude = 9.9312;
    //params.RAM_Longitude=76.2673;
    //params.RAM_Asset_Contact="";
    let headers = new Headers({'Content-Type' :'application/json'});
    let options = new RequestOptions ({ headers : headers ,method : 'post'});
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+'CreateAsset' ,JSON.stringify(params),options);
  }

  editAssetData(params){
    let headers = new Headers({'Content-Type' :'application/json'});
    //console.log(params);
    let options = new RequestOptions ({ headers : headers ,method : 'post'});
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+'editAsset' ,JSON.stringify(params),options);
  }

  editDevice(params){
    let headers = new Headers({'Content-Type' :'application/json'});
    let options = new RequestOptions ({ headers : headers ,method : 'post'});
    //console.log(params);
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+'editSensorKit' ,params,options);
  }

  public getDeviceList() {
    return this.http.get(Config.SECOND_API_URL+Config.API_PATH+'DisplayAsset')
      .pipe(map(res => res.json()));
  }

  public addUser(params){
    let headers = new Headers({'Content-Type' :'application/json'});
    let options = new RequestOptions ({ headers : headers ,method : 'post'});
    //console.log(params);
   return this.http.post(Config.SECOND_API_URL+Config.API_PATH+'CreateUser' ,params,options);
  }

  public editUser(params){
    let headers = new Headers({'Content-Type' :'application/json'});
    let options = new RequestOptions ({ headers : headers ,method : 'post'});
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+'editUser' ,params,options);
  }

  public deleteUser(params) {
    //console.log(params);
    let headers = new Headers({'Content-Type' :'application/json'});
    let options = new RequestOptions ({ headers : headers ,method : 'post'});
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+'deleteUser' ,params,options);
  }

  public getUsersList() {
    return this.http.get(Config.BASE_API_URL+Config.API_PATH+'DisplayUser')
      .pipe(map(res => res.json()));
  }

  public getCustomersList(payload) {
    let headers = new Headers({'Content-Type' :'application/json'});
    let options = new RequestOptions ({ headers : headers ,method : 'post'});   
    return this.http.post(Config.SECOND_API_URL+Config.API_PATH+'displayCustomer',payload, options)
      .pipe(map(res => res.json()));
  }

  public addCustomer(params){
    let headers = new Headers({'Content-Type' :'application/json'});
    let options = new RequestOptions ({ headers : headers ,method : 'post'});
   return this.http.post(Config.SECOND_API_URL+Config.API_PATH+'addCustomer' ,params,options);
  }

  public editCustomer(params){
    let headers = new Headers({'Content-Type' :'application/json'});
    let options = new RequestOptions ({ headers : headers ,method : 'post'});
    return this.http.post(Config.SECOND_API_URL+Config.API_PATH+'editCustomer' ,params,options);
  }

  public deleteCustomer(params) {
    //console.log(params);
    let headers = new Headers({'Content-Type' :'application/json'});
    let options = new RequestOptions ({ headers : headers ,method : 'post'});
    return this.http.post(Config.SECOND_API_URL+Config.API_PATH+'deleteCustomer' ,params,options);
  }


  public getSensorKitList() {
    return this.http.get(Config.BASE_API_URL+Config.API_PATH+'DisplaySensorKitID')
      .pipe(map(res => res.json()));
  }

  public getSensorKitParams(params) {
    //console.log("get parameters",params);
    let headers = new Headers({'Content-Type' :'application/json'});
    let options = new RequestOptions ({ headers : headers ,method : 'post'});
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+'DisplaySensorKitParams',params,options)
      .pipe(map(res => res.json()));
  }

  public deleteAsset(params) {
    let headers = new Headers({'Content-Type' :'application/json'});
    let options = new RequestOptions ({ headers : headers ,method : 'post'});
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+'DeleteAsset' ,params,options);
  }

  public deleteAlert(params) {
    let headers = new Headers({'Content-Type' :'application/json'});
    let options = new RequestOptions ({ headers : headers ,method : 'post'});
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+'DeleteAlert' ,params,options);
  }
  public onDeleteAsset(params) {
    let headers = new Headers({'Content-Type' :'application/json'});
    let options = new RequestOptions ({ headers : headers ,method : 'post'});
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+'DeleteAlert' ,params,options);
  }

  public deleteSensorKit(params) {
    //console.log(params);
    let headers = new Headers({'Content-Type' :'application/json'});
    let options = new RequestOptions ({ headers : headers ,method : 'post'});
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+'deleteSensorKit' ,params,options);
  }

  public addDevice(params){
    let headers = new Headers({'Content-Type' :'application/json'});
    let options = new RequestOptions ({ headers : headers ,method : 'post'});
    return this.http.post(Config.SECOND_API_URL+Config.API_PATH+'RAMSensorKitCreationSql',params,options);
  }

  public sendLocation(params){
    //console.log(params);
    let headers = new Headers({'Content-Type' :'application/json'});
    let options = new RequestOptions ({ headers : headers ,method : 'post'});
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+'UpdateLocation' ,params,options);
  }

  public deleteSensorParameter(params){
    let headers = new Headers({'Content-Type' :'application/json'});
    let options = new RequestOptions ({ headers : headers ,method : 'post'});
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+'DeleteParameter' ,JSON.stringify(params),options);
  }

getLocationwithCoord(lat,lng){
  //console.log(lat,lng);
  return this.http.get('http://dev.virtualearth.net/REST/v1/Locations/'+lat+','+lng+'?o=json&key=Avh43rwIxMpHSkLOHeo7MeaFNwaQgk8BsehjzGxYxscXNvi6VH_VlUnX_MHAyFzw')
  .pipe(map(res => res.json()));
}

  
}
