import { DynamicfieldPipe } from './dynamicfield.pipe';

describe('DynamicfieldPipe', () => {
  it('create an instance', () => {
    const pipe = new DynamicfieldPipe();
    expect(pipe).toBeTruthy();
  });
});
