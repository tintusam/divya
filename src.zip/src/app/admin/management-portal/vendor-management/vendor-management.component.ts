import { Component, OnInit } from '@angular/core';
import {formatDate } from '@angular/common';
declare var $: any;

@Component({
  selector: 'app-vendor-management',
  templateUrl: './vendor-management.component.html',
  styleUrls: ['./vendor-management.component.css']
})
export class VendorManagementComponent implements OnInit {
  public selectedTimeZone:String;
  today= new Date();
  todaysDataTime = '';
  selectedFile:String;
  public showUploadForm:boolean = false;
  public vendorsList:any;
  constructor() { 
    //this.todaysDataTime = formatDate(this.today, 'dd/MMM/yyyy hh:mm:ss a', 'en-US', '+0530');
    this.todaysDataTime = formatDate(this.today, 'long', 'en-US', '+0530');
  }

  ngOnInit(): void {
    //this.selectedTimeZone = 'Australia/Darwin'; 
    this.getVendorsList();
    this.selectedTimeZone = 'Asia/Calcutta'; 
    $(document).ready(() => {
      $('#timeZoneContent').timezonePicker(
        {
          defaultValue: { value: this.selectedTimeZone, attribute: "timezone" },
          width:500,
          height:300,
          showHoverText:false,
          selectBox:true,
          hoverText:true,
          quickLink:[]
        }
      );
      $('#timeZoneContent').on("map:loaded" , function(){
        //console.log("Map is loaded, have fun!");
        //$('#timeZoneContent').data('timezonePicker').setValue('Australia/Darwin')
      });

//       $('#timeZoneContent').on("map:value:changed" , function(){
//         console.log($('#timeZoneContent').data('timezonePicker').getValue());
//     });

//     $('#timeZoneContent').on("map:option:changed" , function(){
//       console.log($('#timeZoneContent').data('timezonePicker').getValue());
//   });

//   $('#timeZoneContent').on("map:country:clicked" , function(){
//     console.log($('#timeZoneContent').data('timezonePicker').getValue());
// });


    });
  }

  toggleUploadForm(){
    this.showUploadForm = !this.showUploadForm;
    console.log(this.showUploadForm);
  }
  get fileName(): string {
    return this.selectedFile ? this.selectedFile.split('/').pop() : 'Browse';
  }

  getVendorsList(){
    this.vendorsList = [
      {
        "V_VendorCode":"12345",
        "V_Vendor_Name":"Ultra Engineers",
        "V_Location":"Pune, India"
      },
      {
        "V_VendorCode":"12345",
        "V_Vendor_Name":"BELLELI ENERGY, SPA",
        "V_Location":"ITALY"
      },
      {
        "V_VendorCode":"12345",
        "V_Vendor_Name":"BORSIG GMBH",
        "V_Location":"GERMANY"
      },
      {
        "V_VendorCode":"12345",
        "V_Vendor_Name":"DAEKYUNG MACHINERY & ENGINEERING CO.LTD",
        "V_Location":"SOUTH KOREA"
      },
      {
        "V_VendorCode":"12345",
        "V_Vendor_Name":"FOSTER WHEELER",
        "V_Location":"ITALY"
      },
      {
        "V_VendorCode":"12345",
        "V_Vendor_Name":"FUCHS FORDERTECHNIK AG",
        "V_Location":"GERMANY"
      }                           
    ]

  }

}
