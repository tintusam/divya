import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-item-management',
  templateUrl: './item-management.component.html',
  styleUrls: ['./item-management.component.css']
})
export class ItemManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
