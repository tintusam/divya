import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-item-management',
  templateUrl: './item-management.component.html',
  styleUrls: ['./item-management.component.css']
})
export class ItemManagementComponent implements OnInit {

  constructor() { }
  items = [1, 2, 3, 4, 5];
  stepsData:any;
  selectedFile:string;
  public showUploadForm:boolean = false;
  ngOnInit(): void {
    this.stepsData = [
      {
        id: 1,
        description: "Receive PO",
        duration:"3 Days"
      },
      {
        id: 2,
        description: "Receive Raw Material",
        duration:"3 Days"
      },
      {
        id: 3,
        description: "Machining",
        duration:"4 Days"
      },
      {
        id: 4,
        description: "Send-outs/Secondary Process",
        duration:"3 Days"
      },
      {
        id: 5,
        description: "Return Inspection",
        duration:"4 Days"
      } ,
      {
        id: 6,
        description: "Final Inspection",
        duration:"3 Days"
      },
      {
        id: 7,
        description: "Paper Work",
        duration:"4 Days"
      },
      {
        id: 8,
        description: "Crate/Ship",
        duration:"3 Days"
      }          
    ]
  }

  toggleUploadForm(){
    this.showUploadForm = !this.showUploadForm;
    console.log(this.showUploadForm);
  }

  get fileName(): string {
    return this.selectedFile ? this.selectedFile.split('/').pop() : 'Browse';
  }

}
