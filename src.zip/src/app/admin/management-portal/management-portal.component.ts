import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';

@Component({
  selector: 'app-management-portal',
  templateUrl: './management-portal.component.html',
  styleUrls: ['./management-portal.component.css']
})
export class ManagementPortalComponent implements OnInit {

  router:string;

  constructor(private _router: Router){
    this.router = _router.url;
  }

  ngOnInit(): void {
    console.log(this.router);
  }

}
