import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-po-dashboard',
  templateUrl: './po-dashboard.component.html',
  styleUrls: ['./po-dashboard.component.css']
})
export class PoDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
