import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-po-summary',
  templateUrl: './po-summary.component.html',
  styleUrls: ['./po-summary.component.css']
})
export class PoSummaryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
