import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AssetsManagerComponent } from './assets-manager/assets-manager.component';
import { DeviceManagerComponent } from './device-manager/device-manager.component';
import { ManageUserComponent } from './manage-user/manage-user.component';
import { AdministrationRoutingModule } from './administration-routing.module';
import { AgmCoreModule } from '@agm/core';
import { AdministrationMenuComponent } from './administration-menu/administration-menu.component';
import { AddAssetModalComponent } from './assets-manager/add-asset-modal/add-asset-modal.component';
import { DeleteAssetModalComponent } from './assets-manager/delete-asset-modal/delete-asset-modal.component';
import { AddLocationComponent } from './assets-manager/add-location/add-location.component';
import { BLOB_STORAGE_TOKEN, IAzureStorage } from './assets-manager/azure-storage/azureStorage';
import { BlobStorageService } from './assets-manager/azure-storage/blob-storage.service';
import {BeautifierPipe} from './../pipes/beautifier.pipe';
import { ManageCustomersComponent } from './manage-customers/manage-customers.component';

// export function azureBlobStorageFactory(): IBlobStorage {
//   return window['AzureStorage'];
// }

declare var AzureStorage: IAzureStorage

@NgModule({
  imports: [
    CommonModule,
    AdministrationRoutingModule,
    FormsModule,  
  ],
  declarations: [AssetsManagerComponent, BeautifierPipe, DeviceManagerComponent, ManageUserComponent, AdministrationMenuComponent, 
  AddAssetModalComponent, DeleteAssetModalComponent, AddLocationComponent, ManageCustomersComponent],
  providers: [
    // BlobStorageService,
    // {
    //   provide: BLOB_STORAGE_TOKEN,
    //   useValue: AzureStorage.Blob
    // }
  ],
  exports:[ManageUserComponent, BeautifierPipe]
})
export class AdministrationModule { }
