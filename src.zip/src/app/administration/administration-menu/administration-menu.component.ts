import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-administration-menu',
  templateUrl: './administration-menu.component.html',
  styleUrls: ['./administration-menu.component.css']
})
export class AdministrationMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
