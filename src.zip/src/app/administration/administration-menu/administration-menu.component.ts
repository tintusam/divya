import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-administration-menu',
  templateUrl: './administration-menu.component.html',
  styleUrls: ['./administration-menu.component.css']
})
export class AdministrationMenuComponent implements OnInit {

  public userRole:string;
  constructor() { }

  ngOnInit() {
    this.userRole = localStorage.getItem("userRole");
    console.log(this.userRole);
  }

}
