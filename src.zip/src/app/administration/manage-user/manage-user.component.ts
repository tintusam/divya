import { Component, OnInit, ViewChild } from '@angular/core';
import { AssetsService } from '../../services/assets.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-manage-user',
  templateUrl: './manage-user.component.html',
  styleUrls: ['./manage-user.component.css']
})
export class ManageUserComponent implements OnInit {

  constructor(private assetsService: AssetsService) { }

  @ViewChild('closeAddUserModal', {static:false}) closeAddUserModal;

  public usersList;
  public uid;
  public ufname;
  public ulname;
  public urole;
  public umail;
  public firstname;
  public lastname;
  public role;
  public email;
  public password;
  public addedUser: boolean = false;
  public addedUserError: boolean = false;
  public deletedUser: boolean = false;
  public editedUser: boolean = false;
  public isFullyLoaded:boolean = false;
  public roles:any;
  public userrole:any;

  public addUserModel: any = {};

  ngOnInit() {
    this.getUsersList();
  }

  selectRole(e){
    this.userrole = e.target.value;
  }

  setUser(user) {
    this.uid = user.UserID;
    this.ufname = user.FirstName;
    this.ulname = user.LastName;
    this.urole = user.Role;
    this.umail = user.Mail
  }

  getUsersList() {
    let payload = {
      "custId":JSON.parse(localStorage.getItem("customerID"))
    }
    this.assetsService.getUsersList(payload)
      .subscribe(res => {
        this.usersList = res;
        this.isFullyLoaded = true;
        //for (let a of this.usersList) {
        // console.log(a);
        // }
      });
  }


  addUser(form:NgForm) {
    let params: any = {
      UserID: this.addUserModel.userid,
      FirstName: this.addUserModel.fullname,
      LastName: '',
      custId:JSON.parse(localStorage.getItem("customerID")),
      Role: this.userrole,
      Mail: this.addUserModel.useremail,
      Password: ''
    };

    this.assetsService.addUser(params)
      .subscribe(
        (response: any) => {
          this.addedUser = true;
          this.deletedUser = false;
          this.editedUser = false;
          form.reset();
          this.closeAddUserModal.nativeElement.click();
          this.getUsersList();
        },
        (error) => {
          this.addedUserError = true;
        });
  }

  clearUser() {
    this.addedUser = false;
    this.deletedUser = false;
    this.editedUser = false;
  }

  deleteUser() {
    let params: any = {
      UserID: this.uid
    };
    this.assetsService.deleteUser(params)
      .subscribe(
        res => {
          this.deletedUser = true;
          this.getUsersList();
        });
  }

  editUser() {
    let params: any = {
      UserID: this.uid,
      FirstName: this.ufname,
      LastName: this.ulname,
      Role: this.urole,
      Mail: this.umail
    };
    this.assetsService.editUser(params)
      .subscribe(
        (response: any) => {
          this.editedUser = true;
          this.deletedUser = false;
          this.getUsersList();
        },
        (error) => {
          console.log(+error);
        });
  }
}
