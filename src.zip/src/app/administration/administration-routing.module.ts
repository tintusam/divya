import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ManageUserComponent } from './manage-user/manage-user.component';
import { ManageCustomersComponent } from './manage-customers/manage-customers.component';
import { DeviceManagerComponent } from './device-manager/device-manager.component';
import { AssetsManagerComponent } from './assets-manager/assets-manager.component';
import { AdministrationMenuComponent } from './administration-menu/administration-menu.component';
import { AddLocationComponent } from './assets-manager/add-location/add-location.component';
import {AuthGuard} from './../services/auth.service'

const administrationRoutes: Routes = [
    { path: 'administration/manage-user',  component: ManageUserComponent, canActivate:[AuthGuard]},
    { path: 'administration/manage-customers',  component: ManageCustomersComponent, canActivate:[AuthGuard]},
    { path: 'administration/device-manager', component: DeviceManagerComponent,canActivate:[AuthGuard]},
    { path: 'administration/asset-manager', component: AssetsManagerComponent,canActivate:[AuthGuard]},
    { path: 'asset-manager/add-location', component: AddLocationComponent,canActivate:[AuthGuard]},
    { path: 'administration/administration-menu', component: AdministrationMenuComponent,canActivate:[AuthGuard]}
  ];

@NgModule({
  imports: [
    RouterModule.forChild(administrationRoutes)
  ],
  exports:[RouterModule]
})

export class AdministrationRoutingModule { }
