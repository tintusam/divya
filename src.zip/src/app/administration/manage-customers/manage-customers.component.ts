import { Component, OnInit } from '@angular/core';
import { AssetsService } from '../../services/assets.service';
@Component({
  selector: 'app-manage-customers',
  templateUrl: './manage-customers.component.html',
  styleUrls: ['./manage-customers.component.css']
})
export class ManageCustomersComponent implements OnInit {

  constructor(private assetsService: AssetsService) { }
  public usersList;
  public addCustomerModel: any = {};
  public uid;
  public ufname;
  public ulname;
  public urole;
  public umail;
  public firstname;
  public lastname;
  public role;
  public email;
  public uaddress;
  public password;
  public addedUser: boolean = false;
  public addedUserError: boolean = false;
  public deletedUser: boolean = false;
  public editedUser: boolean = false;
  public isFullyLoaded:boolean = false;

  ngOnInit() {
    this.getUsersList();
  }

  setUser(user) {
    console.log(user);
    this.uid = user.UserID;
    this.ufname = user.FirstName;
    this.ulname = user.LastName;
    this.urole = user.Role;
    this.umail = user.Mail
  }

  getUsersList() {
    this.assetsService.getUsersList()
      .subscribe(res => {
        this.usersList = res;
        this.isFullyLoaded = true;
        //for (let a of this.usersList) {
        // console.log(a);
        // }
      });
  }


  addUser() {
    let params: any = {
      customerName: this.addCustomerModel.customername,
      Role: "Customer",
      Mail: this.addCustomerModel.customeremail,
      location: this.addCustomerModel.customeraddress
    };
    console.log(params);
    // this.assetsService.addUser(params)
    //   .subscribe(
    //     (response: any) => {
    //       this.addedUser = true;
    //       this.deletedUser = false;
    //       this.editedUser = false;
    //       this.getUsersList();
    //     },
    //     (error) => {
    //       this.addedUserError = true;
    //     });
  }

  clearUser() {
    this.addedUser = false;
    this.deletedUser = false;
    this.editedUser = false;
  }

  deleteUser() {
    let params: any = {
      UserID: this.uid
    };
    this.assetsService.deleteUser(params)
      .subscribe(
        res => {
          this.deletedUser = true;
          this.getUsersList();
        });
  }

  editUser() {
    console.log(this.addCustomerModel);
    // let params: any = {
    //   UserID: this.uid,
    //   FirstName: this.ufname,
    //   LastName: this.ulname,
    //   Role: this.urole,
    //   Mail: this.umail
    // };
    // this.assetsService.editUser(params)
    //   .subscribe(
    //     (response: any) => {
    //       this.editedUser = true;
    //       this.deletedUser = false;
    //       this.getUsersList();
    //     },
    //     (error) => {
    //       console.log(+error);
    //     });
  }
}
