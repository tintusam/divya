import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { NgForm } from '@angular/forms';
import { AuthenticateService } from 'src/app/services/authenticate.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private _router:Router, private _auth:AuthenticateService) { }

  ngOnInit(): void {
  }

  loginModel: any = {};
  AuthResponse: any;
  email = '';
  password = '';
  authMsg:string ='';

  onSubmit(loginData: NgForm){
    let payload: any = {
      userName: loginData.value.email,
      userPassword: loginData.value.password
    };

    this._auth.authenticateUser(payload).subscribe(
      res => {
        this.AuthResponse = res;
        if(this.AuthResponse.statusCode == 200){
          sessionStorage.setItem("Login", "1");
          localStorage.setItem("fullName", this.AuthResponse.userFullName);
          localStorage.setItem("userEmail", this.AuthResponse.userName);
          localStorage.setItem("userRole", this.AuthResponse.userType);
          localStorage.setItem("vendorCode", this.AuthResponse.vendorCode);
          this._router.navigateByUrl('management');
        }
        else{
          this.email = '';
          this.password = ''; 
          this.authMsg = "Invalid User";
        }

        console.log(this.AuthResponse);
        

      },
      err => {
        if(err.status == 500){
          console.log('remote servers not responding');
        }else if(err.status == 404){
          console.log('not found');
        }
        console.log(err);
      })

      // this.AuthResponse = {
      //   Message: "User authenticated",
      //   U_Fullname:"Divya Gopinath",
      //   U_UserType:"Admin",
      //   U_VendorCode:"123456"
      // }

    

      //   if (this.AuthResponse.Message === 'User authenticated') {
      //     sessionStorage.setItem("Login", "1");
      //     sessionStorage.setItem("fullName", this.AuthResponse.U_Fullname);
      //     sessionStorage.setItem("userRole", this.AuthResponse.U_UserType);
      //     sessionStorage.setItem("vendorCode", this.AuthResponse.U_VendorCode);
      //   this._auth.setLogin(true);
      //   this._router.navigateByUrl('management');
      // }else{
      //   this.email = '';
      //   this.password = ''; 
      //   this._router.navigateByUrl('');    
      // }

    
  }

}
