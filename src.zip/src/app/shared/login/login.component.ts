import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { NgForm } from '@angular/forms';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private _router:Router) { }

  ngOnInit(): void {
  }

  loginModel: any = {};

  onSubmit(loginData: NgForm){
    let payload: any = {
      'Mail': loginData.value.email,
      'Password': loginData.value.password
    };
    console.log(payload);
    this._router.navigateByUrl('management');
    
  }

}
