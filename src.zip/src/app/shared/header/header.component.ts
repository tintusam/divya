import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  public showMenu:boolean = false;
  constructor(private _router:Router) { }

  ngOnInit(): void {
  }

  toggleActionMenu(){
    this.showMenu = !this.showMenu;
    console.log(this.showMenu);
  }

  logout(){
    this.showMenu = false;
    this._router.navigateByUrl('login');
  }

}
