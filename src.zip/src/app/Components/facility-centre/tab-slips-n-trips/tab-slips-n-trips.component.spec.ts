import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TabSlipsNTripsComponent } from './tab-slips-n-trips.component';

describe('TabSlipsNTripsComponent', () => {
  let component: TabSlipsNTripsComponent;
  let fixture: ComponentFixture<TabSlipsNTripsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TabSlipsNTripsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TabSlipsNTripsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
