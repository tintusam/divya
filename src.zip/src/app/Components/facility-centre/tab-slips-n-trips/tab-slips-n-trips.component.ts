import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tab-slips-n-trips',
  templateUrl: './tab-slips-n-trips.component.html',
  styleUrls: ['./tab-slips-n-trips.component.scss']
})
export class TabSlipsNTripsComponent implements OnInit {
  patientList = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
  constructor() { }

  ngOnInit(): void {
  }

}
