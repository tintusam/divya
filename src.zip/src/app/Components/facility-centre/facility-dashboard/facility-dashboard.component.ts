import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-facility-dashboard',
  templateUrl: './facility-dashboard.component.html',
  styleUrls: ['./facility-dashboard.component.scss']
})
export class FacilityDashboardComponent implements OnInit {
  zoneList = [1, 1, 1, 1, 1, 2, 11, 1, 1, 1, 1, 1, 1, 1, 1, 234, 11, 1, 1, 1, 1, 1, 1, 1, 1, 234]
  facilityList = [1, 2, 3, 4, 5, 6, 7, 8];

  dropdownFacilityList = ["Maudsley Hospital", "Bethlem Royal Hospital ", "Lambeth Hospital"]
  selectedFacility = 'Maudsley  Hospital'
  showWardOverlay = true
  constructor() { }

  ngOnInit(): void {
  }

}
