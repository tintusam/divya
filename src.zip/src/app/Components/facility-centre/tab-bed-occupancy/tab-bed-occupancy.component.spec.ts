import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TabBedOccupancyComponent } from './tab-bed-occupancy.component';

describe('TabBedOccupancyComponent', () => {
  let component: TabBedOccupancyComponent;
  let fixture: ComponentFixture<TabBedOccupancyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TabBedOccupancyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TabBedOccupancyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
