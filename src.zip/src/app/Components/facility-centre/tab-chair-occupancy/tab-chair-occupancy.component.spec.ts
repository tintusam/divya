import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TabChairOccupancyComponent } from './tab-chair-occupancy.component';

describe('TabChairOccupancyComponent', () => {
  let component: TabChairOccupancyComponent;
  let fixture: ComponentFixture<TabChairOccupancyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TabChairOccupancyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TabChairOccupancyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
