import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tab-chair-occupancy',
  templateUrl: './tab-chair-occupancy.component.html',
  styleUrls: ['./tab-chair-occupancy.component.scss']
})
export class TabChairOccupancyComponent implements OnInit {
  patientList = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]

  constructor() { }

  ngOnInit(): void {
  }

}
