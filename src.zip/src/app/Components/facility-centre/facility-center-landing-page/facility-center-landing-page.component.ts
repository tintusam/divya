import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-facility-center-landing-page',
  templateUrl: './facility-center-landing-page.component.html',
  styleUrls: ['./facility-center-landing-page.component.scss']
})
export class FacilityCenterLandingPageComponent implements OnInit {

  facilityList = [1, 1, 1, 1, 1, 2, 11, 1, 1, 1, 1, , 1, 1, 1, 1, 1, 2, 11, 1, 1, 1, 1, 1, 1, 1, 1, 234, 11, 1, 1, 1, 1, 1, 1, 1, 1, 234]
  constructor() { }

  ngOnInit(): void {
  }

}
