import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TabTemperatureComponent } from './tab-temperature.component';

describe('TabTemperatureComponent', () => {
  let component: TabTemperatureComponent;
  let fixture: ComponentFixture<TabTemperatureComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TabTemperatureComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TabTemperatureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
