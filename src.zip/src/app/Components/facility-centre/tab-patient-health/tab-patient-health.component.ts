import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tab-patient-health',
  templateUrl: './tab-patient-health.component.html',
  styleUrls: ['./tab-patient-health.component.scss']
})
export class TabPatientHealthComponent implements OnInit {
  patientList = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]

  constructor() { }

  ngOnInit(): void {
  }

}
