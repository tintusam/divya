import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WardOverlayComponent } from './ward-overlay.component';

describe('WardOverlayComponent', () => {
  let component: WardOverlayComponent;
  let fixture: ComponentFixture<WardOverlayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WardOverlayComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WardOverlayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
