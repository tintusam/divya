import { Component, OnInit, Input } from '@angular/core';
import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';
import { Label } from 'ng2-charts';
import { AppService } from '../../../Utilities/app.service';
import * as moment from 'moment'
@Component({
  selector: 'app-weekly-chart',
  templateUrl: './weekly-chart.component.html',
  styleUrls: ['./weekly-chart.component.scss']
})
export class WeeklyChartComponent implements OnInit {
  public barChartOptions: ChartOptions;
  public barChartLabels: Label[];
  public barChartType: ChartType;
  public barChartLegend;
  public barChartPlugins = [];
  public barChartData: ChartDataSets[]
  selfDecalredData: any = [];
  remainingData: any = [];
  responseOnject: any;
  showChart = false;
  dateArray: any = [];
  graphMsg:String;
  public isGraphDataAvailable:boolean = false;

  constructor(private app: AppService) {
  //  this.selfDecalredData = [];
   // this.remainingData = [];
   // this.dateArray = [];
  }

  private _siteSelected:any;

  @Input() set siteSelected(value: any) {
   this._siteSelected = value;
   if(this._siteSelected != undefined){
      this.onLoadWeeklyChart(this._siteSelected);
   }
 }

  get siteSelected(): any {
    return this._siteSelected;
 }

  ngOnInit() {
   this.selfDecalredData = [];
   this.remainingData = [];
   this.dateArray = [];
  }

onLoadWeeklyChart(selectedSite){
  this.app.getGraphCounts({ "toDate": "week","siteName":selectedSite }).subscribe(res => {
    this.responseOnject = res;
    //console.log(this.responseOnject);
    if (this.responseOnject == ''){
      this.graphMsg = "No Data Available";
      this.isGraphDataAvailable = false; 
      this.showChart = false;
    }else{
      this.isGraphDataAvailable = true;
      this.selfDecalredData = [];
      this.remainingData = [];
      this.dateArray = [];
      for (let item of this.responseOnject) {
        this.selfDecalredData.push(item.selfDeclareEmployee);
        this.remainingData.push(item.remainingEmployee);
        this.dateArray.push(moment(item.updatedDATE).format("Do MMM YYYY"));
        this.chartFunction();
        this.showChart = true;
      }      
    }

  })
}


  chartFunction() {
    this.barChartOptions = {
      responsive: true,
    };
    this.barChartType = 'bar';
    this.barChartLegend = true;

    // static graph values starts here
/*     this.barChartLabels= ['2006', '2007', '2008', '2009', '2010', '2011', '2012'];
    this.barChartData = [
      {
        data: [65, 59, 80, 81, 56, 55, 40], label: 'Undeclared'
      }, {
        data: [48, 48, 40, 19, 86, 27, 90], label: 'Self Declared'
      }
    ] */


    // dynamic values from Get Graph API

    // console.log(this.dateArray); // ["30th Jul 2020"]
    // console.log(this.remainingData); //[20]
    // console.log(this.selfDecalredData); //[2]

    // dynamic plotting of graph starts here

    this.barChartLabels = this.dateArray;
    this.barChartData = [
      {
        data: this.remainingData, label: 'Undeclared'
      }, {
        data: this.selfDecalredData, label: 'Self Declared'
      }
    ]

  }
}
