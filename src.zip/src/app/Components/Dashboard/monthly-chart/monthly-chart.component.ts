import { Component, OnInit } from '@angular/core';
import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';
import { Label } from 'ng2-charts';
import { AppService } from '../../../Utilities/app.service';
import * as moment from 'moment'
@Component({
  selector: 'app-monthly-chart',
  templateUrl: './monthly-chart.component.html',
  styleUrls: ['./monthly-chart.component.scss']
})
export class MonthlyChartComponent implements OnInit {

  public barChartOptions: ChartOptions;
  public barChartLabels: Label[];
  public barChartType: ChartType;
  public barChartLegend;
  public barChartPlugins = [];

  // public chartColors = [
  //   { // first color
  //     backgroundColor: 'rgba(225,10,24,0.2)',
  //     borderColor: 'rgba(225,10,24,0.2)',
  //     pointBackgroundColor: 'rgba(225,10,24,0.2)',
  //     pointBorderColor: '#fff',
  //     pointHoverBackgroundColor: '#fff',
  //     pointHoverBorderColor: 'rgba(225,10,24,0.2)'
  //   },
  //   { // second color
  //     backgroundColor: 'rgba(225,10,24,0.2)',
  //     borderColor: 'rgba(225,10,24,0.2)',
  //     pointBackgroundColor: 'rgba(225,10,24,0.2)',
  //     pointBorderColor: '#fff',
  //     pointHoverBackgroundColor: '#fff',
  //     pointHoverBorderColor: 'rgba(225,10,24,0.2)'
  //   }
  // ]

  public barChartData: ChartDataSets[]
  selfDecalredData: any;
  remainingData: any;
  responseOnject: any;
  showChart = false;
  dateArray: any;
  constructor(private app: AppService) {
    this.selfDecalredData = [];
    this.remainingData = [];
    this.dateArray = []
    this.app.getGraphCounts({ "toDate": "month" }).subscribe(res => {
      // console.log((res))
      this.responseOnject = res
      for (let item of this.responseOnject) {
        this.selfDecalredData.push(item.selfDeclareEmployee);
        this.remainingData.push(item.remainingEmployee);
        this.dateArray.push(moment(item.updatedDATE).format("Do MMM YYYY"));
        this.chartFunction();
        this.showChart = true;
      }
    })
  }

  ngOnInit() {
  }

  chartFunction() {
    this.barChartOptions = {
      responsive: true,

    };
    this.barChartLabels = this.dateArray;
    this.barChartType = 'bar';
    this.barChartLegend = true;
    this.barChartData = [
      {
        data: this.remainingData, label: 'Undeclared'
      }, {
        data: this.selfDecalredData, label: 'Self Declared'
      }
    ]
  }

}
