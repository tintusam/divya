import { Component, OnInit } from '@angular/core';
import { AppService } from 'src/app/Utilities/app.service'

@Component({
  selector: 'app-dashboard-landing-page',
  templateUrl: './dashboard-landing-page.component.html',
  styleUrls: ['./dashboard-landing-page.component.scss']
})
export class DashboardLandingPageComponent implements OnInit {
  SiteList: any;
  responseObject: any;
  totalEmployees = 0;
  remainingEmp = 0;
  selfDeclaredCount = 0
  constructor(private app: AppService) {
    this.app.getEmployeeCount().subscribe(res => {
      // console.log(res)
      this.responseObject = res;
      this.totalEmployees = this.responseObject[0].totalEmployee;
      this.remainingEmp = this.responseObject[0].remainingEmployee;
      this.selfDeclaredCount = this.responseObject[0].selfDeclareEmployee
    })
  }

  ngOnInit() {
    this.SiteList = [
      {
        siteName: 'Texas',
        selfDecaredEmployees: 220,
        remainingEmployees: 300,
        totalEmployees: 520
      },
      {
        siteName: 'Houston',
        selfDecaredEmployees: 150,
        remainingEmployees: 250,
        totalEmployees: 400
      },
      {
        siteName: 'Chicago',
        selfDecaredEmployees: 250,
        remainingEmployees: 300,
        totalEmployees: 550
      }, {
        siteName: 'Palo Alto',
        selfDecaredEmployees: 320,
        remainingEmployees: 500,
        totalEmployees: 820
      },
    ]
  }

}
