import { Component, OnInit } from '@angular/core';
import { AppService } from '../../../Utilities/app.service';
import { NgForm } from '@angular/forms';
declare const $: any;
@Component({
  selector: 'app-dashboard-landing-page',
  templateUrl: './dashboard-landing-page.component.html',
  styleUrls: ['./dashboard-landing-page.component.scss']
})
export class DashboardLandingPageComponent implements OnInit {
  SiteList: any;
  siteNameModel: any = {};
  responseObject: any;
  totalEmployees:number = 0;
  remainingEmp:number = 0;
  selfDeclaredCount:number = 0;
  failureCount:number = 0;
  successCount:number = 0;
  public addSiteMsg:string='';
  public supervisorList:any;
  public initialSite:any;
  showAddSiteForm:boolean = true;
  public activeClass:boolean = false;
  public userRole:string;
  public siteID:any;

  constructor(private app: AppService) {

  }

  ngOnInit() {
    this.userRole = sessionStorage.getItem('userRole');
    this.siteID = sessionStorage.getItem('siteID');
    this.siteID = JSON.parse(this.siteID);
    if(this.siteID){
      this.listAllSites(this.siteID);
      this.onFetchAllSupervisors(this.siteID);
    }else{
      this.listAllSites(0);
      this.onFetchAllSupervisors(0);
    }   
  }

  ngAfterViewInit(){
    $(document).ready(function(){
      $("list-items").eq(0).addClass('active');
    })
  }

    // to clear add site form
    resetForm(){
      this.showAddSiteForm = true;
      this.addSiteMsg = '';
    }

 getEmployeeCount(selectedSiteName){
  let payload = {
    "siteName":selectedSiteName
  }; 
  this.app.getEmployeeCount(payload).subscribe(res => {
    this.responseObject = res;
    this.totalEmployees = this.responseObject[0].totalEmployee;
    this.remainingEmp = this.responseObject[0].remainingEmployee;
    this.selfDeclaredCount = this.responseObject[0].selfDeclareEmployee;
    this.failureCount = this.responseObject[0].failureCount;
    this.successCount = this.responseObject[0].successCount;
  })
 } 

 listAllSites(siteID){
   console.log(siteID);
   let payload = {
    'siteid':siteID
  }   
   this.app.listAllSites(payload).subscribe(
     res => {
       this.SiteList = res;
       this.initialSite = this.SiteList[0].siteName;
       this.getEmployeeCount(this.initialSite);
     },
     err =>{
       console.log(err);
     }
   )
 }

 highlightItem(itemNumber) {
   var itemNumber = itemNumber +1;
   $(document).ready(function(){
      $(".list-items").removeClass('active');
      $(".list-items:nth-of-type("+itemNumber+")").addClass('active');
  });  
}

  loadSiteInfo(selectedSiteName){
    this.initialSite = selectedSiteName;
    this.getEmployeeCount(selectedSiteName);
  }

  onFetchAllSupervisors(siteID){
    console.log(siteID);
    let payload = {
      'siteid':siteID
    }
    this.app.getAllSupervisors(payload).subscribe(
      res => {
        this.supervisorList = res;
      },
      err => {
        console.log(err);
      })
  }

  onDeleteSite(siteToDelete){
    let payload: any = {
      'siteName':siteToDelete     
    };
    this.app.deleteSite(payload).subscribe(
      res => {
        console.log(res);
        this.listAllSites(); 
      },
      err => {
        console.log(err);
      }

    )
  }

  onAddSite(siteData: NgForm){
    let payload: any = {
      'siteName': siteData.value.siteName,      
      'totalEmployeeCount': siteData.value.empCount
      
    };
    this.app.createSite(payload).subscribe(res =>{
        this.addSiteMsg="Site added successfully";
        this.showAddSiteForm = false;
        this.listAllSites();
        siteData.reset();   
    },
    err=> {
      this.showAddSiteForm = false;
      siteData.reset();
      if(err.status==500)
      {
        this.addSiteMsg="Remote servers are not responding at the moment. Please try after sometime"
      }
      console.log(err);
    })
  }

}
