import { Component, OnInit, Input } from '@angular/core';
import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';
import { Label } from 'ng2-charts';
import { AppService } from '../../../Utilities/app.service';
import { StorageService } from '../../../Utilities/storage.service';
import * as moment from 'moment'
@Component({
  selector: 'app-filtered-chart',
  templateUrl: './filtered-chart.component.html',
  styleUrls: ['./filtered-chart.component.scss']
})
export class FilteredChartComponent implements OnInit {

  public barChartOptions: ChartOptions;
  public barChartLabels: Label[];
  public barChartType: ChartType;
  public barChartLegend;
  public barChartPlugins = [];

  public graphMsg:String;
  public isGraphDataAvailable:boolean = false;
  public barChartData: ChartDataSets[]
  selfDecalredData: any;
  remainingData: any;
  responseOnject: any;
  showChart = false;
  dateArray: any;

  constructor(private app: AppService, private _storageService:StorageService) {
  }

  ngOnInit() {
    this.selfDecalredData = [];
    this.remainingData = [];
    this.dateArray = [];
    this.onLoadFilteredChart(this._storageService.getScope())
  }


  onLoadFilteredChart(selectedSite){
    //console.log(selectedSite);
    this.app.getGraphByFilter(selectedSite).subscribe(res => {
      // console.log((res))
      this.responseOnject = res;
      if (this.responseOnject == ''){
        this.graphMsg = "No Data Available";
        this.isGraphDataAvailable = false; 
        this.showChart = false;        
      }else{
        this.isGraphDataAvailable = true;
        this.selfDecalredData = [];
        this.remainingData = [];
        this.dateArray = [];   
        for (let item of this.responseOnject) {
          this.selfDecalredData.push(item.selfDeclareEmployee);
          this.remainingData.push(item.remainingEmployee);
          this.dateArray.push(moment(item.updatedDATE).format("Do MMM YYYY"));
          this.chartFunction();
          this.showChart = true;
        }             
      }      
    })
  }

  chartFunction() {
    this.barChartOptions = {
      responsive: true,

    };
    this.barChartLabels = this.dateArray;
    this.barChartType = 'bar';
    this.barChartLegend = true;
    this.barChartData = [
      {
        data: this.remainingData, label: 'Undeclared'
      }, 
      {
        data: this.selfDecalredData, label: 'Self Declared'
      }
    ]
  }

}
