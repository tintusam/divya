import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminPortalRoutingModule } from './admin-portal-routing.module';
import { AdminPortalLandingPageComponent } from './admin-portal-landing-page/admin-portal-landing-page.component';
import { DeviceManagementComponent } from './device-management/device-management.component';
import { UserManagementComponent } from './user-management/user-management.component';
import { FacultyManagementComponent } from './faculty-management/faculty-management.component';
import { CommunitycenterManagementComponent } from './communitycenter-management/communitycenter-management.component';
import { GatewaysComponent } from './device-management/gateways/gateways.component';
import { SensorsComponent } from './device-management/sensors/sensors.component';
import { ScannersComponent } from './device-management/scanners/scanners.component';



@NgModule({
  declarations: [AdminPortalLandingPageComponent, DeviceManagementComponent, UserManagementComponent, FacultyManagementComponent, CommunitycenterManagementComponent, GatewaysComponent, SensorsComponent, ScannersComponent],
  imports: [
    TooltipModule.forRoot(),
    CommonModule,
    AdminPortalRoutingModule,
    ReactiveFormsModule,
    FormsModule
  ]
})
export class AdminPortalModule { }
