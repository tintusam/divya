import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-communitycenter-management',
  templateUrl: './communitycenter-management.component.html',
  styleUrls: ['./communitycenter-management.component.scss']
})
export class CommunitycenterManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

public clearUser(){}

}
