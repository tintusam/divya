import { Component, OnInit, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
//import * as moment from 'moment';
//import 'moment-timezone';

@Component({
  selector: 'app-faculty-management',
  templateUrl: './faculty-management.component.html',
  styleUrls: ['./faculty-management.component.scss']
})
export class FacultyManagementComponent implements OnInit {

  public editFacilityName:boolean = false;
  public editWard:boolean = false;
  public wardMapResponse:any = {};
  public markerResponse:any = {};
  public imageRefUrl:any;
  public zones = [];
  public pos = [];
  public zoneInfoResponse:any = {};
  public showPopup:boolean = false;
  public ZoneForm: FormGroup;
  public posx;
  public posy;
  public GatewayList: any;
  public AddZoneForm:FormGroup;
  public addZoneNew:FormGroup;
  public showZoneInfo:boolean = false;

  constructor(private fb: FormBuilder, private el: ElementRef) {
    this.ZoneForm = this.fb.group({
      zoneName: [null, Validators.required],
      Threshold: [null, Validators.required],
      bleGatewaySno: [null, Validators.required]
    });

    this.AddZoneForm = this.fb.group({
    });

    this.addZoneNew = this.fb.group({
    });


   }

  ngOnInit(): void {

    this.showWardMap();

  }

  clearUser(){}


  // Method to get location point 
  onGetLocationPoints(e) {
    this.showPopup = true;
    this.ZoneForm.reset();
    if (this.imageRefUrl) {
      var svg = this.el.nativeElement.querySelector('#mySvg');
      var pt = svg.createSVGPoint();
      pt.x = e.clientX; //x position within the element.
      pt.y = e.clientY;
      var svgP = pt.matrixTransform(svg.getScreenCTM().inverse());
      this.posx = svgP.x;
      this.posy = svgP.y;
      //console.log(this.posx, this.posy)
    }
  }


  onSaveZones(post) {
    //console.log(post);
     if (post.zoneName && post.bleGatewaySno && post.Threshold) {
       this.pos.push({ x: this.posx, y: this.posy });
       this.zones.push({
         ZoneName: post.zoneName,
         GatewaySlNo: post.bleGatewaySno,
         Top: this.posy,
         Left: this.posx,
         Threshold : JSON.parse(post.Threshold)
       });
       //console.log(this.zones);
     }
   }

showWardMap(){
  this.wardMapResponse = {
    "FacilityID": 19,
    "FacilityName": "A",
    "Location": "Banglore",
    "ImageUrl": "https://usfoodsteststorage.blob.core.windows.net/facilityimage/SLM_TEST_IMG.png",
    "ZoneCount": 4,
    "Status": "Active",
    "Zones": [
      // {
      //   "ZoneID": 109,
      //   "ZoneName": "Entry Zone",
      //   "ZoneType": "Green",
      //   "GatewaySlNo": "GTA001",
      //   "Top": "234.96527099609375",
      //   "Left": "26.711198806762695",
      //   "Threshold": 1,
      //   "EmpCountinZone": 0
      // },
      // {
      //   "ZoneID": 110,
      //   "ZoneName": "Exit Zone 2",
      //   "ZoneType": "Green",
      //   "GatewaySlNo": "GTA001",
      //   "Top": "227.60069274902344",
      //   "Left": "302.3570251464844",
      //   "Threshold": 1,
      //   "EmpCountinZone": 0
      // },
      // {
      //   "ZoneID": 111,
      //   "ZoneName": "ZONED",
      //   "ZoneType": "Green",
      //   "GatewaySlNo": "GTA001",
      //   "Top": "212.17013549804688",
      //   "Left": "109.8257827758789",
      //   "Threshold": 1,
      //   "EmpCountinZone": 0
      // },
      {
        "ZoneID": 112,
        "ZoneName": "test zone",
        "ZoneType": "Green",
        "GatewaySlNo": "GTA001",
        "Top": "98.19444274902344",
        "Left": "119.2945327758789",
        "Threshold": 1,
        "EmpCountinZone": 0
      }
    ]
  };

  if(this.wardMapResponse){
    this.imageRefUrl = this.wardMapResponse.ImageUrl;
    this.zones = this.wardMapResponse.Zones;
    //console.log(this.imageRefUrl);
  }
}

close(){

}

onSaveSensor(){
  alert('Saved Successfully!');
  this.showZoneInfo = false;
  this.showPopup = false;
}

onGetZoneInfo(zone, i) {
  this.showZoneInfo = true;
  this.markerResponse = {
    "type": "Gateway Router",
    "WardName": "WRD023345",
    "SerialNumber": "SL3456789AB34"
  }
}

}
