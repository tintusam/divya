import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-device-management',
  templateUrl: './device-management.component.html',
  styleUrls: ['./device-management.component.scss']
})
export class DeviceManagementComponent implements OnInit {

  constructor(private _router:Router) { }

  ngOnInit(): void {
  }

  wearbles(){
    this._router.navigate(['admin/device-management/gateways']);
  }

  clearUser(){}

}
