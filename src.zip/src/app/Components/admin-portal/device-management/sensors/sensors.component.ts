import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

declare var jQuery: any;

@Component({
  selector: 'app-sensors',
  templateUrl: './sensors.component.html',
  styleUrls: ['./sensors.component.scss']
})
export class SensorsComponent implements OnInit {

  constructor(private _router:Router) { }

  ngOnInit(): void {
    jQuery('[data-toggle="tooltip"]').tooltip();
  }

  wearbles(){
    this._router.navigate(['admin/device-management/gateways']);
  }

}
