import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-scanners',
  templateUrl: './scanners.component.html',
  styleUrls: ['./scanners.component.scss']
})
export class ScannersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
