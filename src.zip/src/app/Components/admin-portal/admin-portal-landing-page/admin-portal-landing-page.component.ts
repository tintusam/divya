import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-portal-landing-page',
  templateUrl: './admin-portal-landing-page.component.html',
  styleUrls: ['./admin-portal-landing-page.component.scss']
})
export class AdminPortalLandingPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
