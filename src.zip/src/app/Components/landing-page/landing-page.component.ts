import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'
@Component({
  selector: 'app-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.scss']
})
export class LandingPageComponent implements OnInit {
  showLoader = true;
  EmployeeID = '';
  constructor(private router: Router) {
    this.router.navigate(['login'])

  }

  ngOnInit() {
    this.EmployeeID = sessionStorage.getItem('EmployeeId')

    if (this.EmployeeID) {
      this.router.navigate(['action-center'])
    } else {
      setTimeout(() => {
        this.showLoader = false;
      }, 2800)
      setTimeout(() => {
        this.router.navigate(['login'])
      }, 3000)
    }
  }

}
