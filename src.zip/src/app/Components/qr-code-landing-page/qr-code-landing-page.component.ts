import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'

@Component({
  selector: 'app-qr-code-landing-page',
  templateUrl: './qr-code-landing-page.component.html',
  styleUrls: ['./qr-code-landing-page.component.scss']
})
export class QrCodeLandingPageComponent implements OnInit {

  email = ''
  constructor(private router: Router) { }

  ngOnInit() {
    this.email = sessionStorage.getItem('email')
    // console.log(this.email);
    if (this.email === '') {
      this.router.navigate(['landing-page'])
    }
    this.router.navigate(['action-center']) // Comment this Later
    // this.router.navigate(['action-center/generate-QR-code'])
  }

  signOut() {
    sessionStorage.clear();
    this.router.navigate(['landing-page'])
  }
}
