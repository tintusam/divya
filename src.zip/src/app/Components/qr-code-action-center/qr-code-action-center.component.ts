import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'
@Component({
  selector: 'app-qr-code-action-center',
  templateUrl: './qr-code-action-center.component.html',
  styleUrls: ['./qr-code-action-center.component.scss']
})
export class QrCodeActionCenterComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
    this.router.navigate(['action-center/generate-QR-code'])
  }
  ViewQRCode() {
    this.router.navigate(['action-center/view-QR-code'])
  }
  GenerateQRCode() {
    this.router.navigate(['action-center/generate-QR-code'])
  }
}
