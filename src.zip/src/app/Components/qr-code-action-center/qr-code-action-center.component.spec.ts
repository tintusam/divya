import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QrCodeActionCenterComponent } from './qr-code-action-center.component';

describe('QrCodeActionCenterComponent', () => {
  let component: QrCodeActionCenterComponent;
  let fixture: ComponentFixture<QrCodeActionCenterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QrCodeActionCenterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QrCodeActionCenterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
