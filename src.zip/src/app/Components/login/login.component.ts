import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { NgForm } from '@angular/forms';
import { AuthenticateService} from '../../Utilities/authenticate.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  constructor(private _router:Router, private _auth:AuthenticateService) { }

  ngOnInit(): void {
  }

  loginModel: any = {};
  AuthResponse: any;
  email = '';
  password = '';

  onSubmit(loginData: NgForm){
    let payload: any = {
      'LoggedInEmail': loginData.value.email,
      'Password': loginData.value.password
    };
    //console.log(JSON.stringify(payload));

    this._auth.authenticateUser(payload).subscribe(res => {
      console.log('Auth', res);
      this.AuthResponse = res["body"];
      console.log(this.AuthResponse);

      // if (this.AuthResponse.Message === 'Invalid user') {
      //   alert('Invalid Username and Password.Please Enter Valid Username and Password');
      //   this.email = '';
      //   this.password = '';

      // }
      // if (this.AuthResponse.Message === 'User authenticated') {
      //   sessionStorage.setItem("Login", "1");
      //   sessionStorage.setItem("userEmail", this.AuthResponse.loggedInEmail);
      //   sessionStorage.setItem("userRole", this.AuthResponse.Role);
      //   this._auth.setLogin(true);
      //   this._router.navigateByUrl('dashboard');
      // }

    });
    
  }

}
