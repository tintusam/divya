import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { NgForm } from '@angular/forms';
import { AuthenticateService} from '../../Utilities/authenticate.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  constructor(private _router:Router, private _auth:AuthenticateService) { }

  ngOnInit(): void {
  }

  loginModel: any = {};
  AuthResponse: any;
  email = '';
  password = '';
  validationMessage:String;

  onSubmit(loginData: NgForm){
    let payload: any = {
      'LoggedInEmail': loginData.value.email,
      'Password': loginData.value.password
    };
   this._auth.authenticateUser(payload).subscribe(res => {
      this.AuthResponse = res;
      if (this.AuthResponse.Status === 'OK') {
        sessionStorage.setItem("Login", "1");
        sessionStorage.setItem("userEmail", this.AuthResponse.loggedInEmail);
        sessionStorage.setItem("userRole", this.AuthResponse.Role);
        this._auth.setLogin(true);
        this.AuthResponse.Message = this.AuthResponse.Response;
        this._router.navigateByUrl('dashboard');
      }else{
         this.email = '';
         this.password = '';  
         this.validationMessage = "User Does Not Exist!";
         //this._router.navigateByUrl('');      
      }
    });    
  }

}