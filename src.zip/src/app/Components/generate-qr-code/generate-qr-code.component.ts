import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AppService } from '../../Service/app.service';
@Component({
  selector: 'app-generate-qr-code',
  templateUrl: './generate-qr-code.component.html',
  styleUrls: ['./generate-qr-code.component.scss']
})
export class GenerateQRCodeComponent implements OnInit {
  showLoader = false;
  Location: string;
  EmployeeId: string;
  showFirstNext = true;
  showSecondNext = false;
  showThirdNext = false;
  showFourthNext = false;
  ResponseObject: any;
  showResponse = false;
  showBarcode = false;
  Q1Answer: string;
  Q2Answer: string;
  Q3Answer: string;
  Q4Answer: string;
  Q5Answer: string;
  Q6Answer: string;
  Q7Answer: string;
  Q8Answer: string;
  Q9Answer: string;
  Q10Answer: string;
  Q11Answer: string;
  wrongResponses: any;
  requestPayload: any;
  rightResponses: any;
  finalResponseArray: any;
  emailId = sessionStorage.getItem('email')
  constructor(private app: AppService) { }

  ngOnInit() {
    this.wrongResponses = [];
    this.rightResponses = [];
    this.finalResponseArray = [];
    this.showResponse = false;
    this.showBarcode = false;
    this.EmployeeId = sessionStorage.getItem('EmployeeId');
    this.Location = sessionStorage.getItem('storeId')
    this.Q1Answer = '';
    this.Q2Answer = '';
    this.Q3Answer = '';
    this.Q4Answer = '';
    this.Q5Answer = '';
    this.Q6Answer = '';
    this.Q7Answer = '';
    this.Q8Answer = '';
    this.Q9Answer = '';
    this.Q10Answer = '';
    this.Q11Answer = '';
  }

  showSecondNextButton() {
    // || this.Q3Answer === ''
    if (this.Q1Answer === '' || this.Q2Answer === '') {
      alert('Please Answer All the Questions')
    } else {
      this.showFirstNext = false;
      this.showSecondNext = true;
      this.showThirdNext = false;
      this.showFourthNext = false
    }

  }

  showThirdNextButton() {
    if (this.Q4Answer === '' || this.Q5Answer === '' || this.Q6Answer === '') {
      alert('Please Answer All the Questions')
    } else {
      this.showFirstNext = false;
      this.showSecondNext = false;
      this.showThirdNext = true;
      this.showFourthNext = false
    }
  }

  showFourthNextButton() {
    if (this.Q7Answer === '' || this.Q8Answer === '' || this.Q9Answer === '') {
      alert('Please Answer All the Questions')
    } else {
      this.showFirstNext = false;
      this.showSecondNext = false;
      this.showThirdNext = false;
      this.showFourthNext = true;
    }
  }

  SubmitEmployeeQA() {
    this.showLoader = true;
    if (this.Q1Answer === 'I have not volunteered to come to office') {
      this.wrongResponses.push({

        Question: "Please choose appropriate option",
        Answer: 'I have not volunteered to come to office',
        AnswerStatus: 'Failure'

      })
    } else if (this.Q1Answer === 'I am coming to office vountarily') {
      this.rightResponses.push({
        Question: "Please choose appropriate option",
        Answer: 'I am coming to office vountarily',
        AnswerStatus: 'Success'
      })
    }


    if (this.Q2Answer === 'I have one of these symptoms - Fever, Dry cough, Body Ache, Headaches, Sore throat, Runny Nose, Tiredness, and Shortness of Breath') {
      this.wrongResponses.push({
        Question: "Please select relevant option",
        Answer: 'I have one of these symptoms - Fever, Dry cough, Body Ache, Headaches, Sore throat, Runny Nose, Tiredness, and Shortness of Breath',
        AnswerStatus: 'Failure'

      })
    } else if (this.Q2Answer === 'I am Healthy') {
      this.rightResponses.push({
        Question: "Please select relevant option",
        Answer: ' I am Healthy',
        AnswerStatus: 'Success'
      })
    }

    if (this.Q4Answer === 'Yes') {
      this.wrongResponses.push({

        Question: "Have you been in contact with a confirmed COVID-19 patient in past 28 Days?",
        Answer: 'Yes',
        AnswerStatus: 'Failure'

      })
    } else if (this.Q4Answer === 'No') {
      this.rightResponses.push({
        Question: "Have you been in contact with a confirmed COVID-19 patient in past 28 Days?",
        Answer: 'No',
        AnswerStatus: 'Success'
      })
    }

    if (this.Q5Answer === 'Yes') {
      this.wrongResponses.push({

        Question: "Have you been to COVID-19 affected countries or hot spots inside the country in past 28 days?",
        Answer: 'Yes',
        AnswerStatus: 'Failure'

      })
    } else if (this.Q5Answer === 'No') {
      this.rightResponses.push({
        Question: "Have you been to COVID-19 affected countries or hot spots inside the country in past 28 days?",
        Answer: 'No',
        AnswerStatus: 'Success'
      })
    }

    if (this.Q6Answer === 'Deny') {
      this.wrongResponses.push({

        Question: "Declaration: If I have any symptoms like -Fever,Dry Cough,Body Ache, Headaches,Sore throat, Runny Nose, Tiredness,Shortness of Breath or related symptoms, I will NOT come to office",
        Answer: 'Deny',
        AnswerStatus: 'Failure'

      })
    } else if (this.Q6Answer === 'Accept') {
      this.rightResponses.push({
        Question: "Declaration: If I have any symptoms like -Fever,Dry Cough,Body Ache, Headaches,Sore throat, Runny Nose, Tiredness,Shortness of Breath or related symptoms, I will NOT come to office",
        Answer: 'Accept',
        AnswerStatus: 'Success'
      })
    }


    if (this.Q7Answer === 'Deny') {
      this.wrongResponses.push({

        Question: "Declaration: I agree to abide by the Social Media Policy of Wipro (For details, please visit the Social Media Policy in the Suraksha app in myWipro)",
        Answer: 'Deny',
        AnswerStatus: 'Failure'

      })
    } else if (this.Q7Answer === 'Accept') {
      this.rightResponses.push({
        Question: "Declaration: I agree to abide by the Social Media Policy of Wipro (For details, please visit the Social Media Policy in the Suraksha app in myWipro)",
        Answer: 'Accept',
        AnswerStatus: 'Success'
      })
    } if (this.Q8Answer === 'Yes' && this.Q11Answer == 'No') {
      this.wrongResponses.push({

        Question: "Have you returned back from any other city,district or state to your work location during the last 15 days",
        Answer: 'Yes',
        AnswerStatus: 'Failure'

      })

      this.wrongResponses.push({

        Question: "Have you completed the mandatory 14 days quarantine after arriving at current place of work?",
        Answer: 'No',
        AnswerStatus: 'Failure'

      })
    } else if (this.Q8Answer === 'No') {
      this.rightResponses.push({
        Question: "Have you returned back from any other city,district or state to your work location during the last 15 days",
        Answer: 'No',
        AnswerStatus: 'Success'
      })

      this.rightResponses.push({
        Question: "Have you completed the mandatory 14 days quarantine after arriving at current place of work?",
        Answer: 'Yes',
        AnswerStatus: 'Success'
      })
    } if (this.Q9Answer === 'I do not accept the guidelines & policies mentioned above') {
      //  Employee Declaration
      this.wrongResponses.push({

        Question: "Employee Declaration",
        Answer: 'I do not accept the guidelines & policies mentioned above',
        AnswerStatus: 'Failure'

      })
    } else if (this.Q9Answer === 'I have made the declaration above to the best of my knowledge and accept the guidelines & policies mentioned above') {
      this.rightResponses.push({
        Question: "Employee Declaration",
        Answer: 'I have made the declaration above to the best of my knowledge and accept the guidelines & policies mentioned above',
        AnswerStatus: 'Success'
      })
    } if (this.Q10Answer === 'Decline') {
      this.wrongResponses.push({

        Question: " I read and understood the steps taken by Wipro to ensure safety of its employees and precautionary measures that I need to follow to ensure safety of my colleagues, family and self. I confirm that I shall report to office",
        Answer: 'Decline',
        AnswerStatus: 'Failure'

      })
    } else if (this.Q10Answer === 'Accept') {
      this.rightResponses.push({
        Question: " I read and understood the steps taken by Wipro to ensure safety of its employees and precautionary measures that I need to follow to ensure safety of my colleagues, family and self. I confirm that I shall report to office",
        Answer: 'Accept',
        AnswerStatus: 'Success'
      })
    }


    // console.log('Wrong Response Array: ', this.wrongResponses);
    // console.log('Right Response Array: ', this.rightResponses);

    for (let wrongItems of this.wrongResponses) {
      this.finalResponseArray.push(wrongItems)
    }
    for (let item of this.rightResponses) {
      this.finalResponseArray.push(item);
    }


    // console.log(this.finalResponseArray)

    // if (this.wrongResponses.length != 0) {
    //   let requestPayload = {
    //     loggedInEmail: sessionStorage.getItem('email'),
    //     Status: 'Failure',
    //     QuestionResponses: this.wrongResponses
    //   }
    //   console.log('Wrong Responses', JSON.stringify(requestPayload))
    // }

    // Forming Wrong Response Array OVER
    // if (this.Q10Answer === '') {
    //   alert('Please Answer the above question')
    // } else if (this.Q1Answer === 'I have not volunteered to come to office' || this.Q2Answer === 'I have one of these symptoms - Fever, Dry cough, Body Ache, Headaches, Sore throat, Runny Nose, Tiredness, and Shortness of Breath' || this.Q4Answer === 'Yes' || this.Q5Answer === 'Yes' || this.Q6Answer === 'Deny' || this.Q7Answer === 'Deny' || (this.Q8Answer === 'Yes' && this.Q11Answer == 'No') || this.Q9Answer === 'I do not accept the guidelines & policies mentioned above' || this.Q10Answer === 'Decline' || this.Q11Answer === 'No') {
    //   this.showResponse = true;
    //   this.showBarcode = false;
    // } else {
    let payload = {

      QuestionResponses: [{

        "Question": "Please choose appropriate option",
        "Answer": this.Q1Answer

      }, {

        "Question": "Please select relevant option",
        "Answer": this.Q2Answer

      }, {

        "Question": "Have you been in contact with a confirmed COVID-19 patient in past 28 Days?",
        "Answer": this.Q4Answer

      }, {

        "Question": "Have you been to COVID-19 affected countries or hot spots inside the country in past 28 days?",
        "Answer": this.Q5Answer

      }, {

        "Question": "Declaration: If I have any symptoms like -Fever,Dry Cough,Body Ache, Headaches,Sore throat, Runny Nose, Tiredness,Shortness of Breath or related symptoms, I will NOT come to office",
        "Answer": this.Q6Answer

      }, {

        "Question": "Declaration: I agree to abide by the Social Media Policy of the organization",
        "Answer": this.Q7Answer

      }, {

        "Question": "Have you returned back from any other city,district or state to your work location during the last 15 days",
        "Answer": this.Q8Answer

      }, {

        "Question": "Employee Declaration",
        "Answer": this.Q9Answer

      }, {

        "Question": "I read and understood the steps taken by Wipro to ensure safety of its employees and precautionary measures that I need to follow to ensure safety of my colleagues, family and self. I confirm that I   shall report to office",
        "Answer": this.Q10Answer

      },
      {

        "Question": "Have you completed the mandatory 14 days quarantine after arriving at current place of work?",
        "Answer": this.Q11Answer

      }
      ]
    }

    var siteID = sessionStorage.getItem("storeId");
    siteID = JSON.parse(siteID);

    if (this.wrongResponses.length != 0) {
      this.requestPayload = {
        loggedInEmail: sessionStorage.getItem('email'),
        Status: 'Failure',
        siteId:siteID,
        QuestionResponses: this.finalResponseArray
      }
      // console.log('Wrong Responses', JSON.stringify(this.requestPayload))
    } else if (this.wrongResponses.length == 0) {
      this.requestPayload = {
        loggedInEmail: sessionStorage.getItem('email'),
        Status: 'Success',
        siteId:siteID,
        QuestionResponses: this.finalResponseArray
      }
      // console.log('CORRECT Responses', JSON.stringify(this.requestPayload))
    }


    this.app.postQuestionaireResponse(this.requestPayload).subscribe(res => {
      // console.log(res);
      this.showLoader = false;
      this.ResponseObject = res
      if (this.ResponseObject.Message === 'Failure') {
        this.showResponse = true;
      } else {
        this.showBarcode = true;
        this.showLoader = false;
      }
    })
    // }

  }



}
