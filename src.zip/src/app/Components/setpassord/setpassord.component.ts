import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-setpassord',
  templateUrl: './setpassord.component.html',
  styleUrls: ['./setpassord.component.scss']
})
export class SetpassordComponent implements OnInit {

  constructor() { }
  setPasswordModel:any ={};

  ngOnInit() {
  }

}
