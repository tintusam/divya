import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from '../../Service/app.service'

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.scss']
})
export class LoginPageComponent implements OnInit {
  SelectedLocation = 'Select Location';
  selectedSite:any;
  showLoader = true;
  showDropDown = false;
  email = '';
  locationList: any;
  constructor(private router: Router, private app: AppService) {
    this.locationList = []



  }

  ngOnInit() {
    // if (sessionStorage.getItem('email') != '') {
    //   // this.router.navigate(['action-center'])
    //   this.router.navigate(['action-center/generate-QR-code'])
    // } else {
    //   this.router.navigate(['login'])
    // }
    this.app.getAllSites().subscribe(res => {
       console.log(res);
      this.locationList = res;
      this.showDropDown = true;
      this.showLoader = false;
    })


  }

  selectLocation(location) {
    this.selectedSite = location.siteid;
    this.SelectedLocation = location.siteName;
  }

  login() {
    if (this.email === '' || this.selectedSite == undefined) {
      alert('Email ID and Location are Mandatory. Please fill this information first to login.')
    } else {
      sessionStorage.setItem('email', this.email);
      sessionStorage.setItem('storeId', this.selectedSite);
      console.log(this.selectedSite);
      // this.router.navigate(['action-center'])
      this.router.navigate(['action-center/generate-QR-code'])
    }

  }
}
