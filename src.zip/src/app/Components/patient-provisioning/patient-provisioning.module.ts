import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PatientProvisioningRoutingModule } from './patient-provisioning-routing.module';
import { PatientProvisioningLandingPageComponent } from './patient-provisioning-landing-page/patient-provisioning-landing-page.component';
import { FacilityPatientProvisionComponent } from './facility-patient-provision/facility-patient-provision.component';
import { CommunityCenterPatientProvisionComponent } from './community-center-patient-provision/community-center-patient-provision.component';
import { RegisterFacilityPatientComponent } from './facility-patient-provision/register-facility-patient/register-facility-patient.component';
import { RegisterCommunityPatientComponent } from './community-center-patient-provision/register-community-patient/register-community-patient.component';


@NgModule({
  declarations: [PatientProvisioningLandingPageComponent, FacilityPatientProvisionComponent, CommunityCenterPatientProvisionComponent, RegisterFacilityPatientComponent, RegisterCommunityPatientComponent],
  imports: [
    CommonModule,
    PatientProvisioningRoutingModule
  ]
})
export class PatientProvisioningModule { }
