import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'
@Component({
  selector: 'app-patient-provisioning-landing-page',
  templateUrl: './patient-provisioning-landing-page.component.html',
  styleUrls: ['./patient-provisioning-landing-page.component.scss']
})
export class PatientProvisioningLandingPageComponent implements OnInit {

  constructor(private Router: Router) { }

  ngOnInit(): void {
    // this.Router.navigate(['patient-provisioning/facility-patient-provisioning'])
  }

}
