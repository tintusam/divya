import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-facility-patient-provision',
  templateUrl: './facility-patient-provision.component.html',
  styleUrls: ['./facility-patient-provision.component.scss']
})
export class FacilityPatientProvisionComponent implements OnInit {

  constructor(private _router:Router) { }

  ngOnInit(): void {
  }

  registerNow(){
    this._router.navigate(['patient-provisioning/facility-patient-provisioning/register']);   
  }

}
