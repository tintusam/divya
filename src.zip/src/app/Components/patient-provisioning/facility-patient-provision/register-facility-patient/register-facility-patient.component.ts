import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-facility-patient',
  templateUrl: './register-facility-patient.component.html',
  styleUrls: ['./register-facility-patient.component.scss']
})
export class RegisterFacilityPatientComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
