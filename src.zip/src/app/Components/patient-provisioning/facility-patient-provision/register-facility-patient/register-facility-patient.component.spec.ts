import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterFacilityPatientComponent } from './register-facility-patient.component';

describe('RegisterFacilityPatientComponent', () => {
  let component: RegisterFacilityPatientComponent;
  let fixture: ComponentFixture<RegisterFacilityPatientComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegisterFacilityPatientComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisterFacilityPatientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
