import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FacilityPatientProvisionComponent } from './facility-patient-provision.component';

describe('FacilityPatientProvisionComponent', () => {
  let component: FacilityPatientProvisionComponent;
  let fixture: ComponentFixture<FacilityPatientProvisionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FacilityPatientProvisionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FacilityPatientProvisionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
