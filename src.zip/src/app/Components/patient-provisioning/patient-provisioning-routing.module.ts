import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PatientProvisioningLandingPageComponent } from './patient-provisioning-landing-page/patient-provisioning-landing-page.component';
import { FacilityPatientProvisionComponent } from './facility-patient-provision/facility-patient-provision.component';
import { CommunityCenterPatientProvisionComponent } from './community-center-patient-provision/community-center-patient-provision.component';
import { RegisterCommunityPatientComponent } from './community-center-patient-provision/register-community-patient/register-community-patient.component';
import { RegisterFacilityPatientComponent } from './facility-patient-provision/register-facility-patient/register-facility-patient.component';

const routes: Routes = [
  {
    path: '',
    component: PatientProvisioningLandingPageComponent,
    children: [
      {
        path: 'facility-patient-provisioning',
        component: FacilityPatientProvisionComponent
      },
      {
        path: 'community-patient-provisioning',
        component: CommunityCenterPatientProvisionComponent
      },
      {
        path: 'facility-patient-provisioning/register',
        component: RegisterFacilityPatientComponent
      },
      {
        path: 'community-patient-provisioning/register',
        component: RegisterCommunityPatientComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PatientProvisioningRoutingModule { }
