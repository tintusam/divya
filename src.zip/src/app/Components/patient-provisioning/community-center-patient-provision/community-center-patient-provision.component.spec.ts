import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CommunityCenterPatientProvisionComponent } from './community-center-patient-provision.component';

describe('CommunityCenterPatientProvisionComponent', () => {
  let component: CommunityCenterPatientProvisionComponent;
  let fixture: ComponentFixture<CommunityCenterPatientProvisionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CommunityCenterPatientProvisionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CommunityCenterPatientProvisionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
