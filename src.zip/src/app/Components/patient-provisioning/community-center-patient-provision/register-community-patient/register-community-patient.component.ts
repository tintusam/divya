import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-community-patient',
  templateUrl: './register-community-patient.component.html',
  styleUrls: ['./register-community-patient.component.scss']
})
export class RegisterCommunityPatientComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
