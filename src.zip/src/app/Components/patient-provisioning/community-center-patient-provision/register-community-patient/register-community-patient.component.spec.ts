import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterCommunityPatientComponent } from './register-community-patient.component';

describe('RegisterCommunityPatientComponent', () => {
  let component: RegisterCommunityPatientComponent;
  let fixture: ComponentFixture<RegisterCommunityPatientComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegisterCommunityPatientComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisterCommunityPatientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
