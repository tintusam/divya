import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-community-center-patient-provision',
  templateUrl: './community-center-patient-provision.component.html',
  styleUrls: ['./community-center-patient-provision.component.scss']
})
export class CommunityCenterPatientProvisionComponent implements OnInit {

  constructor(private _router:Router) { }

  ngOnInit(): void {
  }
  registerNow(){
    this._router.navigate(['patient-provisioning/community-patient-provisioning/register']);   
  }

}
