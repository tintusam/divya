import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { NgForm } from '@angular/forms';
import { AuthenticateService} from '../../../Utilities/authenticate.service';
import { AppService } from '../../../Utilities/app.service';
@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {

  constructor(private _router:Router, private _auth:AuthenticateService, private _app:AppService) { }
  supervisorModel: any = {};
  inviteMsg:any;
  email:String;
  userRole:string;
  siteID:any;
  locations:any;
  showInviteForm:boolean = true;
  ngOnInit() {
    this.userRole = sessionStorage.getItem('userRole');
    this.siteID = sessionStorage.getItem('siteID');
    this.siteID = JSON.parse(this.siteID);
    if(this.siteID == 0){
      this.onGetAllLocations();
    }

  }

  // passing site id as 0 by default
  // superadmin only can add other supervisors
  onGetAllLocations(){
    let payload = {
      'siteid':0
    }  

    this._app.listAllSites(payload).subscribe(res =>
      {
        this.locations = res;
      })
  }

  // to clear invite form
  resetForm(){
    this.showInviteForm = true;
    this.inviteMsg = '';
    this.email = '';
  }

  // to invite supervisor
  onInviteSupervisor(supervisor: NgForm){
    var siteID = supervisor.value.location;
    siteID = JSON.parse(siteID);
    let payload: any = {
      'LoggedInEmail': supervisor.value.email,
      'Role': 'supervisor',
      'siteid':siteID
    };
    //console.log(payload);
    this._auth.addSupervisor(payload).subscribe(res => {
      this.inviteMsg = res;
      this.showInviteForm = false;
    },
    err => {
        if (err.status == 500){
          this.inviteMsg = "Remote servers are not responding at the moment. Please try after sometime.";
          this.showInviteForm = false;
        }
    });
  }

  logout(){
    sessionStorage.removeItem("Login");
    sessionStorage.removeItem("userEmail");
    sessionStorage.removeItem("userRole");
    this._router.navigateByUrl('');
  }


}
