import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CommunityCenterLandingPageComponent } from './community-center-landing-page.component';

describe('CommunityCenterLandingPageComponent', () => {
  let component: CommunityCenterLandingPageComponent;
  let fixture: ComponentFixture<CommunityCenterLandingPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CommunityCenterLandingPageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CommunityCenterLandingPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
