import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tab-community-fall-detection',
  templateUrl: './tab-community-fall-detection.component.html',
  styleUrls: ['./tab-community-fall-detection.component.scss']
})
export class TabCommunityFallDetectionComponent implements OnInit {
  fallList = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
  constructor() { }

  ngOnInit(): void {
  }

}
