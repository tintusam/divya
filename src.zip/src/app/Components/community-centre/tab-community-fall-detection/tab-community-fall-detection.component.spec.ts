import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TabCommunityFallDetectionComponent } from './tab-community-fall-detection.component';

describe('TabCommunityFallDetectionComponent', () => {
  let component: TabCommunityFallDetectionComponent;
  let fixture: ComponentFixture<TabCommunityFallDetectionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TabCommunityFallDetectionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TabCommunityFallDetectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
