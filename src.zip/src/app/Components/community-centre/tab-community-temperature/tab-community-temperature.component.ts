import { Component, OnInit } from '@angular/core';
// import { BrowserModule } from '@angular/platform-browser';
// import { NgxChartsModule } from '@swimlane/ngx-charts';

@Component({
  selector: 'app-tab-community-temperature',
  templateUrl: './tab-community-temperature.component.html',
  styleUrls: ['./tab-community-temperature.component.scss']
})
export class TabCommunityTemperatureComponent implements OnInit {


  multi = [
    {
      "name": "Temperature",
      "series": [
        {
          "name": "10:15",
          "value": 92
        },
        {
          "name": "13:15",
          "value": 95
        },
        {
          "name": "16:20",
          "value": 98
        }, {
          "name": "17:15",
          "value": 80
        },
        {
          "name": "19:15",
          "value": 91
        },
        {
          "name": "20:15",
          "value": 98
        },
        {
          "name": "22:15",
          "value": 94
        }
      ]
    },

  ];

  view: any[] = [800, 300];

  // options
  legend: boolean = true;
  showLabels: boolean = true;
  animations: boolean = true;
  xAxis: boolean = true;
  yAxis: boolean = true;
  showYAxisLabel: boolean = true;
  showXAxisLabel: boolean = true;
  xAxisLabel: string = 'Time';
  yAxisLabel: string = 'Temperature';
  timeline: boolean = true;


  colorScheme = {
    domain: ['#5AA454', '#E44D25', '#CFC0BB', '#7aa3e5', '#a8385d', '#aae3f5']

  };
  constructor() {
    // Object.assign(this, { multi });
  }
  ngOnInit() {
    // throw new Error('Method not implemented.');
  }

  onSelect(data): void {
    console.log('Item clicked', JSON.parse(JSON.stringify(data)));
  }

  onActivate(data): void {
    console.log('Activate', JSON.parse(JSON.stringify(data)));
  }

  onDeactivate(data): void {
    console.log('Deactivate', JSON.parse(JSON.stringify(data)));
  }

}
