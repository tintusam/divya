import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TabCommunityPatientHealthComponent } from './tab-community-patient-health.component';

describe('TabCommunityPatientHealthComponent', () => {
  let component: TabCommunityPatientHealthComponent;
  let fixture: ComponentFixture<TabCommunityPatientHealthComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TabCommunityPatientHealthComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TabCommunityPatientHealthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
