import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tab-community-patient-health',
  templateUrl: './tab-community-patient-health.component.html',
  styleUrls: ['./tab-community-patient-health.component.scss']
})
export class TabCommunityPatientHealthComponent implements OnInit {
  medicineList = [1, 1, 1, 1, 1, 2, 11, 1, 1, 2, 111, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]

  constructor() { }

  ngOnInit(): void {
  }

}
