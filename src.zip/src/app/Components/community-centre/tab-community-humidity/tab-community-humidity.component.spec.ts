import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TabCommunityHumidityComponent } from './tab-community-humidity.component';

describe('TabCommunityHumidityComponent', () => {
  let component: TabCommunityHumidityComponent;
  let fixture: ComponentFixture<TabCommunityHumidityComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TabCommunityHumidityComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TabCommunityHumidityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
