import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tab-community-humidity',
  templateUrl: './tab-community-humidity.component.html',
  styleUrls: ['./tab-community-humidity.component.scss']
})
export class TabCommunityHumidityComponent implements OnInit {
  multi = [
    {
      "name": "Humidity",
      "series": [
        {
          "name": "10:15",
          "value": 62
        },
        {
          "name": "13:15",
          "value": 73
        },
        {
          "name": "16:20",
          "value": 89
        }, {
          "name": "17:15",
          "value": 62
        },
        {
          "name": "19:15",
          "value": 73
        },
        {
          "name": "20:15",
          "value": 62
        },
        {
          "name": "22:15",
          "value": 73
        }
      ]
    },

  ];

  view: any[] = [800, 300];

  // options
  legend: boolean = true;
  showLabels: boolean = true;
  animations: boolean = true;
  xAxis: boolean = true;
  yAxis: boolean = true;
  showYAxisLabel: boolean = true;
  showXAxisLabel: boolean = true;
  xAxisLabel: string = 'Time';
  yAxisLabel: string = 'Humidity';
  timeline: boolean = true;

  colorScheme = {

    domain: ['#7aa3e5', '#a8385d', '#aae3f5']
  };

  constructor() {
    // Object.assign(this, { multi });
  }
  ngOnInit() {
    // throw new Error('Method not implemented.');
  }

  onSelect(data): void {
    console.log('Item clicked', JSON.parse(JSON.stringify(data)));
  }

  onActivate(data): void {
    console.log('Activate', JSON.parse(JSON.stringify(data)));
  }

  onDeactivate(data): void {
    console.log('Deactivate', JSON.parse(JSON.stringify(data)));
  }
}
