import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TabMedicineConsumptionComponent } from './tab-medicine-consumption.component';

describe('TabMedicineConsumptionComponent', () => {
  let component: TabMedicineConsumptionComponent;
  let fixture: ComponentFixture<TabMedicineConsumptionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TabMedicineConsumptionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TabMedicineConsumptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
