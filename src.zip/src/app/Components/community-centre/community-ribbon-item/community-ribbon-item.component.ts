import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-community-ribbon-item',
  templateUrl: './community-ribbon-item.component.html',
  styleUrls: ['./community-ribbon-item.component.scss']
})
export class CommunityRibbonItemComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
