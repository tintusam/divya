export const Config = Object.freeze({
     BASE_API_URL: 'https://self-declaration-function-app.azurewebsites.net/',
     SECOND_API_URL: '',
     API_PATH: 'api/' 
});        
