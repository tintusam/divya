import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
import { Config } from '../config';

@Injectable({
  providedIn: 'root'
})
export class AppService {

  constructor(private http: HttpClient) { }

  GetAllLocation() {
    return this.http.get(Config.BASE_API_URL+Config.API_PATH + 'GetAllLocation')
  }


  getEmployeeCount() {
    return this.http.get(Config.BASE_API_URL+Config.API_PATH+  'getEmployeeCount');
  }

  getGraphCounts(payload) {
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+  'getGraph', payload);
  }
}
