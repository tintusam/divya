import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
const ApiUrl = "https://self-declaration-function-app.azurewebsites.net/api/";

@Injectable({
  providedIn: 'root'
})
export class AppService {

  constructor(private http: HttpClient) { }

  GetAllLocation() {
    return this.http.get(ApiUrl + 'GetAllLocation')
  }


  getEmployeeCount() {
    return this.http.get(ApiUrl + 'getEmployeeCount');
  }

  getGraphCounts(payload) {
    return this.http.post(ApiUrl + 'getGraph', payload);
  }
}
