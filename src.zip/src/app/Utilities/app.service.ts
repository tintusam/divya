import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
import { Config } from '../config';

@Injectable({
  providedIn: 'root'
})
export class AppService {

  constructor(private http: HttpClient) { }

  GetAllLocation() {
    return this.http.get(Config.BASE_API_URL+Config.API_PATH + 'GetAllLocation')
  }

  getAllSupervisors(payload) {
    return this.http.post(Config.BASE_API_URL+Config.API_PATH + 'getAllSuperVisiorMails', payload)
  }


  getEmployeeCount(payload) {
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+  'getEmployeeCount',payload);
  }

  getGraphCounts(payload) {
    //console.log(payload)
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+  'getGraph', payload);
  }

  createSite(payload){
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+ 'createSite' , payload);
  }

  deleteSite(payload){
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+ 'deleteSite' , payload);
  }

  listAllSites(payload) {
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+  'getAllSites',payload);
  }

}
