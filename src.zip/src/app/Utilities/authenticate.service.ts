import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
import { Config } from '../config';
@Injectable({
  providedIn: 'root'
})
export class AuthenticateService {

  constructor(private http: HttpClient) {

  }

  // For Login Sessions
  private loginSource = new BehaviorSubject(false);
  getLogin = this.loginSource.asObservable();

  setLogin(log: boolean) {
    this.loginSource.next(log);
  }

  isAuthenticated() {
    if (sessionStorage.getItem("Login")) {
      return true;
    }
    else {
      return false;
    }
  }

  authenticateUser(payload) {
    console.log("login payload is " +JSON.stringify(payload));
    //return this.http.post(Config.BASE_API_URL+Config.API_PATH+ 'authenticateUser', JSON.stringify(payload));
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+ 'authenticateUser', payload)
  }


}
