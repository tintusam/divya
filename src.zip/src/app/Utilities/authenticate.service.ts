import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
import { Config } from '../config';
@Injectable({
  providedIn: 'root'
})
export class AuthenticateService {

  constructor(private http: HttpClient) {

  }

  // For Login Sessions
  private loginSource = new BehaviorSubject(false);
  getLogin = this.loginSource.asObservable();

  setLogin(log: boolean) {
    this.loginSource.next(log);
  }

  isAuthenticated() {
    if (sessionStorage.getItem("Login")) {
      return true;
    }
    else {
      return false;
    }
  }

  // to authenticate user
  authenticateUser(payload) {
    //return this.http.post(Config.BASE_API_URL+Config.API_PATH+ 'authenticateUser', JSON.stringify(payload));
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+ 'authenticateUser', payload);
  }
  
  // to create registration link for new supervisor
  addSupervisor(payload) {
    //console.log(payload);
    return this.http.post(Config.BASE_API_URL+Config.API_PATH+ 'createEmail', payload);
  }

    // to create password for new supervisor
    onSetPassword(payload) {
      console.log(payload);
      return this.http.post(Config.BASE_API_URL+Config.API_PATH+ 'resetPassword', payload);
    }

}
