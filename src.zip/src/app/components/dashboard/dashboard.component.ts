/// <reference path="../../../../node_modules/bingmaps/types/MicrosoftMaps/Microsoft.Maps.All.d.ts" />
import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { MapService } from '../../services/map.service';
import { DatePipe } from '@angular/common';
import { DashboardService } from '../../services/dashboard.service';
import * as c3 from 'c3';
import Swal from 'sweetalert2';
declare var $: any;

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  public DateRange: string[] = [];
  public isLoaded:boolean = true;
  public cartonLoaded:boolean = false;
  public query: any = '';
  public filterStartMonth: any;
  public filterStartDay: any;
  public filterEndDay: any;
  public filterStartDate: any;
  public filterEndMonth: any;
  public filterEndDate: any;
  public minDate: any;
  public shipmentInfo: string;
  public shipmentResponse: any;
  public today = new Date();
  public chartData = [];
  public temperatureResponse:any;
  public selectedShipmentId;
  public deleteShipmentResponse:any;
  public bigDataResponse:any;
  public shipmentCity:string;
  public shipmentCountry:string;
  public shipmentLocality:string;
  public shipmentSubdivision:string;

  //BING MAPS
  public lat:any = 13.6738677;
  public lng:any = 76.0096752;
  public mapPin: any;
  public pin: any[] = [];
  public pinInfobox: any[] = [];
  private map: Microsoft.Maps.Map;
  public mapLoaded: boolean = false;
  public showLocation:boolean = false;
  public showTemperatureGraph:boolean = false;
  public markerIcon:string;

  public widgetCountResponse:any;
  public handheldDataResponse:any;
  public shipmentInfoResponse:any;

  public c3ChartDataXaxis = ['Time'];
  public c3ChartDataYaxis = [];
  public rawchartData:any;
  public xAxisDate:any;
  

  loadAPI: Promise<any>;
  @ViewChild('myMap', { static: false }) myMap;
  

  constructor(
    public _dataService: MapService, 
    private _dashboardService: DashboardService,
    public datePipe: DatePipe,
    private router: Router
    ) { }

  ngOnInit(): void {
    this.showWidgetCount();
    this.showHandheldReaderData();
  }

  onLoggedout(){
    this.router.navigate(['/']);
  }

  onDrawHumidityChart(shipmentId){
    let payload = {
      ShipmentID:shipmentId,
      type:'humidity',
      fromDate:'',
      toDate:''
    }
    this.c3ChartDataYaxis = ['Humidity'];
    this._dashboardService.getGraphData(payload).subscribe(
      res =>{
        //console.log(res);
        console.log(res);
        this.rawchartData = res;
        var insightPropertyName = "Value";
        var insightPropertyValue;
        for (var i = 0; i < this.rawchartData.length; i++) {
          insightPropertyValue = this.rawchartData[i][insightPropertyName];
          insightPropertyValue = parseInt(insightPropertyValue);
          let latest_date = this.datePipe.transform(this.rawchartData[i].LastUpdatedTime, 'short');     
          //console.log(latest_date);  
          this.xAxisDate = new Date(latest_date);
          //console.log(this.xAxisDate);
          this.c3ChartDataXaxis.push(this.xAxisDate);
          this.c3ChartDataYaxis.push(insightPropertyValue);
        }
        this.drawHumidityChart();
      },
      err =>{
        console.log(err);
      }
    )   
  }


  showFilteredHumidityChart(custompayload){
    let payload = custompayload;
    this.c3ChartDataYaxis = ['Humidity'];
    this._dashboardService.getGraphData(payload).subscribe(
      res =>{
        //console.log(res);
        console.log(res);
        this.rawchartData = res;
        var insightPropertyName = "Value";
        var insightPropertyValue;
        for (var i = 0; i < this.rawchartData.length; i++) {
          insightPropertyValue = this.rawchartData[i][insightPropertyName];
          insightPropertyValue = parseInt(insightPropertyValue);
          let latest_date = this.datePipe.transform(this.rawchartData[i].LastUpdatedTime, 'short');     
          //console.log(latest_date);  
          this.xAxisDate = new Date(latest_date);
          //console.log(this.xAxisDate);
          this.c3ChartDataXaxis.push(this.xAxisDate);
          this.c3ChartDataYaxis.push(insightPropertyValue);
        }
        this.drawHumidityChart();
      },
      err =>{
        console.log(err);
      }
    )   
  }


  showFilteredTemperatureChart(custompayload){
    let payload = custompayload;
    this.c3ChartDataYaxis = ['Temperature'];
    this._dashboardService.getGraphData(payload).subscribe(
      res =>{
        //console.log(res);
        console.log(res);
        this.rawchartData = res;
        var insightPropertyName = "Value";
        var insightPropertyValue;
        for (var i = 0; i < this.rawchartData.length; i++) {
          insightPropertyValue = this.rawchartData[i][insightPropertyName];
          insightPropertyValue = parseInt(insightPropertyValue);
          let latest_date = this.datePipe.transform(this.rawchartData[i].LastUpdatedTime, 'short');     
          //console.log(latest_date);  
          this.xAxisDate = new Date(latest_date);
          //console.log(this.xAxisDate);
          this.c3ChartDataXaxis.push(this.xAxisDate);
          this.c3ChartDataYaxis.push(insightPropertyValue);
        }
        this.drawTemperatureChart();
      },
      err =>{
        console.log(err);
      }
    )   
  }


  onDrawTemperatureChart(shipmentId){
    let payload = {
      ShipmentID:shipmentId,
      type:'temperature',
      fromDate:'',
      toDate:''
    }
    this.c3ChartDataYaxis = ['Temperature'];
    this._dashboardService.getGraphData(payload).subscribe(
      res =>{
       // console.log(res);
        this.rawchartData = res;
        var insightPropertyName = "Value";
        var insightPropertyValue;
        for (var i = 0; i < this.rawchartData.length; i++) {
          insightPropertyValue = this.rawchartData[i][insightPropertyName];
          insightPropertyValue = parseInt(insightPropertyValue);
          let latest_date = this.datePipe.transform(this.rawchartData[i].LastUpdatedTime, 'short');       
          this.xAxisDate = new Date(latest_date);
          this.c3ChartDataXaxis.push(this.xAxisDate);
          this.c3ChartDataYaxis.push(insightPropertyValue);
        }
        this.drawTemperatureChart();

      },
      err =>{
        console.log(err);
      }
    )  
  }


  drawHumidityChart(){
    let chart = c3.generate({
      bindto: '#humidityChart',
      data: {
        x: 'Time',
        xFormat: "%Y-%m-%dT%H:%M:%S",
        columns: [this.c3ChartDataXaxis, this.c3ChartDataYaxis],
    },
    axis: {
        x: {
            type: 'timeseries',
            tick: {
              format: '%Y-%m-%d', // how the date is displayed
              rotate: -50
          }
        }
    },
    size: {
      height: 240,
        width: 450
    },

    });
  }


  drawTemperatureChart(){
    let chart = c3.generate({
      bindto: '#temperatureChart',
      data: {
        x: 'Time',
        xFormat: "%Y-%m-%dT%H:%M:%S",
        columns: [this.c3ChartDataXaxis, this.c3ChartDataYaxis],
    },
    axis: {
        x: {
            type: 'timeseries',
            tick: {
              format: '%Y-%m-%d', // how the date is displayed
              rotate: -50
          }
        }
    },
    size: {
      height: 240,
        width: 450
    },

    });
  }


  // Method to show location map
  renderLocationMap(lat, lng) {
    this.markerIcon = '../../../assets/images/place-24px.svg';

    this._dataService.load().then(() => {
      this.map = new Microsoft.Maps.Map(this.myMap.nativeElement, {
        credentials: 'Avh43rwIxMpHSkLOHeo7MeaFNwaQgk8BsehjzGxYxscXNvi6VH_VlUnX_MHAyFzw',
        center: new Microsoft.Maps.Location(lat, lng),
        mapTypeId: Microsoft.Maps.MapTypeId.road,
        zoom: 15
      });
      this.mapLoaded = true;
      this.pin.push(new Microsoft.Maps.Pushpin(new Microsoft.Maps.Location(Number(lat), Number(lng)), {
        icon: this.markerIcon,
      }));

      // to create info that needs to be shown on tooltip
      this.pinInfobox.push(new Microsoft.Maps.Infobox(
        new Microsoft.Maps.Location(Number(lat), Number(lng)),
        { title: "", visible: false }
      ));

      // to show marker tooltip on mouseover event
      Microsoft.Maps.Events.addHandler(this.pin[0], 'mouseover', e => {
        this.pinInfobox[0].setMap(this.map);
      });

      // to hide marker tooltip on mouseout event
      Microsoft.Maps.Events.addHandler(this.pin[0], 'mouseout', e => {
        this.pinInfobox[0].setMap();
      });

      // to show markers on map
      this.map.entities.push(this.pin);
    })
  }

  // Method to show location while clicking the icon from UI
  onShowLocation(e){
    this.renderLocationMap(this.lat, this.lng);
    //e.stopPropagation();
    e.preventDefault();
  }

  // Method to hide location modal while clicking close button
  onCloseLocationModal(){
    this.showLocation = false;
  }

  onCloseTemperatureModal(){
    this.showTemperatureGraph = false;
  }

  // Method to filter the api call for history data
  onFilterByDate() {
    this.filterStartMonth = new Date(this.DateRange[0]).getMonth();
    this.filterStartMonth = this.filterStartMonth + 1;
    this.filterStartMonth = ('0' + this.filterStartMonth).slice(-2);

    this.filterStartDay = new Date(this.DateRange[0]).getDate();
    this.filterStartDay = ('0' + this.filterStartDay).slice(-2);

    this.filterEndMonth = new Date(this.DateRange[1]).getMonth();
    this.filterEndMonth = this.filterEndMonth + 1;
    this.filterEndMonth = ('0' + this.filterEndMonth).slice(-2);

    this.filterEndDay = new Date(this.DateRange[1]).getDate();
    this.filterEndDay = ('0' + this.filterEndDay).slice(-2);
    this.filterStartDate = new Date(this.DateRange[0]).getFullYear() + "-" + this.filterStartMonth + "-" + this.filterStartDay;
    this.filterEndDate = new Date(this.DateRange[1]).getFullYear() + "-" + this.filterEndMonth + "-" + this.filterEndDay;
    if (isNaN(this.filterStartMonth)) {
      alert('Select A Date Range');
    } else {
      let payload: any = {
        fromDate: this.filterStartDate,
        toDate: this.filterEndDate,
        ShipmentID: this.shipmentInfo ? this.shipmentInfo : ''
      }
      this._dashboardService.getWidgetCount(payload).subscribe(
        res => {
          this.widgetCountResponse = res;
          console.log(this.widgetCountResponse);
        },
        err => {
          console.log(err);
        }
      )
    }
  }


  // Method to filter humidity by date
  onFilterHumidityByDate() {
    this.filterStartMonth = new Date(this.DateRange[0]).getMonth();
    this.filterStartMonth = this.filterStartMonth + 1;
    this.filterStartMonth = ('0' + this.filterStartMonth).slice(-2);

    this.filterStartDay = new Date(this.DateRange[0]).getDate();
    this.filterStartDay = ('0' + this.filterStartDay).slice(-2);

    this.filterEndMonth = new Date(this.DateRange[1]).getMonth();
    this.filterEndMonth = this.filterEndMonth + 1;
    this.filterEndMonth = ('0' + this.filterEndMonth).slice(-2);

    this.filterEndDay = new Date(this.DateRange[1]).getDate();
    this.filterEndDay = ('0' + this.filterEndDay).slice(-2);

    this.filterStartDate = new Date(this.DateRange[0]).getFullYear() + "-" + this.filterStartMonth + "-" + this.filterStartDay;
    this.filterEndDate = new Date(this.DateRange[1]).getFullYear() + "-" + this.filterEndMonth + "-" + this.filterEndDay;
    if (isNaN(this.filterStartMonth)) {
      alert('Select A Date Range');
    } else {
      let payload: any = {
        fromDate: this.filterStartDate,
        toDate: this.filterEndDate,
        ShipmentID:this.selectedShipmentId,
        type:'humidity'
      }
      this.showFilteredHumidityChart(payload);
    }
  }

 // Method to filter Temperature by date
 onFilterTemperatureByDate() {
  this.filterStartMonth = new Date(this.DateRange[0]).getMonth();
  this.filterStartMonth = this.filterStartMonth + 1;
  this.filterStartMonth = ('0' + this.filterStartMonth).slice(-2);

  this.filterStartDay = new Date(this.DateRange[0]).getDate();
  this.filterStartDay = ('0' + this.filterStartDay).slice(-2);

  this.filterEndMonth = new Date(this.DateRange[1]).getMonth();
  this.filterEndMonth = this.filterEndMonth + 1;
  this.filterEndMonth = ('0' + this.filterEndMonth).slice(-2);

  this.filterEndDay = new Date(this.DateRange[1]).getDate();
  this.filterEndDay = ('0' + this.filterEndDay).slice(-2);

  this.filterStartDate = new Date(this.DateRange[0]).getFullYear() + "-" + this.filterStartMonth + "-" + this.filterStartDay;
  this.filterEndDate = new Date(this.DateRange[1]).getFullYear() + "-" + this.filterEndMonth + "-" + this.filterEndDay;
  if (isNaN(this.filterStartMonth)) {
    alert('Select A Date Range');
  } else {
    let payload: any = {
      fromDate: this.filterStartDate,
      toDate: this.filterEndDate,
      ShipmentID:this.selectedShipmentId,
      type:'temperature'
    }
    this.showFilteredTemperatureChart(payload);
  }
}


  showWidgetCount(){
    let payload = {
      fromDate: '',
      toDate: '',
      ShipmentID: ''
    }
    this._dashboardService.getWidgetCount(payload).subscribe(
      res => {
        this.widgetCountResponse = res;
        console.log(this.widgetCountResponse);
      },
      err => {
        console.log(err);
      }
    )
  }

  showHandheldReaderData(){
    let payload = {
      fromDate: '',
      toDate: '',
      ShipmentID: ''
    }
    this.isLoaded = false;
    this._dashboardService.getHandheldReaderData(payload).subscribe(
      res => {
        this.handheldDataResponse = res;
        this.isLoaded = true;
        console.log(this.handheldDataResponse)
      },
      err => {
        console.log(err);
        this.isLoaded = true;
      }
    )
  }


  onGetShipmentDataList(selectedShipmentData){
    this.selectedShipmentId = selectedShipmentData.shipmentID;
    let payload = {
      shipmentId : this.selectedShipmentId
    }

     //console.log(payload);
     //console.log(selectedShipmentData);
     // set lat and lng as data from api ( selectedShipmentData variable)
     this.lat = selectedShipmentData.Latitude;
     this.lng = selectedShipmentData.Longitude;
     this.lat = Number(this.lat);
     this.lng = Number(this.lng)
    this.cartonLoaded = false;
    this._dashboardService.getShipmentInfo(payload).subscribe(
      res => {
        this.shipmentInfoResponse = res;
        if(this.shipmentInfoResponse){
          this._dashboardService.getLocationFromBigData(this.lat,this.lng).subscribe(
            res => {
              //console.log(res);
              this.bigDataResponse = res;
              this.cartonLoaded = true;
              this.shipmentCity = this.bigDataResponse.city;
              this.shipmentCountry = this.bigDataResponse.countryName;
              this.shipmentLocality = this.bigDataResponse.locality;
              this.shipmentSubdivision = this.bigDataResponse.principalSubdivision;
              //console.log(this.shipmentInfoResponse)
            },
            err => {
              console.log(err);
            }
          )
        }

      },
      err => {
        console.log(err);
        this.cartonLoaded = true;
      }
    )
  }

  onRefresh(shipmentData, e){
    $('.no-collapsable').on('click', function (e) {
      e.stopPropagation();
    });
    //e.preventDefault();
    this.onGetShipmentDataList(shipmentData);
    
  }

  onDeleteShipment(){
    let payload = {
      shipmentID:this.selectedShipmentId
    }
    this._dashboardService.deleteShipment(payload).subscribe(
      res => {
        this.deleteShipmentResponse = res;
        Swal.fire({
          position: 'top-end',
          icon: 'success',
          text: 'Deleted Successfully!',
          showConfirmButton: false,
          timer: 2000
        })
        this.showWidgetCount();
        this.showHandheldReaderData();        
      },
      err => {
        console.log(err);
        Swal.fire({
          position: 'top-end',
          icon: 'error',
          text: 'Failed to Delete!',
          showConfirmButton: true,
          confirmButtonColor:'#cd0000'
         // timer: 1500
        })
      }
    )
  }

  

}
