import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shipments',
  templateUrl: './shipments.component.html',
  styleUrls: ['./shipments.component.scss']
})
export class ShipmentsComponent implements OnInit {
  public showPendingInfo:boolean = false;

  constructor() { }

  ngOnInit() {
  }

  onShowPendingInfo(){
    this.showPendingInfo = true;
  }

}
