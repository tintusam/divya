import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ManagementPortalComponent } from './admin/management-portal/management-portal.component';
import { VendorManagementComponent } from './admin/management-portal/vendor-management/vendor-management.component';
import { ItemManagementComponent } from './admin/management-portal/item-management/item-management.component';
import { PoDashboardComponent } from './admin/po-dashboard/po-dashboard.component';
import { LoginComponent } from './shared/login/login.component';
import { NotFoundComponent } from './shared/not-found/not-found.component';
import { HeaderComponent } from './shared/header/header.component';
import {SortablejsModule} from 'ngx-sortablejs';
import { PoItemComponent } from './admin/po-dashboard/po-item/po-item.component';
import { ItemTrackerComponent } from './admin/item-tracker/item-tracker.component';

// Vendor Components Starts here
import { VendorDashboardComponent } from './vendor/vendor-dashboard/vendor-dashboard.component';
import { PoSummaryComponent } from './vendor/vendor-dashboard/po-summary/po-summary.component';
import { HttpClientModule } from '@angular/common/http';

// Services starts here
import { BLOB_STORAGE_TOKEN, IAzureStorage } from '../assets/azure-storage/azureStorage';
import { BlobStorageService} from '../assets/azure-storage/blob-storage.service';
declare var AzureStorage: IAzureStorage;

@NgModule({
  declarations: [
    AppComponent,
    ManagementPortalComponent,
    VendorManagementComponent,
    ItemManagementComponent,
    PoDashboardComponent,
    VendorDashboardComponent,
    LoginComponent,
    NotFoundComponent,
    HeaderComponent,
    PoItemComponent,
    PoSummaryComponent,
    ItemTrackerComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    SortablejsModule.forRoot({ animation: 150 }),
    BsDatepickerModule.forRoot(),
    TooltipModule.forRoot()
  ],
  providers: [
    BlobStorageService,
    {
      provide: BLOB_STORAGE_TOKEN,
      useValue: AzureStorage.Blob
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
