import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from './material/material.module';
import { LoginPageComponent } from './Components/login-page/login-page.component';
import { LandingPageComponent } from './Components/landing-page/landing-page.component';
import { ViewQRCodeComponent } from './Components/view-qr-code/view-qr-code.component';
import { GenerateQRCodeComponent } from './Components/generate-qr-code/generate-qr-code.component';
import { QrCodeLandingPageComponent } from './Components/qr-code-landing-page/qr-code-landing-page.component'
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { QRCodeModule } from 'angularx-qrcode';
import { QrCodeActionCenterComponent } from './Components/qr-code-action-center/qr-code-action-center.component';
import { MatRadioModule } from '@angular/material/radio';
import { MatDialogModule } from '@angular/material/dialog';
import { HttpClientModule } from '@angular/common/http';
@NgModule({
  declarations: [
    AppComponent,
    LoginPageComponent,
    LandingPageComponent,
    ViewQRCodeComponent,
    GenerateQRCodeComponent,
    QrCodeLandingPageComponent,
    QrCodeActionCenterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    QRCodeModule,
    FormsModule,
    MatRadioModule,
    ReactiveFormsModule,
    HttpClientModule,
    MaterialModule,
    MatDialogModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
