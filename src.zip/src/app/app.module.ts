import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { ChartsModule } from 'ng2-charts';

import { AppRoutingModule } from './app-routing.module';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { AppComponent } from './app.component';
import { DashboardLandingPageComponent } from './Components/Dashboard/dashboard-landing-page/dashboard-landing-page.component';
import { NavbarComponent } from './Components/Shared/navbar/navbar.component';
import { MonthlyChartComponent } from './Components/Dashboard/monthly-chart/monthly-chart.component';
import { WeeklyChartComponent } from './Components/Dashboard/weekly-chart/weekly-chart.component';
import { LoginComponent } from './Components/login/login.component';
import { SetpassordComponent } from './Components/setpassord/setpassord.component';
import { MustMatchDirective } from './Utilities/must-match.directive';
import { NotfoundComponent } from './Components/notfound/notfound.component';
import { FilteredChartComponent } from './Components/Dashboard/filtered-chart/filtered-chart.component';

@NgModule({
  declarations: [
    AppComponent,
    DashboardLandingPageComponent,
    NavbarComponent,
    MonthlyChartComponent,
    FilteredChartComponent,
    WeeklyChartComponent,
    LoginComponent,
    SetpassordComponent,
    MustMatchDirective,
    NotfoundComponent
  ],
  imports: [
    BrowserAnimationsModule,
    BsDatepickerModule.forRoot(),
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ChartsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
