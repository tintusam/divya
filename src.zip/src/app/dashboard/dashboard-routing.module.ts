import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { SettingsComponent } from './settings/settings.component';
import { SmartViewComponent } from './smart-view/smart-view.component';
import { ReportsComponent } from './reports/reports.component';
import { AssetComponent } from './asset/asset.component';
import { AlertsComponent } from './alerts/alerts.component';
import {AuthGuard} from './../services/auth.service'

const dashboardRoutes: Routes = [
    { path: 'dashboard/alerts',  component: AlertsComponent,canActivate:[AuthGuard ] },
    { path: 'dashboard/assets', component: AssetComponent,canActivate:[AuthGuard ] },
    { path: 'dashboard/reports', component: ReportsComponent,canActivate:[AuthGuard ] },
    { path: 'dashboard/settings', component: SettingsComponent,canActivate:[AuthGuard ] },
    { path: 'dashboard/smart-view', component: SmartViewComponent, canActivate:[AuthGuard ] }
  ];

@NgModule({
  imports: [
    RouterModule.forChild(dashboardRoutes)
  ],
  exports:[RouterModule]
})
export class DashboardRoutingModule { }
