import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SmartViewComponent } from './smart-view.component';

describe('SmartViewComponent', () => {
  let component: SmartViewComponent;
  let fixture: ComponentFixture<SmartViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SmartViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SmartViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
