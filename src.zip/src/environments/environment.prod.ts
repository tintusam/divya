export const environment = {
  production: true,
  // Blob Storage Related Configurations
  // tslint:disable-next-line:max-line-length
  SAS_Token: '?sv=2019-12-12&ss=bfqt&srt=sco&sp=rwdlacupx&se=2020-10-31T17:05:38Z&st=2020-09-09T09:05:38Z&spr=https&sig=v4VWVoeUXn3xLbHdWgslAuIjaAhT%2B8XxY3l23QoEQ%2Fc%3D',

  blobAccessUrl: 'https://bleengine123.blob.core.windows.net/halliburton/',
  storageLink: 'https://bleengine123.blob.core.windows.net/',

  //https://bleengine123.blob.core.windows.net/halliburton/


};
