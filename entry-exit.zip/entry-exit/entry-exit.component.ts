import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from '../../Service/app.service';
import * as CryptoJS from 'crypto-js';
import { invalid } from '@angular/compiler/src/render3/view/util';

@Component({
  selector: 'app-entry-exit',
  templateUrl: './entry-exit.component.html',
  styleUrls: ['./entry-exit.component.scss']
})
export class EntryExitComponent implements OnInit {
  public showEntryStatus:boolean = false;
  public showExitStatus:boolean = false;
  public verifyUniqueCode;
  public userFullName:string;
  public userEmail:string;
  public selfDeclaredTime;
  public showUserInfo:boolean = false;
  public uniqueKey;
  public createLog;
  public showAlert:string;
  public showExitAlert:string;
  constructor(private _app:AppService) { }

  ngOnInit() {
  }

  onVerify(verifyFormData){
    //console.log(verifyFormData.value);
    var key = CryptoJS.enc.Utf8.parse('SIWW673BX081TD34');
    var iv = CryptoJS.enc.Utf8.parse('SIWW673BX081TD34');
    let payload={
      UniqueCode:verifyFormData.value.uniqueKey
    }
    if(!verifyFormData.value.uniqueKey){
      alert('Enter Unique Code');
    }
    this._app.verifyUniqueCode(payload).subscribe(
      res => {
        this.verifyUniqueCode = res;
        //console.log(this.verifyUniqueCode);
        if(this.verifyUniqueCode.IsExpired == "No"){
          if(this.verifyUniqueCode.Status == 'SelfDeclared' || this.verifyUniqueCode.Status == 'Entry'){
            this.showEntryStatus = true;
            this.showUserInfo = true;
            var decryptedFullName  = CryptoJS.AES.decrypt(this.verifyUniqueCode.FullName, key,{
              keySize:128/8, 
              iv:iv,
              mode:CryptoJS.mode.CBC,
              padding:CryptoJS.pad.Pkcs7
            });
            var decryptedEmail  = CryptoJS.AES.decrypt(this.verifyUniqueCode.Email, key,{
              keySize:128/8, 
              iv:iv,
              mode:CryptoJS.mode.CBC,
              padding:CryptoJS.pad.Pkcs7
            });
            this.userFullName = decryptedFullName.toString(CryptoJS.enc.Utf8);
            this.userEmail = decryptedEmail.toString(CryptoJS.enc.Utf8);
            this.userFullName = this.userFullName.replace(/['"]+/g, '');
            this.userEmail = this.userEmail.replace(/['"]+/g, '');
            //console.log(this.userFullName);
            //console.log(this.userFullName.replace(/['"]+/g, ''));
            //console.log(this.userEmail); 
          }else if(this.verifyUniqueCode.Status == 'Exit'){
            this.showExitStatus = true;
            this.showUserInfo = true;
            var decryptedFullName  = CryptoJS.AES.decrypt(this.verifyUniqueCode.FullName, key,{
              keySize:128/8, 
              iv:iv,
              mode:CryptoJS.mode.CBC,
              padding:CryptoJS.pad.Pkcs7
            });
            var decryptedEmail  = CryptoJS.AES.decrypt(this.verifyUniqueCode.Email, key,{
              keySize:128/8, 
              iv:iv,
              mode:CryptoJS.mode.CBC,
              padding:CryptoJS.pad.Pkcs7
            });
            this.userFullName = decryptedFullName.toString(CryptoJS.enc.Utf8);
            this.userEmail = decryptedEmail.toString(CryptoJS.enc.Utf8);
            this.userFullName = this.userFullName.replace(/['"]+/g, '');
            this.userEmail = this.userEmail.replace(/['"]+/g, '');
          }else{
            this.showEntryStatus = false;
            this.showExitStatus = false;
            this.showUserInfo = false;
            alert('Invalid Unique Code');
  
          }
        }else{
          alert('Unique Code Expired');
        }

      },
      err => {
        console.log(err);
      }
    )
  }

  onClear(){
          this.showEntryStatus = false;
          this.showExitStatus = false;
          this.showUserInfo = false;
          this.uniqueKey = '';
         // this.showAlert = '';
         // this.showExitAlert = '';
  }

  onUserEntry(){
    let payload={
      UniqueCode:this.uniqueKey,
      Eid:this.verifyUniqueCode.Eid,
      Mode:'Entry'

    }
    //console.log(payload);
    this._app.visitorLog(payload).subscribe(
      res => {
        this.createLog = res;
        console.log(this.createLog);
        if(this.createLog == 'Entry Accepted'){
           alert('Entry Accepted');
          this.showExitAlert == 'Entry Successful';
          this.showAlert = '';
          this.onClear();
        }
      },
      err => {
        console.log(err);
      }
    )
  }

  onUserExit(){
    let payload={
      UniqueCode:this.uniqueKey,
      Eid:this.verifyUniqueCode.Eid,
      Mode:'Exit'

    }
    //console.log(payload);
   this._app.visitorLog(payload).subscribe(
      res => {
        this.createLog = res;
        console.log(this.createLog);
        if(this.createLog == 'Exit Accepted'){
          this.onClear();
         // alert('SelfDeclared Accepted');
         this.showAlert = 'Exit Successful';
         this.showExitAlert = '';
        }
      },
      err => {
        console.log(err);
      }
    )
  }

}
