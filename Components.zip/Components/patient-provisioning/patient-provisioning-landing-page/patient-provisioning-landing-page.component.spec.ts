import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PatientProvisioningLandingPageComponent } from './patient-provisioning-landing-page.component';

describe('PatientProvisioningLandingPageComponent', () => {
  let component: PatientProvisioningLandingPageComponent;
  let fixture: ComponentFixture<PatientProvisioningLandingPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PatientProvisioningLandingPageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PatientProvisioningLandingPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
