import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PatientProvisioningLandingPageComponent } from './patient-provisioning-landing-page/patient-provisioning-landing-page.component';
import { FacilityPatientProvisionComponent } from './facility-patient-provision/facility-patient-provision.component';
import { CommunityCenterPatientProvisionComponent } from './community-center-patient-provision/community-center-patient-provision.component';

const routes: Routes = [
  {
    path: '',
    component: PatientProvisioningLandingPageComponent,
    children: [
      {
        path: 'facility-patient-provisioning',
        component: FacilityPatientProvisionComponent
      },
      {
        path: 'community-patient-provisioning',
        component: CommunityCenterPatientProvisionComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PatientProvisioningRoutingModule { }
