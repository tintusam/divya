import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PatientProvisioningRoutingModule } from './patient-provisioning-routing.module';
import { PatientProvisioningLandingPageComponent } from './patient-provisioning-landing-page/patient-provisioning-landing-page.component';
import { FacilityPatientProvisionComponent } from './facility-patient-provision/facility-patient-provision.component';
import { CommunityCenterPatientProvisionComponent } from './community-center-patient-provision/community-center-patient-provision.component';


@NgModule({
  declarations: [PatientProvisioningLandingPageComponent, FacilityPatientProvisionComponent, CommunityCenterPatientProvisionComponent],
  imports: [
    CommonModule,
    PatientProvisioningRoutingModule
  ]
})
export class PatientProvisioningModule { }
