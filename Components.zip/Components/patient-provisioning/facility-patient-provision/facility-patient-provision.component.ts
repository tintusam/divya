import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-facility-patient-provision',
  templateUrl: './facility-patient-provision.component.html',
  styleUrls: ['./facility-patient-provision.component.scss']
})
export class FacilityPatientProvisionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
