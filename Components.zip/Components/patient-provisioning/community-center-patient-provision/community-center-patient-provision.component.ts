import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-community-center-patient-provision',
  templateUrl: './community-center-patient-provision.component.html',
  styleUrls: ['./community-center-patient-provision.component.scss']
})
export class CommunityCenterPatientProvisionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
