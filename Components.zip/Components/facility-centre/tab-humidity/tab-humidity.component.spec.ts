import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TabHumidityComponent } from './tab-humidity.component';

describe('TabHumidityComponent', () => {
  let component: TabHumidityComponent;
  let fixture: ComponentFixture<TabHumidityComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TabHumidityComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TabHumidityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
