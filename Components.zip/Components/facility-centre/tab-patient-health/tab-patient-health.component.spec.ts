import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TabPatientHealthComponent } from './tab-patient-health.component';

describe('TabPatientHealthComponent', () => {
  let component: TabPatientHealthComponent;
  let fixture: ComponentFixture<TabPatientHealthComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TabPatientHealthComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TabPatientHealthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
