import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxChartsModule } from '@swimlane/ngx-charts';
// import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { FacilityCentreRoutingModule } from './facility-centre-routing.module';
import { FacilityCenterLandingPageComponent } from './facility-center-landing-page/facility-center-landing-page.component';
import { FacilityDashboardComponent } from './facility-dashboard/facility-dashboard.component';
import { FacilityRibbonItemComponent } from './facility-ribbon-item/facility-ribbon-item.component';
import { WardOverlayComponent } from './ward-overlay/ward-overlay.component';
import { TabTemperatureComponent } from './tab-temperature/tab-temperature.component';
import { TabHumidityComponent } from './tab-humidity/tab-humidity.component';
import { TabSlipsNTripsComponent } from './tab-slips-n-trips/tab-slips-n-trips.component';
import { TabBedOccupancyComponent } from './tab-bed-occupancy/tab-bed-occupancy.component';
import { TabChairOccupancyComponent } from './tab-chair-occupancy/tab-chair-occupancy.component';
import { TabPatientHealthComponent } from './tab-patient-health/tab-patient-health.component';


@NgModule({
  declarations: [FacilityCenterLandingPageComponent, FacilityDashboardComponent, FacilityRibbonItemComponent, WardOverlayComponent, TabTemperatureComponent, TabHumidityComponent, TabSlipsNTripsComponent, TabBedOccupancyComponent, TabChairOccupancyComponent, TabPatientHealthComponent],
  imports: [
    CommonModule,
    FacilityCentreRoutingModule,
    NgbModule,
    NgxChartsModule,
    // BrowserAnimationsModule,

  ]
})
export class FacilityCentreModule { }
