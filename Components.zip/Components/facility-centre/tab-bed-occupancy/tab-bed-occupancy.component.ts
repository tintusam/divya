import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tab-bed-occupancy',
  templateUrl: './tab-bed-occupancy.component.html',
  styleUrls: ['./tab-bed-occupancy.component.scss']
})
export class TabBedOccupancyComponent implements OnInit {
  patientList = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]

  constructor() { }

  ngOnInit(): void {
  }

}
