import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ward-overlay',
  templateUrl: './ward-overlay.component.html',
  styleUrls: ['./ward-overlay.component.scss']
})
export class WardOverlayComponent implements OnInit {
  active = 'Temperature';
  constructor() { }

  ngOnInit(): void {
  }

}
