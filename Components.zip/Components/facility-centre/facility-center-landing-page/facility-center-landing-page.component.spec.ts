import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FacilityCenterLandingPageComponent } from './facility-center-landing-page.component';

describe('FacilityCenterLandingPageComponent', () => {
  let component: FacilityCenterLandingPageComponent;
  let fixture: ComponentFixture<FacilityCenterLandingPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FacilityCenterLandingPageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FacilityCenterLandingPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
