import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-facility-ribbon-item',
  templateUrl: './facility-ribbon-item.component.html',
  styleUrls: ['./facility-ribbon-item.component.scss']
})
export class FacilityRibbonItemComponent implements OnInit {

  @Input() facility: any;
  constructor() { }

  ngOnInit(): void {
  }

}
