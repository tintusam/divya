import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FacilityRibbonItemComponent } from './facility-ribbon-item.component';

describe('FacilityRibbonItemComponent', () => {
  let component: FacilityRibbonItemComponent;
  let fixture: ComponentFixture<FacilityRibbonItemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FacilityRibbonItemComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FacilityRibbonItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
