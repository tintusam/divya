import { Component, OnInit } from '@angular/core';
//import * as moment from 'moment';
//import 'moment-timezone';

@Component({
  selector: 'app-faculty-management',
  templateUrl: './faculty-management.component.html',
  styleUrls: ['./faculty-management.component.scss']
})
export class FacultyManagementComponent implements OnInit {

  public editFacilityName:boolean = false;
  public editWard:boolean = false;
  constructor() { }

  ngOnInit(): void {
   // var jun = moment("2020-01-27T14:17:00Z");

//console.log(jun.tz('America/Los_Angeles').format('YYYY-MM-DD HH:mm:ss A Zz'));  // 5am PDT

  }


}
