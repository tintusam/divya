import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommunitycenterManagementComponent } from './communitycenter-management/communitycenter-management.component';
import { DeviceManagementComponent } from './device-management/device-management.component';
import { FacultyManagementComponent } from './faculty-management/faculty-management.component';
import { UserManagementComponent } from './user-management/user-management.component';

const routes: Routes = [
  {
    path: 'device-management',
    component: DeviceManagementComponent 
   },
   {
    path: 'user-management',
    component: UserManagementComponent 
   },
   {
    path: 'faculty-management',
    component: FacultyManagementComponent 
   },
   {
    path: 'community-center-management',
    component: CommunitycenterManagementComponent 
   }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminPortalRoutingModule { }
