import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CommunitycenterManagementComponent } from './communitycenter-management.component';

describe('CommunitycenterManagementComponent', () => {
  let component: CommunitycenterManagementComponent;
  let fixture: ComponentFixture<CommunitycenterManagementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CommunitycenterManagementComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CommunitycenterManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
