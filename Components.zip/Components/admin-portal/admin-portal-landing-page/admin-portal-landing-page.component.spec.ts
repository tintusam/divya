import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminPortalLandingPageComponent } from './admin-portal-landing-page.component';

describe('AdminPortalLandingPageComponent', () => {
  let component: AdminPortalLandingPageComponent;
  let fixture: ComponentFixture<AdminPortalLandingPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminPortalLandingPageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminPortalLandingPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
