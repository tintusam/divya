import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminPortalRoutingModule } from './admin-portal-routing.module';
import { AdminPortalLandingPageComponent } from './admin-portal-landing-page/admin-portal-landing-page.component';
import { DeviceManagementComponent } from './device-management/device-management.component';
import { UserManagementComponent } from './user-management/user-management.component';
import { FacultyManagementComponent } from './faculty-management/faculty-management.component';
import { CommunitycenterManagementComponent } from './communitycenter-management/communitycenter-management.component';


@NgModule({
  declarations: [AdminPortalLandingPageComponent, DeviceManagementComponent, UserManagementComponent, FacultyManagementComponent, CommunitycenterManagementComponent],
  imports: [
    CommonModule,
    AdminPortalRoutingModule
  ]
})
export class AdminPortalModule { }
