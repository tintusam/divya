import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommunityCenterLandingPageComponent } from './community-center-landing-page/community-center-landing-page.component';

const routes: Routes = [
  {
    path: '',
    component: CommunityCenterLandingPageComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CommunityCentreRoutingModule { }
