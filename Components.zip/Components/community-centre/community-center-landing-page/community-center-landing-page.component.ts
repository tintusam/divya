import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-community-center-landing-page',
  templateUrl: './community-center-landing-page.component.html',
  styleUrls: ['./community-center-landing-page.component.scss']
})
export class CommunityCenterLandingPageComponent implements OnInit {
  zoneList = [1, 1, 1, 1, 1, 2, 11, 1, 1, 1, 1, 1, 1, 1, 1, 234, 11, 1, 1, 1, 1, 1, 1, 1, 1, 234]
  facilityList = [1, 2, 3, 4, 5, 6, 7, 8];

  dropdownFacilityList = ["Maudsley Hospital", "Bethlem Royal Hospital ", "Lambeth Hospital"]
  selectedFacility = 'Maudsley  Hospital'
  showWardOverlay = false
  constructor() { }

  ngOnInit(): void {
  }

}
