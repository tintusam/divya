import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-overlay-info-section',
  templateUrl: './overlay-info-section.component.html',
  styleUrls: ['./overlay-info-section.component.scss']
})
export class OverlayInfoSectionComponent implements OnInit {
  active = 'Temperature';

  constructor() { }

  ngOnInit(): void {
  }

}
