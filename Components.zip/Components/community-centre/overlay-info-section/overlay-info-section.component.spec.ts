import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OverlayInfoSectionComponent } from './overlay-info-section.component';

describe('OverlayInfoSectionComponent', () => {
  let component: OverlayInfoSectionComponent;
  let fixture: ComponentFixture<OverlayInfoSectionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OverlayInfoSectionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OverlayInfoSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
