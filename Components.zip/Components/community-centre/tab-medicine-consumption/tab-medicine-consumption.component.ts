import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tab-medicine-consumption',
  templateUrl: './tab-medicine-consumption.component.html',
  styleUrls: ['./tab-medicine-consumption.component.scss']
})
export class TabMedicineConsumptionComponent implements OnInit {
  medicineList = [1, 1, 1, 1, 1, 2, 11, 1, 1, 2, 111, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
  constructor() { }

  ngOnInit(): void {
  }

}
