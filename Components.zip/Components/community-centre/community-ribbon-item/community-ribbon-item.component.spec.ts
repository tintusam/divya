import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CommunityRibbonItemComponent } from './community-ribbon-item.component';

describe('CommunityRibbonItemComponent', () => {
  let component: CommunityRibbonItemComponent;
  let fixture: ComponentFixture<CommunityRibbonItemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CommunityRibbonItemComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CommunityRibbonItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
