import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

// import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgxChartsModule } from '@swimlane/ngx-charts';

import { CommunityCentreRoutingModule } from './community-centre-routing.module';
import { CommunityCenterLandingPageComponent } from './community-center-landing-page/community-center-landing-page.component';
import { CommunityRibbonItemComponent } from './community-ribbon-item/community-ribbon-item.component';
import { OverlayInfoSectionComponent } from './overlay-info-section/overlay-info-section.component';
import { TabCommunityTemperatureComponent } from './tab-community-temperature/tab-community-temperature.component';
import { TabCommunityHumidityComponent } from './tab-community-humidity/tab-community-humidity.component';
import { TabCommunityFallDetectionComponent } from './tab-community-fall-detection/tab-community-fall-detection.component';

import { TabCommunityPatientHealthComponent } from './tab-community-patient-health/tab-community-patient-health.component';
import { TabMedicineConsumptionComponent } from './tab-medicine-consumption/tab-medicine-consumption.component';

@NgModule({
  declarations: [
    CommunityCenterLandingPageComponent,
    CommunityRibbonItemComponent,
    OverlayInfoSectionComponent,
    TabCommunityTemperatureComponent,
    TabCommunityHumidityComponent,
    TabCommunityFallDetectionComponent,
    TabCommunityPatientHealthComponent,
    TabMedicineConsumptionComponent,
  ],
  imports: [
    CommonModule,
    CommunityCentreRoutingModule,
    NgbModule,

    NgxChartsModule,
    // BrowserAnimationsModule
  ],
})
export class CommunityCentreModule { }
