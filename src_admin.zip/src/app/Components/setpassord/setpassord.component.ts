import { Component, OnInit } from '@angular/core';
import { Router  , ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';
import { AuthenticateService} from '../../Utilities/authenticate.service';

@Component({
  selector: 'app-setpassord',
  templateUrl: './setpassord.component.html',
  styleUrls: ['./setpassord.component.scss']
})
export class SetpassordComponent implements OnInit {

  constructor(private _route:ActivatedRoute,  private _auth:AuthenticateService) { }
  setPasswordModel:any ={};
  inviteMsg:any;
  redirectToLogin:boolean = false;

  ngOnInit() {
    //console.log(this._route.snapshot.params['id']);

    // Define the string
// var string = 'divya.gopinath4@wipro.com';

// // Encode the String
// var encodedString = btoa(string);
// console.log(encodedString); // Outputs: "ZGl2eWEuZ29waW5hdGg0QHdpcHJvLmNvbQ=="

// // Decode the String
// var decodedString = atob(encodedString);
// console.log(decodedString); // Outputs: "Hello World!"


  }

  // to invite supervisor
  onSetPassword(supervisor: NgForm){
    let payload: any = {
      'LoggedInEmail': atob(this._route.snapshot.params['id']),
      'Password': supervisor.value.password
    };
    this._auth.onSetPassword(payload).subscribe(res => {
      this.inviteMsg = res;
      this.redirectToLogin = true;
    },
    err => {
        if (err.status == 500){
          this.inviteMsg = "Remote servers are not responding at the moment. Please try after sometime.";
          this.redirectToLogin = false;
        }
        if (err.status == 400){
          this.inviteMsg = "User already registered!";
          this.redirectToLogin = false;
        }
    });
  }


}
