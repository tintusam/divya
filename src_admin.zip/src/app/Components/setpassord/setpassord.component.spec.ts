import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SetpassordComponent } from './setpassord.component';

describe('SetpassordComponent', () => {
  let component: SetpassordComponent;
  let fixture: ComponentFixture<SetpassordComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SetpassordComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SetpassordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
