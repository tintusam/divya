/// <reference path="../../../../../../node_modules/bingmaps/types/MicrosoftMaps/Microsoft.Maps.All.d.ts" />

import { Component, OnInit, ElementRef, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { environment } from '../../../../../environments/environment.prod';
import { AssetService } from '../../../../Services/asset.service';
import { MessageService } from 'primeng/api';

// Added By ABhishek
import { ISasToken } from '../azure-storage/azureStorage';
import { BlobStorageService } from '../azure-storage/blob-storage.service';
import { from, Observable } from 'rxjs';
import { combineAll, map } from 'rxjs/operators';
// Abhishek Declaration ENds Here

interface IUploadProgress {
  filename: string;
  progress: number;
}

@Component({
  selector: 'app-facilities-management',
  templateUrl: './facilities-management.component.html',
  styleUrls: ['./facilities-management.component.scss']
})
export class FacilitiesManagementComponent implements OnInit {

  url: string
  highlight: Array<boolean> = [];
  public pos = [];
  public image;
  public selected;
  public index;
  public facilityName;
  public Location;
  public ZoneForm: FormGroup;
  public zones = [];
  public posx;
  public posy;
  public facilityList = [];
  public showImage = false;
  public showHeader = true;
  public searchText;
  click: any;
  public FacilityID;
  public showPopup:boolean = false;
  // Asset Image Related Variables
  fileInfo: any;
  uploadProgress$: Observable<IUploadProgress[]>;
  filesSelected = false;
  fileName: String;
  blobAccessUrl = environment.blobAccessUrl;
  fileUploadProgress: number;
  showLoader: boolean;
  showUploadComplete: boolean;
  imageRefUrl = '';
  showImageUploaded: boolean;
  GatewayList: any;
  public new = true;

  private _hasFacilityImage = '';
  private _getSelectedFloorInfo = '';
  private _getSelectedGatewayList = '';

  @Input()
  set showImageStatus(hasFacilityImage: any) {
    this._hasFacilityImage = hasFacilityImage;
    if(hasFacilityImage != undefined){
      this.showImage = hasFacilityImage;
      if(this.showImage == true){
        this.new = false;
      }else{
        this.new = true;
      }
      //console.log(this.showImage);
    }
  }

  get hasFacilityImage(): any { return this._hasFacilityImage; }

  @Input()
  set showSelectedFloorInfo(getSelectedFloorInfo: any) {
    this._getSelectedFloorInfo = getSelectedFloorInfo;
    if(getSelectedFloorInfo != undefined){
      this.facilityList = this.getSelectedFloorInfo;
      //console.log(this.facilityList);
      this.listAllGateWays();
      this.onGetFloorImage(this.facilityList);
    }else{
      this.imageRefUrl = '';
      this.zones = [];
      this.facilityName = '';
      this.Location = '';
      this.FacilityID = '';
    }
  }

  get getSelectedFloorInfo(): any { return this._getSelectedFloorInfo; }

  // Getting gateway list from sitemanagement page
  @Input()
  set showGatewayList(GetGatewayList: any) {
    this._getSelectedGatewayList = GetGatewayList;
    if(GetGatewayList != undefined){
      this.GatewayList = this.GetGatewayList;
      //console.log(this.GatewayList);
    }
  }

  get GetGatewayList(): any { return this._getSelectedGatewayList; }

  constructor(private fb: FormBuilder,
    private _assetservice: AssetService,
    private blobStorage: BlobStorageService,
    private _messageService:MessageService,
    private el: ElementRef) {
    this.showImageUploaded = false;
    this.ZoneForm = this.fb.group({
      zoneName: [null, Validators.required],
      bleGatewaySno: [null, Validators.required]
    });
  }

  ngOnInit() {
    this.listAllGateWays();
    this.getAllFacilityList();
  }

  // Method to list All Gateways
  listAllGateWays(){
    let payload = {
      Sid:JSON.parse(sessionStorage.getItem("SiteId"))  
    }
    this._assetservice.GetGatewayList(payload)
    .subscribe(res => {
      this.GatewayList = res;
      console.log(this.GatewayList);
    })
  }

  // Method to list all facilities
  getAllFacilityList() {
    let payload = {
      SiteID:JSON.parse(sessionStorage.getItem("SiteId"))  
    }
    this._assetservice.GetAllFacilityList(payload)
      .subscribe(res => {
        this.facilityList = res[0]; // taking only first item
        this.onGetFloorImage(this.facilityList);
      })
  }

  // Upload Asset Image Section Here =================================================
  onFileChange(event: any): void {
    this.showLoader = true;
    this.showUploadComplete = false;
    this.filesSelected = true;
    this.uploadProgress$ = from(event.target.files as FileList).pipe(
      map(file => this.uploadFile(file)), // Getting FIle Details HEre
      combineAll()
    );
  }

  uploadFile(file: File): Observable<IUploadProgress> {
    this.fileName = file.name;
    let accessToken: ISasToken = {
      container: 'facilityimage',
      filename: file.name,
      storageAccessToken: environment.SAS_Token,
      storageUri: environment.storageLink + environment.SAS_Token,
    };
    this.imageRefUrl = this.blobAccessUrl + this.fileName;
    console.log(accessToken);
    console.log(this.imageRefUrl);
    return this.blobStorage
      .uploadToBlobStorage(accessToken, file)
      .pipe(map(progress => this.mapProgress(file, progress)));
  }

  private mapProgress(file: File, progress: number): IUploadProgress {
    if (progress === 100) {
      this.showLoader = false;
      this.showUploadComplete = true;
      this.showImage = true;
      this.filesSelected = false;
      this.showImage = true;
      this.showImageUploaded = true;
    }
    return {
      filename: file.name,
      progress: progress
    };
  }
  // Upload Asset Image Section ENds Here =============================================

  // Method to get location point 
  onGetLocationPoints(e) {
    this.ZoneForm.reset();
    if (this.imageRefUrl) {
      var svg = this.el.nativeElement.querySelector('#mySvg');
      var pt = svg.createSVGPoint();
      pt.x = e.clientX; //x position within the element.
      pt.y = e.clientY;
      var svgP = pt.matrixTransform(svg.getScreenCTM().inverse());
      this.posx = svgP.x;
      this.posy = svgP.y;
      //console.log(this.posx, this.posy)
    }
  }

 onHighlightOption(i, options) {
    this.highlight.fill(false);
    this.highlight[i] = !this.highlight[i]
    this.selected = options;
  }

  onGetFloorImage(floor) {
    //console.log(floor);
    if(floor != undefined){
      this.imageRefUrl = floor.ImageUrl;
      this.zones = floor.Zones;
      this.facilityName = floor.FacilityName;
      this.Location = floor.Location;
      this.FacilityID = floor.FacilityID || '';
      this.showImage = true;
    }

  }

 onSaveZones(post) {
    if (post.zoneName && post.bleGatewaySno) {
      this.pos.push({ x: this.posx, y: this.posy });
      this.zones.push({
        ZoneName: post.zoneName,
        GatewaySlNo: post.bleGatewaySno,
        Top: this.posy,
        Left: this.posx
      });
      this.onUpdateFacility()
    }
  }

  resetForm() {
    this.ZoneForm.reset();
  }

  onCreateFacility() {
    if (!this.facilityName) {
      this._messageService.clear();
      this._messageService.add({ life: 4000, sticky: false, severity: 'error', summary: 'Alert', detail: 'The Facility Name is Required' });
    }
    else if (!this.imageRefUrl) {
      this._messageService.clear();
      this._messageService.add({ life: 4000, sticky: false, severity: 'error', summary: 'Alert', detail: 'The Facility Map is Required' });
    }
    else {
      const payload = {
        FacilityName: this.facilityName,
        Location: this.Location,
        Zones: this.zones,
        ImageUrl: this.imageRefUrl,
        SiteID:JSON.parse(sessionStorage.getItem("SiteId"))
      }
      //console.log(payload);
      this._assetservice.CreateFacility(payload)
        .subscribe(res => {
          //console.log(res)
          this._messageService.clear();
          this._messageService.add({ life: 4000, sticky: false, severity: 'success', summary: 'Success', detail: 'The Facility is created on the Site.' });
          this.Abort();
          this.showImage = false;
          this.getAllFacilityList();
        });
    }
  }

  public Abort() {
    this.facilityName = '';
    this.Location = '';
    this.imageRefUrl = '';
    this.pos = [];
    this.zones = [];
    this.showImage = false;
  }

  onUpdateFacility() {
    const payload = {
      FacilityName: this.facilityName,
      Location: this.Location,
      Zones: this.zones,
      ImageUrl: this.imageRefUrl,
      FacilityID: this.FacilityID,
      SiteID:JSON.parse(sessionStorage.getItem("SiteId"))
    }
    //console.log(payload);
    this._assetservice.UpdateFacility(payload)
      .subscribe(res => {
        this._messageService.clear();
        this._messageService.add({ life: 4000, sticky: false, severity: 'success', summary: 'Success', detail: 'The Facility has been updated successfully!' });
        this.getAllFacilityList();
        this.Abort();
      });
  }

  onDeleteFacility(FacId) {
    var r = confirm("Delete Facility?");
    if (r == true) {
      this._assetservice.DeleteFacility(FacId)
        .subscribe(res => {
          this.getAllFacilityList();
          this.Abort();
          this.new = false;
        })
    }
  }

  onRefreshPlan() {
    this.showImageUploaded = false;
    this.ZoneForm = this.fb.group({
      zoneName: [null, Validators.required],
      bleGatewaySno: [null, Validators.required]
    });
    this.facilityList = [];
    this.getAllFacilityList();
  }

  OnEdit(zone, i) {
    this.selected = zone;
    this.index = i;
    this.showPopup = !this.showPopup;
    console.log(zone);
  }
}
