import { Component, OnInit, Output, EventEmitter, ViewChild, ElementRef } from '@angular/core';
import * as atlas from 'azure-maps-control';
import * as atlasTool from 'azure-maps-drawing-tools';
import * as atlasService from 'azure-maps-rest';
import { AtlasMapComponent } from '@acaisoft/angular-azure-maps';
import { environment } from 'src/environments/environment.prod';
import { AppService } from 'src/app/Services/app.service';
import { MessageService } from 'primeng/api';
@Component({
  selector: 'app-add-site',
  templateUrl: './add-site.component.html',
  styleUrls: ['./add-site.component.scss']
})
export class AddSiteComponent implements OnInit {


  public type;
  public SId;
  public managerName;
  public mangerId;
  public temperatureThreshold;
  public EmployeeCountThreshold;
  public showCreateButton = false
  // public location;
  // public lat;
  // public lng;


  //map 
  key: string = environment.azureMapsPrimaryKey;
  authTypeValue = 'subscriptionKey';
  subscriptionKey: any
  map: any;
  position;
  marker;
  eventClick: any;
  searchText;

  public drawingManager: any;

  // public siteList:any=new Array();
  locationInfo: any;
  datasource; client: any; popup: any; searchInput: string; resultsPanel: any; searchInputLength: any; centerMapOnResults;

  //The minimum number of characters needed in the search input before a search is performed.
  minSearchInputLength = 2;

  //The number of ms between key strokes to wait before performing a search.
  keyStrokeDelay = 150;
  responseSearch = [];

  public config = {
    'zoom': 1.5,
    'center': [20, 20],
    'interactive': true,
  };
  location: string;
  lat: any;
  lng: any;
  map1: atlas.Map;

  @Output() onExit = new EventEmitter<any>();

  @ViewChild('maper', { static: false }) maper: AtlasMapComponent;
  @ViewChild('mapContainer', { static: false }) mapContainer;
  @ViewChild('results-panel', { static: false }) resultspanel: ElementRef;
  @ViewChild('search-input', { static: false }) searchinput: ElementRef;
  managerMail: any;
  country: any;
  state: any;
  selected: boolean;
  toolbar: atlasTool.control.DrawingToolbar;


  constructor(private service: AppService, private messageService: MessageService) { }

  ngOnInit() {
    setTimeout(() => {
      this.GetMap();
      // console.log("uday");
    }, 1000);
  }


  GetMap() {
    // console.log("uday");
    //Initialize a map instance.
    this.map = new atlas.Map('myMap', {
      center: [77.6583, 12.8379],
      zoom: 2,
      view: 'Auto',

      //Add your Azure Maps subscription key to the map SDK. Get an Azure Maps key at https://azure.com/maps
      authOptions: {
        authType: atlas.AuthenticationType.subscriptionKey,
        subscriptionKey: 'i6AdgV8rulpPXVcK-6iWYY_PzomZjHXBijEXYgmFR2o'
      }
    });

    //Store a reference to the Search Info Panel.
    this.resultsPanel = document.getElementById("results-panel");

    //Add key up event to the search box. 
    // this.searchInput = document.getElementById("search-input");
    // this.searchInput.addEventListener("keyup", searchInputKeyup);

    //Create a popup which we can reuse for each result.
    this.popup = new atlas.Popup();

    //Wait until the map resources are ready.
    this.map.events.add('ready', () => {

      //Add the zoom control to the map.
      this.map.controls.add(new atlas.control.ZoomControl(), {
        position: 'top-right'
      });

      //Create a data source and add it to the map.
      this.datasource = new atlas.source.DataSource();
      this.map.sources.add(this.datasource);

      //Add a layer for rendering the results.
      var searchLayer = new atlas.layer.SymbolLayer(this.datasource, null, {
        iconOptions: {
          image: 'pin-round-darkblue',
          anchor: 'center',
          allowOverlap: true
        }
      });
      this.map.layers.add(searchLayer);

      //Add a click event to the search layer and show a popup when a result is clicked.
      this.map.events.add("click", searchLayer, function (e) {
        //Make sure the event occurred on a shape feature.
        if (e.shapes && e.shapes.length > 0) {
          this.showPopup(e.shapes[0]);
        }
      });
    });


    //   var marker = new atlas.HtmlMarker({
    //     color: 'DodgerBlue',
    //     text: '50',
    //     position: [0, 0],
    //     popup: new atlas.Popup({
    //         content: '<div style="padding:10px">Hello World</div>',
    //         pixelOffset: [0, -30]
    //     })
    // });

    // this.map.markers.add(marker);
  }


  searchInputKeyup(event: KeyboardEvent) {
    this.selected = false;
    //// console.log('EVENT: ' + event.target['value']);
    this.responseSearch = [];
    // this.searchInput = '';
    this.searchInput = event.target['value'];
    // // console.log('EVENT2: ' + (this.searchInput.length));
    this.centerMapOnResults = false;
    if (this.searchInput.length >= this.minSearchInputLength) {
      if (event.keyCode === 13) {
        this.centerMapOnResults = true;
      }
      //Wait 100ms and see if the input length is unchanged before performing a search. 
      //This will reduce the number of queries being made on each character typed.
      // setTimeout(function () {

      //   if (this.searchInputLength === this.searchInput.length) {
      //     this.search();
      //   }
      // }, this.keyStrokeDelay);
      this.search();
    } else {
      this.resultsPanel = '';
    }
    this.searchInputLength = this.searchInput.length;
    // console.log(this.searchInputLength);
  }

  search() {
    //Remove any previous results from the map.
    this.datasource = {};
    this.popup.close();
    this.resultsPanel = '';
    // this.resultsPanel.innerHTML = '';

    //Use SubscriptionKeyCredential with a subscription key
    var subscriptionKeyCredential = new atlasService.SubscriptionKeyCredential(atlas.getSubscriptionKey());

    //Use subscriptionKeyCredential to create a pipeline
    var pipeline = atlasService.MapsURL.newPipeline(subscriptionKeyCredential);

    //Construct the SearchURL object
    var searchURL = new atlasService.SearchURL(pipeline);

    var query = this.searchInput;
    searchURL.searchPOI(atlasService.Aborter.timeout(10000), query, {
      lon: this.map.getCamera().center[0],
      lat: this.map.getCamera().center[1],
      maxFuzzyLevel: 4,
      view: 'Auto'
    }).then((results) => {

      //Extract GeoJSON feature collection from the response and add it to the datasource
      var data = results.geojson.getFeatures();
      //// console.log('RESPONSE: ' + JSON.stringify(data));
      this.datasource = (data);

      if (this.centerMapOnResults) {
        this.map.setCamera({
          bounds: data.bbox
        });
      }
      // console.log(data);
      //Create the HTML for the results list.
      var html = [];
      this.responseSearch = data.features;
      // for (var i = 0; i < data.features.length; i++) {
      //   var r = data.features[i];
      //   html.push('<li onclick="itemClicked(\'', r.id, '\')" onmouseover="itemHovered(\'', r.id, '\')">')
      //   html.push('<div class="title">');
      //   if (r.properties.poi && r.properties.poi.name) {
      //     html.push(r.properties.poi.name);
      //   } else {
      //     html.push(r.properties.address.freeformAddress);
      //   }
      //   html.push('</div><div class="info">', r.properties.type, ': ', r.properties.address.freeformAddress, '</div>');
      //   if (r.properties.poi) {
      //     if (r.properties.phone) {
      //       html.push('<div class="info">phone: ', r.properties.poi.phone, '</div>');
      //     }
      //     if (r.properties.poi.url) {
      //       html.push('<div class="info"><a href="http://', r.properties.poi.url, '">http://', r.properties.poi.url, '</a></div>');
      //     }
      //   }
      //   html.push('</li>');
      //   // this.resultsPanel.innerHTML = html.join('');
      // }

    });

  }

  showClickedPlace(response) {
    // // alert(coordinates);
    // console.log("response", response);
    this.searchText = response.properties.poi.name + ',' + response.properties.address.freeformAddress;
    // console.log("searchtext: " + this.searchText);
    this.selected = true;

    this.location = response.properties.poi.name + ',' + response.properties.address.freeformAddress;
    this.lat = response.geometry.coordinates[1];
    this.lng = response.geometry.coordinates[0];

    this.country = response.properties.address.country;
    this.state = response.properties.address.countrySubdivision;

    // console.log(this.country, this.state);

    //  this.service.getTimezone(this.lat, this.lng).subscribe(res => {
    //    // console.log("Timezone res", res["TimeZones"][0]["ReferenceTime"]["Tag"]);
    //    this.timezone = res["TimeZones"][0]["ReferenceTime"]["Tag"];
    //  });;

    this.map = new atlas.Map('myMap', {
      center: [response.geometry.coordinates[0], response.geometry.coordinates[1]],
      zoom: 14,
      view: 'Auto',
    });

    // console.log(this.map.getCamera());


    //Wait until the map resources are ready.
    this.map.events.add('ready', () => {
      this.toolbar = new atlasTool.control.DrawingToolbar({
        position: 'top-right',
        style: 'dark',
        buttons: ["draw-point", "edit-geometry"]
      });
      //Create an instance of the drawing manager and display the drawing toolbar.
      this.drawingManager = new atlasTool.drawing.DrawingManager(this.map, {
        toolbar: this.toolbar
      });
      // console.log(this.toolbar.getOptions());
    });

    // this.eventClick=this.map.events.add("click", (e)=>{

    //     this.position = [e.position[0], e.position[1]];
    //     // console.log("position", this.position);
    //     this.marker = new atlas.HtmlMarker({
    //         color: 'red',
    //         // text: '10',
    //         position: this.position,

    //     });
    //     this.lat=this.position[1];
    //     this.lng=this.position[0];
    //     // console.log("marker", this.marker);
    //     this.map.markers.add(this.marker);
    //     this.map.events.add('click',this.marker, () => {
    //             // this.map.events=[];
    //             // this.form=true;

    //         });
    //         // this.map.events.remove(eventClick);
    //       });

  }

  clear() {
    this.searchText = "";
    this.responseSearch = [];
  }


  createSite() {


    // console.log("GEOFENCE DATA: " + JSON.stringify(source.toJson(), null, '    '));

    if (!this.SId || !this.type || !this.managerName || !this.managerMail || !this.location) {
      // alert("Input fields are empty");
      this.messageService.clear();
      this.messageService.add({ key: 'tl1', life: 8000, sticky: true, severity: 'warn', summary: 'INVALID FORM INPUT', detail: 'Please Fill in all the details in the form' });
    }
    else {
      var source = this.drawingManager.getSource();
      let i;
      if (source.toJson().features[0].geometry.type == "Point") {
        this.lng = source.toJson().features[0].geometry.coordinates[0];
        this.lat = source.toJson().features[0].geometry.coordinates[1];
        i = 1;
      }
      else {
        // alert("Please chhoose a location");
        this.messageService.clear();
        this.messageService.add({ key: 'tl1', life: 8000, sticky: true, severity: 'warn', summary: 'INVALID FORM INPUT', detail: 'Please Choose a Location' });
      }
      // else {
      //   this.lng = source.toJson().features[1].geometry.coordinates[0];
      //   this.lat = source.toJson().features[1].geometry.coordinates[1];
      //   i = 0;
      // }

      // console.log(source.toJSON().features[i].geometry)
      // let geopayload = source.toJson().features[i].geometry;

      // //Add Geofence 

      // geopayload["GeofenceName"] = this.SId;

      // this.service.addGeofence(geopayload)
      //   .subscribe(res => {
      //     // console.log(res);
      //   }, err => {
      //     // console.log(err);
      //   });

      // // console.log(geopayload.coordinates[0][0][0]);

      let payload = {
        "StoreType": this.type,
        "StoreId": this.SId,
        "Location": this.location,
        "Description": "des",
        "Latitude": this.lat,
        "Longitude": this.lng,
        "StoreManager": this.managerName,
        "ManagerEmail": this.managerMail,
        "Geofencename": this.SId,
        "State": this.state,
        "Country": this.country,
        // "TempThreshold": this.temperatureThreshold.toString(),
        // "PeopleLimit": this.EmployeeCountThreshold
        "TempThreshold": 0,
        "PeopleLimit": 0
      }
      // console.log("payload", payload);
      this.service.createSite(payload)
        .subscribe(res => {
          // console.log(res);
          // alert("Site successfully created");
          this.location = "";
          this.onExit.emit(false);
          // sessionStorage.setItem('SiteId',this.SId)
        }, err => {
          // console.log(err);
        });

    }
  }

  close() {
    this.onExit.emit(false);
  }

}
