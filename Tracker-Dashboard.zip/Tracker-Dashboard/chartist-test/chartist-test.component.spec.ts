import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChartistTestComponent } from './chartist-test.component';

describe('ChartistTestComponent', () => {
  let component: ChartistTestComponent;
  let fixture: ComponentFixture<ChartistTestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChartistTestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChartistTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
