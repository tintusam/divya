import { Component, OnInit } from '@angular/core';
import { ChartType } from 'ng-chartist';
import { IChartistData, ILineChartOptions } from 'chartist';
import ChartistTooltip from 'chartist-plugin-tooltips-updated';

@Component({
  selector: 'app-chartist-test',
  templateUrl: './chartist-test.component.html',
  styleUrls: ['./chartist-test.component.scss']
})
export class ChartistTestComponent implements OnInit {

  type: ChartType;
  data: IChartistData;
  options: ILineChartOptions

  constructor() { }

  ngOnInit() {

    this.type = 'Line';
    this.data = {
      labels: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
      series: [[12, 9, 7, 8, 5], [2, 1, 3.5, 7, 3], [1, 3, 4, 5, 6]]
    };
    this.options = {
      plugins: [
        ChartistTooltip({
          anchorToPoint: true,
          appendToBody: true
        })
      ]
    };
  }

}
