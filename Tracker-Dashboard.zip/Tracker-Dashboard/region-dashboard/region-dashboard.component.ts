import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-region-dashboard',
  templateUrl: './region-dashboard.component.html',
  styleUrls: ['./region-dashboard.component.scss']
})
export class RegionDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
