import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserSocialDistancingTabComponent } from './user-social-distancing-tab.component';

describe('UserSocialDistancingTabComponent', () => {
  let component: UserSocialDistancingTabComponent;
  let fixture: ComponentFixture<UserSocialDistancingTabComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserSocialDistancingTabComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserSocialDistancingTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
