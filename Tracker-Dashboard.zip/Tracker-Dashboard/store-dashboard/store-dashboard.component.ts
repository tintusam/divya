import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-store-dashboard',
  templateUrl: './store-dashboard.component.html',
  styleUrls: ['./store-dashboard.component.scss']
})
export class StoreDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
