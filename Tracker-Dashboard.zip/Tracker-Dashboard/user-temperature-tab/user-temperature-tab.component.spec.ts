import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserTemperatureTabComponent } from './user-temperature-tab.component';

describe('UserTemperatureTabComponent', () => {
  let component: UserTemperatureTabComponent;
  let fixture: ComponentFixture<UserTemperatureTabComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserTemperatureTabComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserTemperatureTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
