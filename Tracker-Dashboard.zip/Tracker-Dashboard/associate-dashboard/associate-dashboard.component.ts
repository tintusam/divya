import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-associate-dashboard',
  templateUrl: './associate-dashboard.component.html',
  styleUrls: ['./associate-dashboard.component.scss']
})
export class AssociateDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
