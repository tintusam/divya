import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import * as atlas from 'azure-maps-control';
import * as atlasService from 'azure-maps-rest';
import { AtlasMapComponent } from '@acaisoft/angular-azure-maps';
import { environment } from 'src/environments/environment.prod';
import { Router } from '@angular/router'
import { AppService } from '../../../Services/app.service';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
// import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';

import { MatAccordion } from '@angular/material/expansion';
import * as moment from 'moment';
@Component({
  selector: 'app-tracker-landing-page',
  templateUrl: './tracker-landing-page.component.html',
  styleUrls: ['./tracker-landing-page.component.scss']
})
export class TrackerLandingPageComponent implements OnInit {
  @ViewChild(MatAccordion, { static: false }) accordion: MatAccordion;

  countrySelected = 'all';
  DateRange: string[] = [];
  showLoader2 = true;
  datePickerConfig: Partial<BsDatepickerConfig>;
  countryList: any;
  selectedCountry: any;
  Region: any;
  store: any;
  RegionList: any;
  RegionList2: any;
  RegionSelected = 'all';
  StoreList: any;
  StoreSelected = 'all';
  FilteredStoreList: any;
  TotalPeople = 0;
  QuarantinePeopleCount = 0;
  SDAlertCount = 0;
  SDA_Alert_15minsCount = 0;
  AssociateAlertCount = 0;
  isOpen = [];
  setQuarantineDate = false;
  modifiedDaate = false;
  EmployeeList: any;
  temperatureList: any;
  showLoader = false;
  associateAlertList: any;
  sessionEmail: any;
  customDays: number;
  validSessionToken = true;
  intervalTimer: any;
  localStrToken: any;
  Curr_TimeZone: any
  modalTitle = '';
  paramSiteId = 0;
  showFilterOption = false;
  public show = false;
  showNote = false;
  term: string;
  EmpTerm: string;
  // Azure Maps Related 
  key: string = environment.azureMapsPrimaryKey;
  authTypeValue = 'subscriptionKey';
  subscriptionKey: any
  map: any;
  SetEmployee: any;
  datasource = {}; client: any; popup: any; searchInput: string; resultsPanel: any; searchInputLength: any; centerMapOnResults;

  //The minimum number of characters needed in the search input before a search is performed.
  minSearchInputLength = 2;

  //The number of ms between key strokes to wait before performing a search.
  keyStrokeDelay = 150;
  responseSearch = [];
  selectedStore: any;
  SDA15minListNorm: any;
  markers = [];
  public config = {
    'zoom': 1.5,
    'center': [20, 20],
    'interactive': true,
  };

  SDA15minList: any;

  sessionSid = '';
  @ViewChild('maper', { static: false }) maper: AtlasMapComponent;
  @ViewChild('mapContainer', { static: false }) mapContainer;
  @ViewChild('results-panel', { static: false }) resultspanel: ElementRef;
  @ViewChild('search-input', { static: false }) searchinput: ElementRef;
  marker: atlas.HtmlMarker;

  public showInfo: boolean;
  GenerateTokenResponse: any;
  sitemarkers: any;
  public FacilityClicked = [];
  modifiedDate = false;
  FilterOptionSelected = 2
  constructor(private router: Router, private app: AppService) {
    this.datePickerConfig = Object.assign({},
      {
        containerClass: 'theme-dark-blue',
        showWeekNumbers: false,
        rangeInputFormat: 'YYYY-MM-DD',
        isAnimated: true,
        adaptivePosition: true
      });
  }

  ngOnInit() {
    this.SDA15minListNorm = [];
    this.showNote = false;
    // this.SDA15minList = [
    //   {
    //     "FullName": null,
    //     "EmployeeId": "WIP-SB-5",
    //     "OtherEmployee": "WIP-SB-1",
    //     "BreachCount": 2,
    //     "Duration": 20,
    //     "SdAlertsList": [
    //       {
    //         "StartTime": "2020-07-16T09:08:37Z",
    //         "EndTime": "2020-07-16T09:11:35Z",
    //         "Duration": 3
    //       },
    //       {
    //         "StartTime": "2020-07-16T09:15:53Z",
    //         "EndTime": "2020-07-16T09:32:09Z",
    //         "Duration": 17
    //       }
    //     ]
    //   },
    //   {
    //     "FullName": null,
    //     "EmployeeId": "WIP-SB-1",
    //     "OtherEmployee": "WIP-SB-5",
    //     "BreachCount": 2,
    //     "Duration": 19,
    //     "SdAlertsList": [
    //       {
    //         "StartTime": "2020-07-16T09:08:38Z",
    //         "EndTime": "2020-07-16T09:11:22Z",
    //         "Duration": 3
    //       },
    //       {
    //         "StartTime": "2020-07-16T09:15:51Z",
    //         "EndTime": "2020-07-16T09:31:59Z",
    //         "Duration": 16
    //       },
    //       {
    //         "StartTime": "2020-07-16T09:08:38Z",
    //         "EndTime": "2020-07-16T09:11:22Z",
    //         "Duration": 3
    //       },
    //       {
    //         "StartTime": "2020-07-16T09:15:51Z",
    //         "EndTime": "2020-07-16T09:31:59Z",
    //         "Duration": 16
    //       }, {
    //         "StartTime": "2020-07-16T09:08:38Z",
    //         "EndTime": "2020-07-16T09:11:22Z",
    //         "Duration": 3
    //       },
    //       {
    //         "StartTime": "2020-07-16T09:15:51Z",
    //         "EndTime": "2020-07-16T09:31:59Z",
    //         "Duration": 16
    //       }, {
    //         "StartTime": "2020-07-16T09:08:38Z",
    //         "EndTime": "2020-07-16T09:11:22Z",
    //         "Duration": 3
    //       },
    //       {
    //         "StartTime": "2020-07-16T09:15:51Z",
    //         "EndTime": "2020-07-16T09:31:59Z",
    //         "Duration": 16
    //       }
    //     ]
    //   }
    // ]
    // /////////////////////////////////
    this.Curr_TimeZone = new Date().getTimezoneOffset();
    // alert(this.Curr_TimeZone)

    this.localStrToken = localStorage.getItem('Token')
    // console.log(this.localStrToken)
    let payload = {
      Token: this.localStrToken
    }
    this.app.validateToken(payload).subscribe(res => {
      // console.log(res);
      this.validSessionToken = true;

      this.intervalTimer = setInterval(() => {
        this.localStrToken = localStorage.getItem('Token')
        let payloadReq = {
          Token: this.localStrToken
        }
        this.app.validateToken(payloadReq).subscribe(res => {
          // console.log(res);
          this.validSessionToken = true
        }, error => {
          // console.log('Session Expired', error)
          this.validSessionToken = false;
          clearInterval(this.intervalTimer)
          this.app.setLogin(false);
        })
      }, 60000)
    }, error => {
      // console.log('Session Expired', error)
      this.validSessionToken = false;
      clearInterval(this.intervalTimer)
      this.app.setLogin(false);
    })
    this.sessionSid = sessionStorage.getItem("Sid");
    this.sessionEmail = sessionStorage.getItem('email')
    // if (this.sessionEmail == 'admin@us-foods-demo.com') {
    //   this.RegionSelected = 'Oh';
    //   this.countrySelected = "United States"
    // } else {
    this.RegionSelected = 'all';
    this.countrySelected = 'all';
    // }
    this.paramSiteId = 0;
    this.associateAlertList = [];
    this.modalTitle = '';
    // this.AssociateAlertCount = 0;
    // this.SDAlertCount = 0;
    // this.QuarantinePeopleCount = 0;
    // this.TotalPeople = 0
    // this.datePickerConfig = Object.assign({},
    //   {
    //     containerClass: 'theme-dark-blue',
    //     showWeekNumbers: false,
    //     rangeInputFormat: 'DD/MM/YYYY',
    //     isAnimated: true
    //   });
    this.term = "";
    this.EmpTerm = "";
    this.FacilityClicked = [];

    sessionStorage.setItem('store', 'all');
    this.getRegionBasedOnCountry(this.countrySelected);

    this.loadRegion(this.RegionSelected);
    this.loadCountry(this.countrySelected)
    this.getStoreListBasedOnCountryAndRegion();

    this.showInfo = false;
    this.GetMap();
    // alert(1)
    // this.router.navigate(['/tracker/region-tracker'])
    this.app.getAllCountries().subscribe(res => {
      this.countryList = res;
      this.countryList.unshift({ Country: 'all' })
      // console.log(res)
    })

  }

  GoToLogin() {
    sessionStorage.clear();
    localStorage.clear();
    this.app.setLogin(false);
    // this.router.navigate(['managers-portal/site-management'])
    this.router.navigate(['']);
    // window.location.reload();
  }


  getRegionBasedOnCountry(Country) {
    // alert('Inside Function')
    let payload = {
      "Country": Country
    }
    this.app.getRegionList(payload).subscribe(res => {
      this.RegionList = res;
      // console.log('Region', this.RegionList);
      this.RegionList.unshift({ State: 'all' })
    })
  }

  GetMap() {
    //Initialize a map instance.
    this.map = new atlas.Map('myMap', {
      center: [0, 0],
      zoom: 1,
      view: 'Auto',

      //Add your Azure Maps subscription key to the map SDK. Get an Azure Maps key at https://azure.com/maps
      authOptions: {
        authType: atlas.AuthenticationType.subscriptionKey,
        subscriptionKey: 'i6AdgV8rulpPXVcK-6iWYY_PzomZjHXBijEXYgmFR2o'
      }
    });

    // this.map.events.add("ready", () => {
    //   this.marker = new atlas.HtmlMarker({
    //     htmlContent: '<i class="fa fa-map-pin fa-2x" style="color:purple" aria-hidden="true"></i>',
    //     color: 'blue',
    //     position: [77.6583, 12.8379]
    //   });
    //   // console.log("marker", this.marker);

    //   this.map.events.add('click', this.marker, function (e) {
    //     // // console.log(this.showInfo);
    //     //this.show=1;
    //     //this.showInfo = true;
    //     document.getElementById('check').style.display = 'block';

    //   });
    //   // console.log(this.showInfo);

    //   this.map.markers.add(this.marker);
    //   // console.log("markers", this.map.markers);
    // });


  }

  close() {
    //this.show=false;
    //// console.log(this.show);
    document.getElementById('check').style.display = 'none';
  }

  loadCountry(item) {
    sessionStorage.setItem('Country', item)
    this.paramSiteId = 0;
    sessionStorage.setItem('store', 'all');
    sessionStorage.setItem('paramSite', 'all')

    if (item != 'all') {
      this.selectedCountry = 'Country'
    } else if (item == 'all') {
      this.selectedCountry = ''
    }

  }


  loadRegion(item) {
    sessionStorage.setItem('State', item)
    this.paramSiteId = 0;
    sessionStorage.setItem('store', 'all');
    sessionStorage.setItem('paramSite', 'all')
    if (item != 'all') {
      this.Region = 'Region'
    } else if (item == 'all') {
      this.Region = ''
    }
  }
  loadStore(item) {
    if (item != 'all') {
      this.store = 'Store'
    } else if (item == 'all') {
      this.store = ''
    }
  }
  setQuarantineDateFn() {
    this.showLoader = true;
    if (this.DateRange === [] || this.DateRange === undefined) {
      alert('Please Select the Date Range');
    } else {
      let payload = {
        "Email": this.SetEmployee.Email,
        // "Email": undefined,
        "IsQuarantine": "y",
        "FromDate": this.DateRange[0],
        "ToDate": this.DateRange[1]
      }
      // console.log('HELLLLLLO', payload);
      this.app.updateEmployeeStatus(payload).subscribe(res => {
        // console.log(res);
        this.showLoader = false;
      }, error => {
        alert('Something went wrong..Could not update the quarantine period');
        this.setQuarantineDate = false;
        this.modifiedDate = false;
        this.showLoader = false
      })
    }
  }

  getAlertList(status) {
    this.associateAlertList = [];
    this.showLoader = true;
    if (status === 'Alert') {
      this.modalTitle = 'Associates with Temperature Alert'
    } else if (status === 'Quarantine') {
      this.modalTitle = 'Quarantined Associates'
    } else {
      this.modalTitle = 'Associates with Social Distancing Alert'
    }
    // alert(this.countrySelected + ' ' + this.RegionSelected)
    let payload = {
      "Country": this.countrySelected,
      "Region": this.RegionSelected,
      "Status": status,
      "Sid": this.paramSiteId

    }
    console.log(payload);
    this.app.getEmployeeListforlabels(payload).subscribe(res => {
      console.log(res)
      this.associateAlertList = res;
      this.showLoader = false;
    })
  }

  getCumulativeAlertList() {
    this.DateRange = [];
    this.showLoader = true;
    this.SDA15minList = [];
    // console.log(this.sessionSid);
    let payload = {
      "Sid": this.paramSiteId
    }
    // { Sid: parseInt(sessionStorage.getItem('SiteId')) }
    this.app.getSDAlerts15Mins(payload).subscribe(res => {
      console.log(res)
      this.SDA15minList = res;
      this.showLoader = false;
      this.showFilterOption = false
    }, err => {
      console.log(err)
      this.showLoader = false
    })
  }


  getCumulativeAlertListNorm() {
    this.showLoader = true;
    this.SDA15minListNorm = [];
    // console.log(this.sessionSid);
    let payload = {
      "Sid": this.paramSiteId
    }
    // { Sid: parseInt(sessionStorage.getItem('SiteId')) }
    // this.app.getSDAlerts15MinsNorm(payload).subscribe(res => {
    //   // console.log(res)
    //   this.SDA15minListNorm = res;
    //   this.showLoader = false;
    // }, err => {
    //   console.log(err)
    //   this.showLoader = false
    // })
  }

  getCumulativeAlertListByDays() {
    console.log(this.DateRange)
    this.showLoader = true;
    this.SDA15minList = [];
    // console.log(this.sessionSid);
    let payload = {
      "Sid": this.paramSiteId,
      "FromDate": moment(this.DateRange[0]).format('YYYY-MM-DD'),
      "ToDate": moment(this.DateRange[1]).format('YYYY-MM-DD')
    }
    // { Sid: parseInt(sessionStorage.getItem('SiteId')) }
    this.app.getSDAlerts15MinsByDays(payload).subscribe(res => {
      console.log(res)
      this.SDA15minList = res;
      this.showLoader = false;
      this.showFilterOption = false
      // this.FilterOptionSelected = 0;
      this.showFilterOption = false;
      this.showNote = true;

    }, err => {
      console.log(err)
      this.showLoader = false
      this.FilterOptionSelected = 0;
    })
  }

  getStoreListBasedOnCountryAndRegion() {
    this.SDAlertCount = 0; this.TotalPeople = 0;
    this.AssociateAlertCount = 0; this.QuarantinePeopleCount = 0; this.SDA_Alert_15minsCount = 0
    let payload = {
      "Country": this.countrySelected,
      "Region": this.RegionSelected
    }
    this.app.getStoreList(payload).subscribe(res => {
      this.FilteredStoreList = []
      this.StoreList = res;
      if (this.sessionSid === "0") {
        this.FilteredStoreList = this.StoreList
      } else {
        for (let item of this.StoreList) {
          if (item.Sid === parseInt(this.sessionSid)) {
            this.FilteredStoreList.push(item)
          }
        }
      }
      // this.FilteredStoreList = res; //To add Site Filtration Comment this --->IMPORTANT
      this.showLoader2 = false
      // // console.log('IDHAR', this.FilteredStoreList)
      for (let item of this.FilteredStoreList) {
        // "TotalCount": 1,
        // "AlertCount": 0,
        // "QuarantineCount": 0,
        // "SocilaDistancingCount": 0
        this.SDAlertCount = this.SDAlertCount + item.SocilaDistancingCount;
        sessionStorage.setItem('SDA_Counts', this.SDAlertCount.toString())
        this.TotalPeople = this.TotalPeople + item.TotalCount;

        this.QuarantinePeopleCount = this.QuarantinePeopleCount + item.QuarantineCount;
        sessionStorage.setItem('QuarantineCount', this.QuarantinePeopleCount.toString())
        this.AssociateAlertCount = this.AssociateAlertCount + item.AlertCount
        sessionStorage.setItem('TempAlertCount', this.AssociateAlertCount.toString())
        this.SDA_Alert_15minsCount = this.SDA_Alert_15minsCount + item.SocialDistanceDurationReport
      }

      this.map.markers.clear();

      for (let item of this.FilteredStoreList) {

        if (item.TotalCount != 0 && (item.SocilaDistancingCount != 0 || item.AlertCount != 0 || item.QuarantineCount != 0)) {
          // alert('Inside Here');
          this.sitemarkers = new atlas.HtmlMarker({
            htmlContent: '<svg xmlns="http://www.w3.org/2000/svg" height="33pt" viewBox="0 0 64 64" width="43pt"><g><path d="m32 39a15 15 0 1 0 -15-15 15.017 15.017 0 0 0 15 15zm-.625-26.781a1 1 0 0 1 1.25 0l10 8a1 1 0 0 1 -.625 1.781h-1v11a1 1 0 0 1 -1 1h-16a1 1 0 0 1 -1-1v-11h-1a1 1 0 0 1 -.625-1.781z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#c70039"/><path d="m25 21v11h3v-7a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v7h3v-11a1 1 0 0 1 .4-.8l-7.4-5.919-7.4 5.919a1 1 0 0 1 .4.8z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#c70039"/><path d="m30 26h4v6h-4z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#c70039"/><path d="m32 59.53c3.667-4.008 20-22.54 20-34.53 0-11.972-8.6-21-20-21s-20 9.028-20 21c0 11.995 16.332 30.521 20 34.53zm0-52.53a17 17 0 1 1 -17 17 17.019 17.019 0 0 1 17-17z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#c70039"/><path d="m2 60h4v2h-4z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#c70039"/><path d="m8 60h19v2h-19z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#c70039"/><path d="m58 60h4v2h-4z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#c70039"/><path d="m37 60h19v2h-19z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#c70039"/></g> </svg>',
            color: 'red',
            position: [item.Longitude, item.Latitude],
            popup: new atlas.Popup({
              content: '<div style="color:white">' + '<div style="padding:10px;text-align:center;font-weight:700;margin-bottom:-10px;color:yellow"> ' + item.StoreId + ' </div>' + ' <div style="padding:10px"> <span><svg xmlns="http://www.w3.org/2000/svg" height="15px" width="15px" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" width="512px" height="512px" viewBox="0 0 98.736 98.736" style="enable-background:new 0 0 98.736 98.736;" xml:space="preserve"><g><g> <g><path d="M26.417,56.739c0-5.115,1.688-9.838,4.528-13.656c-2.974-2.673-6.893-4.313-11.205-4.313    c-9.272,0-16.789,7.518-16.789,16.789c0,0,3.95,35.276,16.789,35.276c4.962,0,8.592-5.274,11.184-11.739    c-3.025-9.953-4.248-19.888-4.488-22.026L26.417,56.739z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/> <path d="M19.74,37.554c5.617,0,10.503-3.125,13.02-7.729c-2.513-3.413-4.006-7.619-4.006-12.173c0-2.066,0.313-4.06,0.882-5.943    c-2.625-2.358-6.088-3.808-9.896-3.808c-8.188,0-14.826,6.639-14.826,14.827C4.914,30.915,11.552,37.554,19.74,37.554z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="M78.996,38.77c-4.312,0-8.23,1.64-11.205,4.313c2.842,3.818,4.528,8.541,4.528,13.656l-0.019,0.33    c-0.24,2.14-1.463,12.073-4.488,22.026c2.592,6.465,6.222,11.739,11.184,11.739c12.839,0,16.789-35.276,16.789-35.276    C95.785,46.288,88.268,38.77,78.996,38.77z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="M65.977,29.824c2.517,4.604,7.401,7.729,13.02,7.729c8.188,0,14.826-6.639,14.826-14.826    c0-8.188-6.639-14.827-14.826-14.827c-3.809,0-7.271,1.449-9.896,3.808c0.568,1.884,0.883,3.877,0.883,5.943    C69.982,22.205,68.489,26.411,65.977,29.824z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="M49.368,36.751c-11.039,0-19.988,8.949-19.988,19.988c0,0,4.704,41.997,19.988,41.997s19.987-41.997,19.987-41.997    C69.355,45.7,60.407,36.751,49.368,36.751z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><circle cx="49.368" cy="17.651" r="17.651" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/></g></g></g> </svg> ' + item.TotalCount + ' </span>  <span style="padding:10px"><svg xmlns="http://www.w3.org/2000/svg" id="Layer_1" height="20px" width="20px" enable-background="new 0 0 512 512" height="512px" viewBox="0 0 512 512" width="512px"><g><g><path d="m41.4 359.02c-5.265 0-10.393-.592-15.337-1.681l8.443 77.773c.826 7.613 7.255 13.381 14.912 13.381h63.162c7.657 0 14.086-5.768 14.912-13.381l8.443-77.773c-4.944 1.09-10.071 1.681-15.337 1.681z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m342.943 405.573-15.5-13.126c-6.322-5.355-15.787-4.567-21.141 1.753-1.952 2.306-3.079 5.03-3.427 7.82h-93.751c-.349-2.79-1.475-5.514-3.427-7.82-5.355-6.322-14.819-7.107-21.141-1.753l-15.5 13.126c-3.366 2.85-5.307 7.037-5.307 11.447s1.94 8.597 5.307 11.447l15.5 13.126c2.818 2.387 6.261 3.554 9.686 3.554 4.258 0 8.488-1.804 11.455-5.307 1.952-2.306 3.079-5.03 3.427-7.82h93.751c.349 2.79 1.475 5.514 3.427 7.82 2.968 3.503 7.197 5.307 11.455 5.307 3.425 0 6.867-1.167 9.686-3.554l15.5-13.126c3.366-2.85 5.307-7.037 5.307-11.447s-1.94-8.596-5.307-11.447z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m146.964 167.571c-15.244 19.759-39.135 32.522-65.964 32.522s-50.72-12.763-65.964-32.522c-9.178 7.637-15.036 19.17-15.036 32.053v87.793c0 22.94 18.572 41.604 41.4 41.604h79.2c22.828 0 41.4-18.663 41.4-41.604v-87.793c0-12.883-5.858-24.416-15.036-32.053z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m81 170.094c29.386 0 53.293-23.907 53.293-53.293s-23.907-53.294-53.293-53.294-53.293 23.908-53.293 53.294c0 29.385 23.907 53.293 53.293 53.293z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m391.4 359.02c-5.265 0-10.393-.592-15.337-1.681l8.443 77.773c.826 7.613 7.255 13.381 14.912 13.381h63.162c7.657 0 14.086-5.768 14.912-13.381l8.443-77.773c-4.944 1.09-10.071 1.681-15.337 1.681z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m496.964 167.571c-15.244 19.759-39.135 32.522-65.964 32.522s-50.72-12.763-65.964-32.522c-9.178 7.637-15.036 19.17-15.036 32.052v87.793c0 22.94 18.572 41.604 41.4 41.604h79.2c22.828 0 41.4-18.663 41.4-41.604v-87.793c0-12.882-5.858-24.415-15.036-32.052z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m431 170.094c29.386 0 53.293-23.907 53.293-53.293s-23.907-53.294-53.293-53.294-53.293 23.908-53.293 53.294c0 29.385 23.907 53.293 53.293 53.293z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/></g></g> </svg>  ' + item.SocilaDistancingCount + ' </span>  </div>',
              pixelOffset: [0, -30],
              fillColor: 'rgba(10,0,0,0.85)'
            })
          });

        }

        else if (item.TotalCount != 0 && (item.SocilaDistancingCount == 0 || item.AlertCount == 0 || item.QuarantineCount == 0)) {

          this.sitemarkers = new atlas.HtmlMarker({
            htmlContent: '<svg xmlns="http://www.w3.org/2000/svg" height="33pt" viewBox="0 0 64 64" width="43pt"><g><path d="m32 39a15 15 0 1 0 -15-15 15.017 15.017 0 0 0 15 15zm-.625-26.781a1 1 0 0 1 1.25 0l10 8a1 1 0 0 1 -.625 1.781h-1v11a1 1 0 0 1 -1 1h-16a1 1 0 0 1 -1-1v-11h-1a1 1 0 0 1 -.625-1.781z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#2b580c"/><path d="m25 21v11h3v-7a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v7h3v-11a1 1 0 0 1 .4-.8l-7.4-5.919-7.4 5.919a1 1 0 0 1 .4.8z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#2b580c"/><path d="m30 26h4v6h-4z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#2b580c"/><path d="m32 59.53c3.667-4.008 20-22.54 20-34.53 0-11.972-8.6-21-20-21s-20 9.028-20 21c0 11.995 16.332 30.521 20 34.53zm0-52.53a17 17 0 1 1 -17 17 17.019 17.019 0 0 1 17-17z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#2b580c"/><path d="m2 60h4v2h-4z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#2b580c"/><path d="m8 60h19v2h-19z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#2b580c"/><path d="m58 60h4v2h-4z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#2b580c"/><path d="m37 60h19v2h-19z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#2b580c"/></g> </svg>',
            color: 'green',
            position: [item.Longitude, item.Latitude],
            popup: new atlas.Popup({
              content: '<div style="color:white">' + '<div style="padding:10px;text-align:center;font-weight:700;margin-bottom:-10px;color:yellow"> ' + item.StoreId + ' </div>' + ' <div style="padding:10px"> <span><svg xmlns="http://www.w3.org/2000/svg" height="15px" width="15px" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" width="512px" height="512px" viewBox="0 0 98.736 98.736" style="enable-background:new 0 0 98.736 98.736;" xml:space="preserve"><g><g> <g><path d="M26.417,56.739c0-5.115,1.688-9.838,4.528-13.656c-2.974-2.673-6.893-4.313-11.205-4.313    c-9.272,0-16.789,7.518-16.789,16.789c0,0,3.95,35.276,16.789,35.276c4.962,0,8.592-5.274,11.184-11.739    c-3.025-9.953-4.248-19.888-4.488-22.026L26.417,56.739z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/> <path d="M19.74,37.554c5.617,0,10.503-3.125,13.02-7.729c-2.513-3.413-4.006-7.619-4.006-12.173c0-2.066,0.313-4.06,0.882-5.943    c-2.625-2.358-6.088-3.808-9.896-3.808c-8.188,0-14.826,6.639-14.826,14.827C4.914,30.915,11.552,37.554,19.74,37.554z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="M78.996,38.77c-4.312,0-8.23,1.64-11.205,4.313c2.842,3.818,4.528,8.541,4.528,13.656l-0.019,0.33    c-0.24,2.14-1.463,12.073-4.488,22.026c2.592,6.465,6.222,11.739,11.184,11.739c12.839,0,16.789-35.276,16.789-35.276    C95.785,46.288,88.268,38.77,78.996,38.77z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="M65.977,29.824c2.517,4.604,7.401,7.729,13.02,7.729c8.188,0,14.826-6.639,14.826-14.826    c0-8.188-6.639-14.827-14.826-14.827c-3.809,0-7.271,1.449-9.896,3.808c0.568,1.884,0.883,3.877,0.883,5.943    C69.982,22.205,68.489,26.411,65.977,29.824z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="M49.368,36.751c-11.039,0-19.988,8.949-19.988,19.988c0,0,4.704,41.997,19.988,41.997s19.987-41.997,19.987-41.997    C69.355,45.7,60.407,36.751,49.368,36.751z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><circle cx="49.368" cy="17.651" r="17.651" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/></g></g></g> </svg> ' + item.TotalCount + ' </span>  <span style="padding:10px"><svg xmlns="http://www.w3.org/2000/svg" id="Layer_1" height="20px" width="20px" enable-background="new 0 0 512 512" height="512px" viewBox="0 0 512 512" width="512px"><g><g><path d="m41.4 359.02c-5.265 0-10.393-.592-15.337-1.681l8.443 77.773c.826 7.613 7.255 13.381 14.912 13.381h63.162c7.657 0 14.086-5.768 14.912-13.381l8.443-77.773c-4.944 1.09-10.071 1.681-15.337 1.681z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m342.943 405.573-15.5-13.126c-6.322-5.355-15.787-4.567-21.141 1.753-1.952 2.306-3.079 5.03-3.427 7.82h-93.751c-.349-2.79-1.475-5.514-3.427-7.82-5.355-6.322-14.819-7.107-21.141-1.753l-15.5 13.126c-3.366 2.85-5.307 7.037-5.307 11.447s1.94 8.597 5.307 11.447l15.5 13.126c2.818 2.387 6.261 3.554 9.686 3.554 4.258 0 8.488-1.804 11.455-5.307 1.952-2.306 3.079-5.03 3.427-7.82h93.751c.349 2.79 1.475 5.514 3.427 7.82 2.968 3.503 7.197 5.307 11.455 5.307 3.425 0 6.867-1.167 9.686-3.554l15.5-13.126c3.366-2.85 5.307-7.037 5.307-11.447s-1.94-8.596-5.307-11.447z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m146.964 167.571c-15.244 19.759-39.135 32.522-65.964 32.522s-50.72-12.763-65.964-32.522c-9.178 7.637-15.036 19.17-15.036 32.053v87.793c0 22.94 18.572 41.604 41.4 41.604h79.2c22.828 0 41.4-18.663 41.4-41.604v-87.793c0-12.883-5.858-24.416-15.036-32.053z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m81 170.094c29.386 0 53.293-23.907 53.293-53.293s-23.907-53.294-53.293-53.294-53.293 23.908-53.293 53.294c0 29.385 23.907 53.293 53.293 53.293z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m391.4 359.02c-5.265 0-10.393-.592-15.337-1.681l8.443 77.773c.826 7.613 7.255 13.381 14.912 13.381h63.162c7.657 0 14.086-5.768 14.912-13.381l8.443-77.773c-4.944 1.09-10.071 1.681-15.337 1.681z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m496.964 167.571c-15.244 19.759-39.135 32.522-65.964 32.522s-50.72-12.763-65.964-32.522c-9.178 7.637-15.036 19.17-15.036 32.052v87.793c0 22.94 18.572 41.604 41.4 41.604h79.2c22.828 0 41.4-18.663 41.4-41.604v-87.793c0-12.882-5.858-24.415-15.036-32.052z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m431 170.094c29.386 0 53.293-23.907 53.293-53.293s-23.907-53.294-53.293-53.294-53.293 23.908-53.293 53.294c0 29.385 23.907 53.293 53.293 53.293z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/></g></g> </svg>  ' + item.SocilaDistancingCount + ' </span>  </div>',
              pixelOffset: [0, -30],
              fillColor: 'rgba(10,0,0,0.85)'
            })
          });

        }

        else {

          this.sitemarkers = new atlas.HtmlMarker({
            htmlContent: '<svg xmlns="http://www.w3.org/2000/svg" height="33pt" viewBox="0 0 64 64" width="43pt"><g><path d="m32 39a15 15 0 1 0 -15-15 15.017 15.017 0 0 0 15 15zm-.625-26.781a1 1 0 0 1 1.25 0l10 8a1 1 0 0 1 -.625 1.781h-1v11a1 1 0 0 1 -1 1h-16a1 1 0 0 1 -1-1v-11h-1a1 1 0 0 1 -.625-1.781z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#363636"/><path d="m25 21v11h3v-7a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v7h3v-11a1 1 0 0 1 .4-.8l-7.4-5.919-7.4 5.919a1 1 0 0 1 .4.8z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#363636"/><path d="m30 26h4v6h-4z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#363636"/><path d="m32 59.53c3.667-4.008 20-22.54 20-34.53 0-11.972-8.6-21-20-21s-20 9.028-20 21c0 11.995 16.332 30.521 20 34.53zm0-52.53a17 17 0 1 1 -17 17 17.019 17.019 0 0 1 17-17z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#363636"/><path d="m2 60h4v2h-4z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#363636"/><path d="m8 60h19v2h-19z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#363636"/><path d="m58 60h4v2h-4z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#363636"/><path d="m37 60h19v2h-19z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#363636"/></g> </svg>',
            color: 'grey',
            position: [item.Longitude, item.Latitude],
            popup: new atlas.Popup({
              content: '<div style="color:white">' + '<div style="padding:10px;text-align:center;font-weight:700;margin-bottom:-10px;color:yellow"> ' + item.StoreId + ' </div>' + ' <div style="padding:10px"> <span><svg xmlns="http://www.w3.org/2000/svg" height="15px" width="15px" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" width="512px" height="512px" viewBox="0 0 98.736 98.736" style="enable-background:new 0 0 98.736 98.736;" xml:space="preserve"><g><g> <g><path d="M26.417,56.739c0-5.115,1.688-9.838,4.528-13.656c-2.974-2.673-6.893-4.313-11.205-4.313    c-9.272,0-16.789,7.518-16.789,16.789c0,0,3.95,35.276,16.789,35.276c4.962,0,8.592-5.274,11.184-11.739    c-3.025-9.953-4.248-19.888-4.488-22.026L26.417,56.739z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/> <path d="M19.74,37.554c5.617,0,10.503-3.125,13.02-7.729c-2.513-3.413-4.006-7.619-4.006-12.173c0-2.066,0.313-4.06,0.882-5.943    c-2.625-2.358-6.088-3.808-9.896-3.808c-8.188,0-14.826,6.639-14.826,14.827C4.914,30.915,11.552,37.554,19.74,37.554z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="M78.996,38.77c-4.312,0-8.23,1.64-11.205,4.313c2.842,3.818,4.528,8.541,4.528,13.656l-0.019,0.33    c-0.24,2.14-1.463,12.073-4.488,22.026c2.592,6.465,6.222,11.739,11.184,11.739c12.839,0,16.789-35.276,16.789-35.276    C95.785,46.288,88.268,38.77,78.996,38.77z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="M65.977,29.824c2.517,4.604,7.401,7.729,13.02,7.729c8.188,0,14.826-6.639,14.826-14.826    c0-8.188-6.639-14.827-14.826-14.827c-3.809,0-7.271,1.449-9.896,3.808c0.568,1.884,0.883,3.877,0.883,5.943    C69.982,22.205,68.489,26.411,65.977,29.824z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="M49.368,36.751c-11.039,0-19.988,8.949-19.988,19.988c0,0,4.704,41.997,19.988,41.997s19.987-41.997,19.987-41.997    C69.355,45.7,60.407,36.751,49.368,36.751z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><circle cx="49.368" cy="17.651" r="17.651" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/></g></g></g> </svg> ' + item.TotalCount + ' </span>  <span style="padding:10px"><svg xmlns="http://www.w3.org/2000/svg" id="Layer_1" height="20px" width="20px" enable-background="new 0 0 512 512" height="512px" viewBox="0 0 512 512" width="512px"><g><g><path d="m41.4 359.02c-5.265 0-10.393-.592-15.337-1.681l8.443 77.773c.826 7.613 7.255 13.381 14.912 13.381h63.162c7.657 0 14.086-5.768 14.912-13.381l8.443-77.773c-4.944 1.09-10.071 1.681-15.337 1.681z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m342.943 405.573-15.5-13.126c-6.322-5.355-15.787-4.567-21.141 1.753-1.952 2.306-3.079 5.03-3.427 7.82h-93.751c-.349-2.79-1.475-5.514-3.427-7.82-5.355-6.322-14.819-7.107-21.141-1.753l-15.5 13.126c-3.366 2.85-5.307 7.037-5.307 11.447s1.94 8.597 5.307 11.447l15.5 13.126c2.818 2.387 6.261 3.554 9.686 3.554 4.258 0 8.488-1.804 11.455-5.307 1.952-2.306 3.079-5.03 3.427-7.82h93.751c.349 2.79 1.475 5.514 3.427 7.82 2.968 3.503 7.197 5.307 11.455 5.307 3.425 0 6.867-1.167 9.686-3.554l15.5-13.126c3.366-2.85 5.307-7.037 5.307-11.447s-1.94-8.596-5.307-11.447z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m146.964 167.571c-15.244 19.759-39.135 32.522-65.964 32.522s-50.72-12.763-65.964-32.522c-9.178 7.637-15.036 19.17-15.036 32.053v87.793c0 22.94 18.572 41.604 41.4 41.604h79.2c22.828 0 41.4-18.663 41.4-41.604v-87.793c0-12.883-5.858-24.416-15.036-32.053z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m81 170.094c29.386 0 53.293-23.907 53.293-53.293s-23.907-53.294-53.293-53.294-53.293 23.908-53.293 53.294c0 29.385 23.907 53.293 53.293 53.293z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m391.4 359.02c-5.265 0-10.393-.592-15.337-1.681l8.443 77.773c.826 7.613 7.255 13.381 14.912 13.381h63.162c7.657 0 14.086-5.768 14.912-13.381l8.443-77.773c-4.944 1.09-10.071 1.681-15.337 1.681z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m496.964 167.571c-15.244 19.759-39.135 32.522-65.964 32.522s-50.72-12.763-65.964-32.522c-9.178 7.637-15.036 19.17-15.036 32.052v87.793c0 22.94 18.572 41.604 41.4 41.604h79.2c22.828 0 41.4-18.663 41.4-41.604v-87.793c0-12.882-5.858-24.415-15.036-32.052z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m431 170.094c29.386 0 53.293-23.907 53.293-53.293s-23.907-53.294-53.293-53.294-53.293 23.908-53.293 53.294c0 29.385 23.907 53.293 53.293 53.293z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/></g></g> </svg>  ' + item.SocilaDistancingCount + ' </span>  </div>',
              pixelOffset: [0, -30],
              fillColor: 'rgba(10,0,0,0.85)'
            })
          });

        }

        this.map.markers.add([this.sitemarkers]);
        this.markers.push(this.sitemarkers);


      }
      for (let marker of this.markers) {

        this.map.events.add('click', marker, () => {
          // console.log("clciked");
          marker.togglePopup();
        });

      }
      // // console.log("markers", this.map.markers);


      // // console.log("markers", this.map.markers);

      this.map.setCamera({
        center: [0, 0],
        zoom: 1
      });

      // // console.log('Filter', res)
      this.StoreList.unshift({ StoreId: 'all' })
    })
  }
  getStoreEmployees(SId) {
    this.EmployeeList = [];
    let payload = {
      "Sid": SId
    }
    this.app.getAllStoreEmployees(payload).subscribe(res => {
      this.EmployeeList = []; this.EmployeeList = res;
      // console.log('HERE', res)
    })
  }

  setEmployee(employee) {
    this.SetEmployee = employee;
    sessionStorage.setItem('SetEmployee', JSON.stringify(employee));
    sessionStorage.setItem('EmpEmail', employee.Email);
    this.app.setEmailId(employee.Email)
    // this.app.getTemperatureGraphForEmployee(employee.Email).subscribe(res => {
    //   this.temperatureList = [];
    //   this.temperatureList = res;
    //   sessionStorage.setItem('EmpEmail', employee.Email);
    //   this.app.setEmailId(employee.Email)
    // })
  }

  getMarker(item) {
    this.map.markers.clear();

    // console.log(item.TotalCount);
    if (item.TotalCount != 0 && (item.SocilaDistancingCount != 0 || item.AlertCount != 0 || item.QuarantineCount != 0)) {

      this.sitemarkers = new atlas.HtmlMarker({
        htmlContent: '<svg xmlns="http://www.w3.org/2000/svg" height="33pt" viewBox="0 0 64 64" width="43pt"><g><path d="m32 39a15 15 0 1 0 -15-15 15.017 15.017 0 0 0 15 15zm-.625-26.781a1 1 0 0 1 1.25 0l10 8a1 1 0 0 1 -.625 1.781h-1v11a1 1 0 0 1 -1 1h-16a1 1 0 0 1 -1-1v-11h-1a1 1 0 0 1 -.625-1.781z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#c70039"/><path d="m25 21v11h3v-7a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v7h3v-11a1 1 0 0 1 .4-.8l-7.4-5.919-7.4 5.919a1 1 0 0 1 .4.8z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#c70039"/><path d="m30 26h4v6h-4z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#c70039"/><path d="m32 59.53c3.667-4.008 20-22.54 20-34.53 0-11.972-8.6-21-20-21s-20 9.028-20 21c0 11.995 16.332 30.521 20 34.53zm0-52.53a17 17 0 1 1 -17 17 17.019 17.019 0 0 1 17-17z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#c70039"/><path d="m2 60h4v2h-4z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#c70039"/><path d="m8 60h19v2h-19z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#c70039"/><path d="m58 60h4v2h-4z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#c70039"/><path d="m37 60h19v2h-19z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#c70039"/></g> </svg>',
        color: 'red',
        position: [item.Longitude, item.Latitude],
        popup: new atlas.Popup({
          content: '<div style="color:white">' + '<div style="padding:10px;text-align:center;font-weight:700;margin-bottom:-10px;color:yellow"> ' + item.StoreId + ' </div>' + ' <div style="padding:10px"> <span><svg xmlns="http://www.w3.org/2000/svg" height="15px" width="15px" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" width="512px" height="512px" viewBox="0 0 98.736 98.736" style="enable-background:new 0 0 98.736 98.736;" xml:space="preserve"><g><g> <g><path d="M26.417,56.739c0-5.115,1.688-9.838,4.528-13.656c-2.974-2.673-6.893-4.313-11.205-4.313    c-9.272,0-16.789,7.518-16.789,16.789c0,0,3.95,35.276,16.789,35.276c4.962,0,8.592-5.274,11.184-11.739    c-3.025-9.953-4.248-19.888-4.488-22.026L26.417,56.739z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/> <path d="M19.74,37.554c5.617,0,10.503-3.125,13.02-7.729c-2.513-3.413-4.006-7.619-4.006-12.173c0-2.066,0.313-4.06,0.882-5.943    c-2.625-2.358-6.088-3.808-9.896-3.808c-8.188,0-14.826,6.639-14.826,14.827C4.914,30.915,11.552,37.554,19.74,37.554z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="M78.996,38.77c-4.312,0-8.23,1.64-11.205,4.313c2.842,3.818,4.528,8.541,4.528,13.656l-0.019,0.33    c-0.24,2.14-1.463,12.073-4.488,22.026c2.592,6.465,6.222,11.739,11.184,11.739c12.839,0,16.789-35.276,16.789-35.276    C95.785,46.288,88.268,38.77,78.996,38.77z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="M65.977,29.824c2.517,4.604,7.401,7.729,13.02,7.729c8.188,0,14.826-6.639,14.826-14.826    c0-8.188-6.639-14.827-14.826-14.827c-3.809,0-7.271,1.449-9.896,3.808c0.568,1.884,0.883,3.877,0.883,5.943    C69.982,22.205,68.489,26.411,65.977,29.824z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="M49.368,36.751c-11.039,0-19.988,8.949-19.988,19.988c0,0,4.704,41.997,19.988,41.997s19.987-41.997,19.987-41.997    C69.355,45.7,60.407,36.751,49.368,36.751z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><circle cx="49.368" cy="17.651" r="17.651" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/></g></g></g> </svg> ' + item.TotalCount + ' </span>  <span style="padding:10px"><svg xmlns="http://www.w3.org/2000/svg" id="Layer_1" height="20px" width="20px" enable-background="new 0 0 512 512" height="512px" viewBox="0 0 512 512" width="512px"><g><g><path d="m41.4 359.02c-5.265 0-10.393-.592-15.337-1.681l8.443 77.773c.826 7.613 7.255 13.381 14.912 13.381h63.162c7.657 0 14.086-5.768 14.912-13.381l8.443-77.773c-4.944 1.09-10.071 1.681-15.337 1.681z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m342.943 405.573-15.5-13.126c-6.322-5.355-15.787-4.567-21.141 1.753-1.952 2.306-3.079 5.03-3.427 7.82h-93.751c-.349-2.79-1.475-5.514-3.427-7.82-5.355-6.322-14.819-7.107-21.141-1.753l-15.5 13.126c-3.366 2.85-5.307 7.037-5.307 11.447s1.94 8.597 5.307 11.447l15.5 13.126c2.818 2.387 6.261 3.554 9.686 3.554 4.258 0 8.488-1.804 11.455-5.307 1.952-2.306 3.079-5.03 3.427-7.82h93.751c.349 2.79 1.475 5.514 3.427 7.82 2.968 3.503 7.197 5.307 11.455 5.307 3.425 0 6.867-1.167 9.686-3.554l15.5-13.126c3.366-2.85 5.307-7.037 5.307-11.447s-1.94-8.596-5.307-11.447z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m146.964 167.571c-15.244 19.759-39.135 32.522-65.964 32.522s-50.72-12.763-65.964-32.522c-9.178 7.637-15.036 19.17-15.036 32.053v87.793c0 22.94 18.572 41.604 41.4 41.604h79.2c22.828 0 41.4-18.663 41.4-41.604v-87.793c0-12.883-5.858-24.416-15.036-32.053z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m81 170.094c29.386 0 53.293-23.907 53.293-53.293s-23.907-53.294-53.293-53.294-53.293 23.908-53.293 53.294c0 29.385 23.907 53.293 53.293 53.293z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m391.4 359.02c-5.265 0-10.393-.592-15.337-1.681l8.443 77.773c.826 7.613 7.255 13.381 14.912 13.381h63.162c7.657 0 14.086-5.768 14.912-13.381l8.443-77.773c-4.944 1.09-10.071 1.681-15.337 1.681z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m496.964 167.571c-15.244 19.759-39.135 32.522-65.964 32.522s-50.72-12.763-65.964-32.522c-9.178 7.637-15.036 19.17-15.036 32.052v87.793c0 22.94 18.572 41.604 41.4 41.604h79.2c22.828 0 41.4-18.663 41.4-41.604v-87.793c0-12.882-5.858-24.415-15.036-32.052z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m431 170.094c29.386 0 53.293-23.907 53.293-53.293s-23.907-53.294-53.293-53.294-53.293 23.908-53.293 53.294c0 29.385 23.907 53.293 53.293 53.293z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/></g></g> </svg>  ' + item.SocilaDistancingCount + ' </span>  </div>',
          pixelOffset: [0, -30],
          fillColor: 'rgba(10,0,0,0.85)'
        })
      });

    }

    else if (item.TotalCount != 0 && (item.SocilaDistancingCount == 0 || item.AlertCount == 0 || item.QuarantineCount == 0)) {

      this.sitemarkers = new atlas.HtmlMarker({
        htmlContent: '<svg xmlns="http://www.w3.org/2000/svg" height="33pt" viewBox="0 0 64 64" width="43pt"><g><path d="m32 39a15 15 0 1 0 -15-15 15.017 15.017 0 0 0 15 15zm-.625-26.781a1 1 0 0 1 1.25 0l10 8a1 1 0 0 1 -.625 1.781h-1v11a1 1 0 0 1 -1 1h-16a1 1 0 0 1 -1-1v-11h-1a1 1 0 0 1 -.625-1.781z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#2b580c"/><path d="m25 21v11h3v-7a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v7h3v-11a1 1 0 0 1 .4-.8l-7.4-5.919-7.4 5.919a1 1 0 0 1 .4.8z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#2b580c"/><path d="m30 26h4v6h-4z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#2b580c"/><path d="m32 59.53c3.667-4.008 20-22.54 20-34.53 0-11.972-8.6-21-20-21s-20 9.028-20 21c0 11.995 16.332 30.521 20 34.53zm0-52.53a17 17 0 1 1 -17 17 17.019 17.019 0 0 1 17-17z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#2b580c"/><path d="m2 60h4v2h-4z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#2b580c"/><path d="m8 60h19v2h-19z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#2b580c"/><path d="m58 60h4v2h-4z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#2b580c"/><path d="m37 60h19v2h-19z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#2b580c"/></g> </svg>',
        color: 'green',
        position: [item.Longitude, item.Latitude],
        popup: new atlas.Popup({
          content: '<div style="color:white">' + '<div style="padding:10px;text-align:center;font-weight:700;margin-bottom:-10px;color:yellow"> ' + item.StoreId + ' </div>' + ' <div style="padding:10px"> <span><svg xmlns="http://www.w3.org/2000/svg" height="15px" width="15px" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" width="512px" height="512px" viewBox="0 0 98.736 98.736" style="enable-background:new 0 0 98.736 98.736;" xml:space="preserve"><g><g> <g><path d="M26.417,56.739c0-5.115,1.688-9.838,4.528-13.656c-2.974-2.673-6.893-4.313-11.205-4.313    c-9.272,0-16.789,7.518-16.789,16.789c0,0,3.95,35.276,16.789,35.276c4.962,0,8.592-5.274,11.184-11.739    c-3.025-9.953-4.248-19.888-4.488-22.026L26.417,56.739z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/> <path d="M19.74,37.554c5.617,0,10.503-3.125,13.02-7.729c-2.513-3.413-4.006-7.619-4.006-12.173c0-2.066,0.313-4.06,0.882-5.943    c-2.625-2.358-6.088-3.808-9.896-3.808c-8.188,0-14.826,6.639-14.826,14.827C4.914,30.915,11.552,37.554,19.74,37.554z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="M78.996,38.77c-4.312,0-8.23,1.64-11.205,4.313c2.842,3.818,4.528,8.541,4.528,13.656l-0.019,0.33    c-0.24,2.14-1.463,12.073-4.488,22.026c2.592,6.465,6.222,11.739,11.184,11.739c12.839,0,16.789-35.276,16.789-35.276    C95.785,46.288,88.268,38.77,78.996,38.77z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="M65.977,29.824c2.517,4.604,7.401,7.729,13.02,7.729c8.188,0,14.826-6.639,14.826-14.826    c0-8.188-6.639-14.827-14.826-14.827c-3.809,0-7.271,1.449-9.896,3.808c0.568,1.884,0.883,3.877,0.883,5.943    C69.982,22.205,68.489,26.411,65.977,29.824z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="M49.368,36.751c-11.039,0-19.988,8.949-19.988,19.988c0,0,4.704,41.997,19.988,41.997s19.987-41.997,19.987-41.997    C69.355,45.7,60.407,36.751,49.368,36.751z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><circle cx="49.368" cy="17.651" r="17.651" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/></g></g></g> </svg> ' + item.TotalCount + ' </span>  <span style="padding:10px"><svg xmlns="http://www.w3.org/2000/svg" id="Layer_1" height="20px" width="20px" enable-background="new 0 0 512 512" height="512px" viewBox="0 0 512 512" width="512px"><g><g><path d="m41.4 359.02c-5.265 0-10.393-.592-15.337-1.681l8.443 77.773c.826 7.613 7.255 13.381 14.912 13.381h63.162c7.657 0 14.086-5.768 14.912-13.381l8.443-77.773c-4.944 1.09-10.071 1.681-15.337 1.681z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m342.943 405.573-15.5-13.126c-6.322-5.355-15.787-4.567-21.141 1.753-1.952 2.306-3.079 5.03-3.427 7.82h-93.751c-.349-2.79-1.475-5.514-3.427-7.82-5.355-6.322-14.819-7.107-21.141-1.753l-15.5 13.126c-3.366 2.85-5.307 7.037-5.307 11.447s1.94 8.597 5.307 11.447l15.5 13.126c2.818 2.387 6.261 3.554 9.686 3.554 4.258 0 8.488-1.804 11.455-5.307 1.952-2.306 3.079-5.03 3.427-7.82h93.751c.349 2.79 1.475 5.514 3.427 7.82 2.968 3.503 7.197 5.307 11.455 5.307 3.425 0 6.867-1.167 9.686-3.554l15.5-13.126c3.366-2.85 5.307-7.037 5.307-11.447s-1.94-8.596-5.307-11.447z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m146.964 167.571c-15.244 19.759-39.135 32.522-65.964 32.522s-50.72-12.763-65.964-32.522c-9.178 7.637-15.036 19.17-15.036 32.053v87.793c0 22.94 18.572 41.604 41.4 41.604h79.2c22.828 0 41.4-18.663 41.4-41.604v-87.793c0-12.883-5.858-24.416-15.036-32.053z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m81 170.094c29.386 0 53.293-23.907 53.293-53.293s-23.907-53.294-53.293-53.294-53.293 23.908-53.293 53.294c0 29.385 23.907 53.293 53.293 53.293z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m391.4 359.02c-5.265 0-10.393-.592-15.337-1.681l8.443 77.773c.826 7.613 7.255 13.381 14.912 13.381h63.162c7.657 0 14.086-5.768 14.912-13.381l8.443-77.773c-4.944 1.09-10.071 1.681-15.337 1.681z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m496.964 167.571c-15.244 19.759-39.135 32.522-65.964 32.522s-50.72-12.763-65.964-32.522c-9.178 7.637-15.036 19.17-15.036 32.052v87.793c0 22.94 18.572 41.604 41.4 41.604h79.2c22.828 0 41.4-18.663 41.4-41.604v-87.793c0-12.882-5.858-24.415-15.036-32.052z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m431 170.094c29.386 0 53.293-23.907 53.293-53.293s-23.907-53.294-53.293-53.294-53.293 23.908-53.293 53.294c0 29.385 23.907 53.293 53.293 53.293z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/></g></g> </svg>  ' + item.SocilaDistancingCount + ' </span>  </div>',
          pixelOffset: [0, -30],
          fillColor: 'rgba(10,0,0,0.85)'
        })
      });

    }

    else {

      this.sitemarkers = new atlas.HtmlMarker({
        htmlContent: '<svg xmlns="http://www.w3.org/2000/svg" height="33pt" viewBox="0 0 64 64" width="43pt"><g><path d="m32 39a15 15 0 1 0 -15-15 15.017 15.017 0 0 0 15 15zm-.625-26.781a1 1 0 0 1 1.25 0l10 8a1 1 0 0 1 -.625 1.781h-1v11a1 1 0 0 1 -1 1h-16a1 1 0 0 1 -1-1v-11h-1a1 1 0 0 1 -.625-1.781z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#363636"/><path d="m25 21v11h3v-7a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v7h3v-11a1 1 0 0 1 .4-.8l-7.4-5.919-7.4 5.919a1 1 0 0 1 .4.8z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#363636"/><path d="m30 26h4v6h-4z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#363636"/><path d="m32 59.53c3.667-4.008 20-22.54 20-34.53 0-11.972-8.6-21-20-21s-20 9.028-20 21c0 11.995 16.332 30.521 20 34.53zm0-52.53a17 17 0 1 1 -17 17 17.019 17.019 0 0 1 17-17z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#363636"/><path d="m2 60h4v2h-4z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#363636"/><path d="m8 60h19v2h-19z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#363636"/><path d="m58 60h4v2h-4z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#363636"/><path d="m37 60h19v2h-19z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#363636"/></g> </svg>',
        color: 'grey',
        position: [item.Longitude, item.Latitude],
        popup: new atlas.Popup({
          content: '<div style="color:white">' + '<div style="padding:10px;text-align:center;font-weight:700;margin-bottom:-10px;color:yellow"> ' + item.StoreId + ' </div>' + ' <div style="padding:10px"> <span><svg xmlns="http://www.w3.org/2000/svg" height="15px" width="15px" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" width="512px" height="512px" viewBox="0 0 98.736 98.736" style="enable-background:new 0 0 98.736 98.736;" xml:space="preserve"><g><g> <g><path d="M26.417,56.739c0-5.115,1.688-9.838,4.528-13.656c-2.974-2.673-6.893-4.313-11.205-4.313    c-9.272,0-16.789,7.518-16.789,16.789c0,0,3.95,35.276,16.789,35.276c4.962,0,8.592-5.274,11.184-11.739    c-3.025-9.953-4.248-19.888-4.488-22.026L26.417,56.739z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/> <path d="M19.74,37.554c5.617,0,10.503-3.125,13.02-7.729c-2.513-3.413-4.006-7.619-4.006-12.173c0-2.066,0.313-4.06,0.882-5.943    c-2.625-2.358-6.088-3.808-9.896-3.808c-8.188,0-14.826,6.639-14.826,14.827C4.914,30.915,11.552,37.554,19.74,37.554z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="M78.996,38.77c-4.312,0-8.23,1.64-11.205,4.313c2.842,3.818,4.528,8.541,4.528,13.656l-0.019,0.33    c-0.24,2.14-1.463,12.073-4.488,22.026c2.592,6.465,6.222,11.739,11.184,11.739c12.839,0,16.789-35.276,16.789-35.276    C95.785,46.288,88.268,38.77,78.996,38.77z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="M65.977,29.824c2.517,4.604,7.401,7.729,13.02,7.729c8.188,0,14.826-6.639,14.826-14.826    c0-8.188-6.639-14.827-14.826-14.827c-3.809,0-7.271,1.449-9.896,3.808c0.568,1.884,0.883,3.877,0.883,5.943    C69.982,22.205,68.489,26.411,65.977,29.824z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="M49.368,36.751c-11.039,0-19.988,8.949-19.988,19.988c0,0,4.704,41.997,19.988,41.997s19.987-41.997,19.987-41.997    C69.355,45.7,60.407,36.751,49.368,36.751z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><circle cx="49.368" cy="17.651" r="17.651" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/></g></g></g> </svg> ' + item.TotalCount + ' </span>  <span style="padding:10px"><svg xmlns="http://www.w3.org/2000/svg" id="Layer_1" height="20px" width="20px" enable-background="new 0 0 512 512" height="512px" viewBox="0 0 512 512" width="512px"><g><g><path d="m41.4 359.02c-5.265 0-10.393-.592-15.337-1.681l8.443 77.773c.826 7.613 7.255 13.381 14.912 13.381h63.162c7.657 0 14.086-5.768 14.912-13.381l8.443-77.773c-4.944 1.09-10.071 1.681-15.337 1.681z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m342.943 405.573-15.5-13.126c-6.322-5.355-15.787-4.567-21.141 1.753-1.952 2.306-3.079 5.03-3.427 7.82h-93.751c-.349-2.79-1.475-5.514-3.427-7.82-5.355-6.322-14.819-7.107-21.141-1.753l-15.5 13.126c-3.366 2.85-5.307 7.037-5.307 11.447s1.94 8.597 5.307 11.447l15.5 13.126c2.818 2.387 6.261 3.554 9.686 3.554 4.258 0 8.488-1.804 11.455-5.307 1.952-2.306 3.079-5.03 3.427-7.82h93.751c.349 2.79 1.475 5.514 3.427 7.82 2.968 3.503 7.197 5.307 11.455 5.307 3.425 0 6.867-1.167 9.686-3.554l15.5-13.126c3.366-2.85 5.307-7.037 5.307-11.447s-1.94-8.596-5.307-11.447z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m146.964 167.571c-15.244 19.759-39.135 32.522-65.964 32.522s-50.72-12.763-65.964-32.522c-9.178 7.637-15.036 19.17-15.036 32.053v87.793c0 22.94 18.572 41.604 41.4 41.604h79.2c22.828 0 41.4-18.663 41.4-41.604v-87.793c0-12.883-5.858-24.416-15.036-32.053z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m81 170.094c29.386 0 53.293-23.907 53.293-53.293s-23.907-53.294-53.293-53.294-53.293 23.908-53.293 53.294c0 29.385 23.907 53.293 53.293 53.293z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m391.4 359.02c-5.265 0-10.393-.592-15.337-1.681l8.443 77.773c.826 7.613 7.255 13.381 14.912 13.381h63.162c7.657 0 14.086-5.768 14.912-13.381l8.443-77.773c-4.944 1.09-10.071 1.681-15.337 1.681z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m496.964 167.571c-15.244 19.759-39.135 32.522-65.964 32.522s-50.72-12.763-65.964-32.522c-9.178 7.637-15.036 19.17-15.036 32.052v87.793c0 22.94 18.572 41.604 41.4 41.604h79.2c22.828 0 41.4-18.663 41.4-41.604v-87.793c0-12.882-5.858-24.415-15.036-32.052z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/><path d="m431 170.094c29.386 0 53.293-23.907 53.293-53.293s-23.907-53.294-53.293-53.294-53.293 23.908-53.293 53.294c0 29.385 23.907 53.293 53.293 53.293z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"/></g></g> </svg>  ' + item.SocilaDistancingCount + ' </span>  </div>',
          pixelOffset: [0, -30],
          fillColor: 'rgba(10,0,0,0.85)'
        })
      });

    }


    this.map.setCamera({
      center: [parseFloat(item.Longitude), parseFloat(item.Latitude)],
      zoom: 10
    });
    // this.markers = [];
    this.map.markers.add([this.sitemarkers]);
    this.markers.push(this.sitemarkers);

    // this.map.markers.add([this.sitemarkers]);
    for (let marker of this.markers) {

      this.map.events.add('click', marker, () => {
        // console.log("clciked");
        marker.togglePopup();
      });

    }

    // // console.log("markers", this.map.markers);


    // this.map.events.add("ready", () => {
    //   this.map.events.add('click', this.sitemarkers, e => {
    //     this.employeeMarkers();
    //   })
    // });

  }

  generateToken() {
    // console.log("HELLLLO")
    this.app.generateToken({ "EmployeeKey": sessionStorage.getItem("email") }).subscribe(response => {
      this.GenerateTokenResponse = response;
      localStorage.setItem('Token', this.GenerateTokenResponse.Token)
    })
  }

  employeeMarkers() {


    // this.marker = new atlas.HtmlMarker({
    //   htmlContent: '<i class="fa fa-map-pin fa-2x" style="color:purple" aria-hidden="true"></i>',
    //   color: 'blue',
    //   position: [77.6583, 12.8379]
    // });
    // console.log("marker", this.marker);

    this.map.markers.add(this.marker);

    // console.log("markers", this.map.markers);



    this.map.events.add('click', this.marker, function (e) {
      // // console.log(this.showInfo);
      //this.show=1;
      //this.showInfo = true;
      document.getElementById('check').style.display = 'block';

    });
    // console.log(this.showInfo);
  }

  getStoreCount(store) {
    // alert(JSON.stringify(store));
    this.selectedStore = store.StoreId;
    this.paramSiteId = store.Sid;
    sessionStorage.setItem('store', JSON.stringify(store));
    this.SDAlertCount = store.SocilaDistancingCount;
    this.TotalPeople = store.TotalCount;
    this.SDA_Alert_15minsCount = store.SocialDistanceDurationReport;
    // this.QuarantinePeopleCount = store.QuarantineCount;
    // this.AssociateAlertCount = store.AlertCount
    sessionStorage.setItem('SDA_Counts', this.SDAlertCount.toString());
    // sessionStorage.setItem('QuarantineCount', this.QuarantinePeopleCount.toString())
    // sessionStorage.setItem('TempAlertCount', this.AssociateAlertCount.toString())
  }

  sortInDescending() {
    this.SDA15minList.sort((a, b) => b.Duration - a.Duration)
  }
  sortInAscending() {
    this.SDA15minList.sort((a, b) => a.Duration - b.Duration)
  }

  sortInDescendingNorm() {
    this.SDA15minListNorm.sort((a, b) => b.Duration - a.Duration)
  }
  sortInAscendingNorm() {
    this.SDA15minListNorm.sort((a, b) => a.Duration - b.Duration)
  }



  sortInDescendingCBT() {
    this.associateAlertList.sort((a, b) => b.Duration - a.Duration)
  }
  sortInAscendingCBT() {
    this.associateAlertList.sort((a, b) => a.Duration - b.Duration)
  }
}

