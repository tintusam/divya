import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TrackerLandingPageComponent } from './tracker-landing-page.component';

describe('TrackerLandingPageComponent', () => {
  let component: TrackerLandingPageComponent;
  let fixture: ComponentFixture<TrackerLandingPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TrackerLandingPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrackerLandingPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
