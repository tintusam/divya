import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AssetComponent } from './asset/asset.component';
import { AlertsComponent } from './alerts/alerts.component';
import { ReportsComponent } from './reports/reports.component';
import { SettingsComponent } from './settings/settings.component';
import { SmartViewComponent } from './smart-view/smart-view.component';
import {DashboardRoutingModule} from './dashboard-routing.module'
import { DashboardSidebarComponent } from './dashboard-sidebar/dashboard-sidebar.component';
import { AgmCoreModule } from '@agm/core';
import { ServiceSidebarComponent } from './smart-view/service-sidebar/service-sidebar.component';
import {DynamicfieldPipe} from './../pipes/dynamicfield.pipe';
import { FormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    DashboardRoutingModule,
    FormsModule,
    AgmCoreModule.forRoot({
      // please get your own API key here:
      // https://developers.google.com/maps/documentation/javascript/get-api-key?hl=en
      apiKey: 'AIzaSyDEfHy3Ll9NYVO5Rd8Vu6NU1X5kGd_qN5I'
    })  
  ],
  declarations: [AssetComponent, AlertsComponent, DynamicfieldPipe, ReportsComponent, SettingsComponent, SmartViewComponent, DashboardSidebarComponent, ServiceSidebarComponent],
  exports:[SmartViewComponent, DynamicfieldPipe]
})
export class DashboardModule { }
