import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QrCodeLandingPageComponent } from './qr-code-landing-page.component';

describe('QrCodeLandingPageComponent', () => {
  let component: QrCodeLandingPageComponent;
  let fixture: ComponentFixture<QrCodeLandingPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QrCodeLandingPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QrCodeLandingPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
