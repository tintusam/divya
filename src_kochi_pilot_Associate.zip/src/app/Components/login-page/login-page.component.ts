import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from '../../Service/app.service'

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.scss']
})
export class LoginPageComponent implements OnInit {
  SelectLocation = 'Select Location';
  showLoader = true;
  showDropDown = false;
  EmployeeId: number;
  locationList: any;
  model:any ={};
  EncodedQRCodeEmployeeKey = "";
  TempArray: any;

  constructor(private router: Router, private app: AppService) {
    this.locationList = [];
    sessionStorage.clear()

  }

  ngOnInit() {
    // this.app.GetAllLocation().subscribe(res => {
    //   // console.log(res);
    //   this.locationList = res;
    //   this.showDropDown = true;
    this.showLoader = false;
    // })


  }

  // selectLocation(location) {
  //   this.SelectLocation = location.storeId
  // }

  login() {
    //console.log(this.model.EmployeeId);
    this.EmployeeId = parseInt(this.model.EmployeeId);
    if (this.EmployeeId === 0) {
      alert('Please Provide Employee ID to login. ')
    } else {
      this.EmployeeId = this.EmployeeId * 7 + 9;
      this.TempArray = (this.EmployeeId.toString()).split("");
      this.TempArray.unshift("XY");
      this.TempArray.push("PQ")
      // console.log(this.TempArray)

      for (let item of this.TempArray) {
        this.EncodedQRCodeEmployeeKey += item

      }
    }
    sessionStorage.setItem('EmployeeId', this.EncodedQRCodeEmployeeKey);
    sessionStorage.setItem('storeId', "Kochi"); // hardcoded for kochi location only.

    this.router.navigate(['action-center'])
  }


}
