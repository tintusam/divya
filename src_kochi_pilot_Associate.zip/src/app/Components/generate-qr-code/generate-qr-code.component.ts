import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AppService } from '../../Service/app.service';
@Component({
  selector: 'app-generate-qr-code',
  templateUrl: './generate-qr-code.component.html',
  styleUrls: ['./generate-qr-code.component.scss']
})
export class GenerateQRCodeComponent implements OnInit {

  Location: string;
  EmployeeId: string;
  showFirstNext = true;
  showSecondNext = false;
  showThirdNext = false;
  showFourthNext = false;
  ResponseObject: any;
  showResponse = false;
  showBarcode = false;
  Q1Answer: string;
  Q2Answer: string;
  Q3Answer: string;
  Q4Answer: string;
  Q5Answer: string;
  Q6Answer: string;
  Q7Answer: string;
  Q8Answer: string;
  Q9Answer: string;
  Q10Answer: string;
  Q11Answer: string;
  constructor(private app: AppService) { }

  ngOnInit() {
    this.showResponse = false;
    this.showBarcode = false;
    this.EmployeeId = sessionStorage.getItem('EmployeeId');
    this.Location = sessionStorage.getItem('storeId')
    this.Q1Answer = '';
    this.Q2Answer = '';
    this.Q3Answer = '';
    this.Q4Answer = '';
    this.Q5Answer = '';
    this.Q6Answer = '';
    this.Q7Answer = '';
    this.Q8Answer = '';
    this.Q9Answer = '';
    this.Q10Answer = '';
    this.Q11Answer = '';
  }

  showSecondNextButton() {
    if (this.Q1Answer === '' || this.Q2Answer === '' || this.Q3Answer === '') {
      alert('Please Answer All the Questions')
    } else {
      this.showFirstNext = false;
      this.showSecondNext = true;
      this.showThirdNext = false;
      this.showFourthNext = false
    }

  }

  showThirdNextButton() {
    if (this.Q4Answer === '' || this.Q5Answer === '' || this.Q6Answer === '') {
      alert('Please Answer All the Questions')
    } else {
      this.showFirstNext = false;
      this.showSecondNext = false;
      this.showThirdNext = true;
      this.showFourthNext = false
    }
  }

  showFourthNextButton() {
    if (this.Q7Answer === '' || this.Q8Answer === '' || this.Q9Answer === '') {
      alert('Please Answer All the Questions')
    } else {
      this.showFirstNext = false;
      this.showSecondNext = false;
      this.showThirdNext = false;
      this.showFourthNext = true;
    }
  }

  SubmitEmployeeQA() {
    //alert('inside submit');
    //console.log(payload)
    if (this.Q10Answer === '') {
      alert('Please Answer the above question')
      // || this.Q3Answer === 'I have not downloaded the Aarogya Setu app'
    } else if (this.Q1Answer === 'I have not volunteered to come to office' || this.Q2Answer === 'I have one of these symptoms - Fever, Dry cough, Body Ache, Headaches, Sore throat, Runny Nose, Tiredness, and Shortness of Breath' || this.Q4Answer === 'Yes' || this.Q5Answer === 'Yes' || this.Q6Answer === 'Deny' || this.Q7Answer === 'Deny' || (this.Q8Answer === 'Yes' && this.Q11Answer == 'No') || this.Q9Answer === 'I do not accept the guidelines & policies mentioned above' || this.Q10Answer === 'Decline' || this.Q11Answer === 'No') {
      this.showResponse = true;
      this.showBarcode = false;
    } else {
      let payload = {

        "Location": this.Location,

        "EmployeeId": this.EmployeeId,

        "Questions": [{

          "Question": "Q1",

          "Answer": this.Q1Answer

        }, {

          "Question": "Q2",

          "Answer": this.Q2Answer

        }, {

          "Question": "Q3",

          "Answer": this.Q3Answer

        }, {

          "Question": "Q4",

          "Answer": this.Q4Answer

        }, {

          "Question": "Q5",

          "Answer": this.Q5Answer

        }, {

          "Question": "Q6",

          "Answer": this.Q6Answer

        }, {

          "Question": "Q7",

          "Answer": this.Q7Answer

        }, {

          "Question": "Q8",

          "Answer": this.Q8Answer

        }, {

          "Question": "Q9",

          "Answer": this.Q9Answer

        }, {

          "Question": "Q10",

          "Answer": this.Q10Answer

        },
        {

          "Question": "Q11",

          "Answer": this.Q11Answer

        }
        ]
      }

       
      // console.log(this.Q11Answer)
      this.app.postQuestionaireResponse(payload).subscribe(res => {
        // console.log(res);
        this.ResponseObject = res
        if (this.ResponseObject.Message === 'Not Approved') {
          this.showResponse = true;
        } else {
          this.showBarcode = true;
        }
      })
    }
  }
}
