import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginPageComponent } from './Components/login-page/login-page.component';
import { LandingPageComponent } from './Components/landing-page/landing-page.component';
import { ViewQRCodeComponent } from './Components/view-qr-code/view-qr-code.component';
import { GenerateQRCodeComponent } from './Components/generate-qr-code/generate-qr-code.component'
import { QrCodeLandingPageComponent } from './Components/qr-code-landing-page/qr-code-landing-page.component'
import { QrCodeActionCenterComponent } from './Components/qr-code-action-center/qr-code-action-center.component';
import { ErrorMsgComponent } from './Components/error-msg/error-msg.component';
const routes: Routes = [
  {
    path: 'landing-page',
    component: LandingPageComponent
  },
  {
    path: 'login',
    component: LoginPageComponent
  },
  {
    path: 'action-center',
    component: QrCodeLandingPageComponent,
    children: [

      {
        path: '',
        component: QrCodeActionCenterComponent
      },
      {
        path: 'view-QR-code',
        component: ViewQRCodeComponent
      },
      {
        path: 'generate-QR-code',
        component: GenerateQRCodeComponent
      },
      {
        path: 'error',
        component: ErrorMsgComponent
      }      
    ]
  },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
