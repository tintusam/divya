import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
const ApiUrl = "https://co-trackwebapi.azurewebsites.net/api/";

@Injectable({
  providedIn: 'root'
})
export class AppService {

  constructor(private http: HttpClient) { }

  GetAllLocation() {
    return this.http.get(ApiUrl + 'GetAllLocation')
  }

  validateEmployeeId(payload) {
    return this.http.post(ApiUrl + 'ValidateEmployeeId', payload);
  }
  postQuestionaireResponse(Payload) {
    console.log(Payload);
    // https://co-track-wfo-function.azurewebsites.net/api/EmployeeQA
    return this.http.post(ApiUrl + 'EmployeeQA', Payload);
  }

  getQRCodeValidity(Payload) {
    return this.http.post(ApiUrl + 'GetEmpQrCodeValidity', Payload);
  }
}
