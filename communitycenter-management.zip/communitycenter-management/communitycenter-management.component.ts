import { Component, OnInit, Output, EventEmitter, AfterViewInit, ElementRef, ViewChild} from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { environment } from '../../../../environments/environment.prod';
import { CommunityCentreManagementService } from '../../../services/admin-portal/community-centre-management.service';
import { from, Observable } from 'rxjs';
import { combineAll, map } from 'rxjs/operators';
import { ISasToken } from '../../../../assets/azure-storage/azureStorage';
import { BlobStorageService } from '../../../../assets/azure-storage/blob-storage.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import Swal from 'sweetalert2';
interface IUploadProgress {
  filename: string;
  progress: number;
};
declare var jQuery: any;

@Component({
  selector: 'app-communitycenter-management',
  templateUrl: './communitycenter-management.component.html',
  styleUrls: ['./communitycenter-management.component.scss']
})
export class CommunitycenterManagementComponent implements OnInit {


  public editFacilityName:boolean = false;
  public editWard:boolean = false;
  public wardMapResponse:any = {};
  public zoneInfo:any = {};
  public imageRefUrl:any;
  public zones = [];
  public pos = [];
  public zoneInfoResponse:any = {};
  public showPopup:boolean = false;
  public ZoneForm: FormGroup;
  public posx;
  public posy;
  public GatewayList: any;
  public AddZoneForm:FormGroup;
  public addZoneNew:FormGroup;
  public showZoneInfo:boolean = false;
  public addFacility:boolean = false;
  public allowPlaceMarker:boolean = false;
  public addWard:boolean = false;
  public addFaciltyModel:any = {};
  public addWardModel:any = {};
  public addZoneModel:any = {};
  public isLoaded:boolean = true;
  public isLoadedRightSide:boolean = true;
  public listFacilityResponse:any;
  public wardsList:any;
  public hasWardList:boolean = false;
  public facilityID:any;
  public wardID:any;
  public wardInfoResponse:any;
  public deviceType:string = "gatewayrouter"; // default value
  public serialNumber:string;
  public unMappedDeviceList:any;
  public mappingList:any = {};
  public query:any = '';
  public queryWard:any = '';

  public selectedFile: String;
  public showUploadForm: boolean = true;
  public showLoader: boolean = false;
  public showUploadComplete: boolean = false;
  public filesSelected: boolean = false;
  public showButton: boolean = false;
  public showInvalidFileExtensionMsg: boolean = false;
  @Output() onExit = new EventEmitter<any>();
  uploadProgress$: Observable<IUploadProgress[]>;
  public fileUploadSuccess: boolean = false;
  public uploadFileName: string;
  public storageUrl = '';
  public fullName: string;
  public currentFile: any;
  public deviceMappingResponse:any;
  public unMappingResponse : any;
  public selectedFacility:any;
  public SelectedDeviceType:string = "gateway";
  public singleRouterData:any;
  public routerList = [];
  public nonRouterData:any;
  public nonRouterList = [];
  public rightSideBarCountResponse:any;
  public deleteWard:number;
  public deleteWardResponse:any;

  constructor(private fb: FormBuilder, private el: ElementRef, private _router:Router,private _communityService:CommunityCentreManagementService, private blobStorage: BlobStorageService) { 
    this.ZoneForm = this.fb.group({
      zoneName: [null, Validators.required],
      Threshold: [null, Validators.required],
      bleGatewaySno: [null, Validators.required]
    });
    this.AddZoneForm = this.fb.group({
    });

    this.addZoneNew = this.fb.group({
    });
   }
  

  ngOnInit(): void {
    this.onListAllFacilities();
    this.facilityID = JSON.parse(sessionStorage.getItem('facilityID'));
    if(this.facilityID){
      this.getFacilityWards(this.facilityID);
    }
    this.onShowRightSideBarCount();
  }

// Method to get file details before pushing it to blob
onFileChange(event: any): void {
  this.showLoader = true;
  this.showUploadComplete = false;
  this.filesSelected = true;
  this.showButton = true;
  this.currentFile = event.target.files;
  this.onUploadImageToBlob();
}

// Method to upload the selected file to blob
onUploadImageToBlob() {
  this.uploadProgress$ = from(this.currentFile as FileList).pipe(
    map(file => this.uploadFile(file)), // Getting File Details Here
      combineAll()
  );
}

// observable for uploading the image file
uploadFile(file: File): Observable<IUploadProgress> {
  if (!(file.type.match('image.*'))) {
        Swal.fire({
        position: 'top-end',
        icon: 'error',
        text: 'Please Choose a valid image file!',
        showConfirmButton: true,
        confirmButtonColor:'#cd0000'
      // timer: 1500
    })
    this.showLoader = false;
    this.showInvalidFileExtensionMsg = true;
  } else {
    //console.log(file);
    this.uploadFileName = file.name;
    this.storageUrl = environment.blobAccessUrl + this.uploadFileName + environment.SAS_Token
    const accessToken: ISasToken = {
      container: 'imagestorage', // container with same name should be created in blob storage account
      filename: file.name,
      storageAccessToken: environment.SAS_Token,
      storageUri: environment.storageLink + environment.SAS_Token,
    };
    return this.blobStorage
      .uploadToBlobStorage(accessToken, file)
      .pipe(map(progress => this.mapProgress(file, progress)));
  }
}

private mapProgress(file: File, progress: number): IUploadProgress {
  if (progress === 100) {
    this.showLoader = false;
    this.showUploadComplete = true;
    this.fileUploadSuccess = true;
    this.filesSelected = false;
    this.imageRefUrl = environment.blobAccessUrl + this.uploadFileName;
    console.log(this.imageRefUrl);
    // Swal.fire({
    //   position: 'top-end',
    //   icon: 'success',
    //   text: 'Uploaded Successfully!',
    //   showConfirmButton: false,
    //   timer: 2000
    // }) 
  }
  return {
    filename: file.name,
    progress: progress
  };
}

// Method to get location point 
onGetLocationPoints(e) {
  if(this.allowPlaceMarker){
    this.showPopup = true;
    this.ZoneForm.reset();
    if (this.imageRefUrl) {
      this.listSerialNumbers();
      var svg = this.el.nativeElement.querySelector('#mySvg');
      var pt = svg.createSVGPoint();
      pt.x = e.clientX; //x position within the element.
      pt.y = e.clientY;
      var svgP = pt.matrixTransform(svg.getScreenCTM().inverse());
      this.posx = svgP.x;
      this.posy = svgP.y;
      //console.log(this.posx, this.posy)
    }
  }else{
    Swal.fire({
      icon:'info',
      html:
      'Select Marker before pointing!',
      showCloseButton:true,
      // focusConfirm: false,
      confirmButtonText: '<i class="fa fa-thumbs-up"></i>OK!'
     // timer: 1500
    })
    // Swal.fire({
    //   position: 'top-end',
    //   icon: 'error',
    //   text: 'Select Marker before pointing!',
    //   showConfirmButton: true,
    //   confirmButtonColor:'#cd0000'
    //  // timer: 1500
    // })
  }

}

// method to list serial number based on sensors and gateways on add zone form
listSerialNumbers(){
  console.log(this.deviceType);
  if(this.deviceType == 'gatewayrouter'){
    this.SelectedDeviceType = 'gateway';
  }else{
    this.SelectedDeviceType = 'sensor';
  }
  let payload = {
    "Type":this.SelectedDeviceType
  };
  // this._facilityService.getUnMappedDevices(payload).subscribe(
  //   res =>{
  //     this.unMappedDeviceList = res;
  //     if(this.unMappedDeviceList){
  //       this.serialNumber = this.unMappedDeviceList[0]['SerialNumber']+'-'+this.unMappedDeviceList[0]['Id'];
  //     }
  //   },
  //   err => {
  //     console.log(err);
  //   }
  // )   
}

selectSerialNumber(e){
  this.serialNumber = e.target.value;
}

selectDeviceType(e){
  this.deviceType = e.target.value; 
}

onSaveZones(form:NgForm) {
  var sensorSerialInfo = this.serialNumber.split("*");
  console.log(sensorSerialInfo);
  if(this.serialNumber && this.deviceType){
    let payload={
      'SerialNumber':sensorSerialInfo[0],
      'ID':sensorSerialInfo[1],
      'Facid':JSON.parse(sessionStorage.getItem("facilityID")),
      'Wrdid':JSON.parse(sessionStorage.getItem("wardID")),
      'Name':this.addZoneModel.zoneName,
      'ObjectType':this.deviceType,
      'Left':this.posx,
      'Top':this.posy
    }
    // this._facilityService.deviceMappingInsideWard(payload).subscribe(
    //   res => {
    //     this.deviceMappingResponse = res;
    //     this.onGetSelectedWardInfo(JSON.parse(sessionStorage.getItem("wardID")));
    //     Swal.fire({
    //       position: 'top-end',
    //       icon: 'success',
    //       text: 'Device added successfully!',
    //       showConfirmButton: false,
    //       timer: 2000
    //     })
    //   },
    //   err => {
    //     console.log(err);
    //     Swal.fire({
    //       position: 'top-end',
    //       icon: 'error',
    //       text: 'Failed to add the zone!',
    //       showConfirmButton: true,
    //       confirmButtonColor:'#cd0000'
    //      // timer: 1500
    //     })
    //   }
    // )
  }
 }

 //Method to remove Mapping of device from Ward
 onRemoveMapping(zoneToRemove){
   console.log(zoneToRemove);
   let payload = {
     'SerialNumber' : zoneToRemove.SerialNumber,
     //'ID' : zoneToRemove.,
     'Facid':JSON.parse(sessionStorage.getItem("facilityID")),
     'Wrdid':JSON.parse(sessionStorage.getItem("wardID")),
      'Name': zoneToRemove.Name,
      'ObjectType':zoneToRemove.ObjectType,
      'Left':zoneToRemove.Left,
      //'Top': '',
      'WardObjid':zoneToRemove.WrdObjid
   }
  //  this._facilityService.deviceUnmappingFromWard(payload).subscribe(
  //    res => {
  //      this.unMappingResponse = res;
  //      this.onGetSelectedWardInfo(this.wardsList[0]['Wrdid']);
  //      console.log(this.unMappingResponse);
  //      Swal.fire({
  //       title: 'Mapping Removed',
  //       showClass: {
  //         popup: 'animate__animated animate__fadeInDown'
  //       },
  //       hideClass: {
  //         popup: 'animate__animated animate__fadeOutUp'
  //       }
  //     })

  //    },
  //    err => {
  //      console.log(err);
  //    }
  //  )
 }


onSaveSensor(){
//alert('Saved Successfully!');
this.showZoneInfo = false;
this.showPopup = false;
}

// Method to show zone info on custom modal on clicking a particular zone
onGetZoneInfo(zone, i) {
console.log(zone);
this.showZoneInfo = true;
this.zoneInfo = {
  "zoneName": zone.Name,
  "facilityName": zone.FacilityName,
  "SerialNumber": zone.SerialNumber,
  "type":zone.ObjectType,
  "wardId":sessionStorage.getItem('wardID'),
  "WrdObjid":zone.WrdObjid,
  "Name": zone.Name
}
console.log(this.zoneInfo);
}

cancelAddFacility(){
this.addFacility = false;
}

onAddNewWard(){
this.addFacility = false;
this.addWard = true;
}

// Method to add a new ward under facility
onCreateNewWard(form:NgForm){
//alert('inside ward creation');
this.addWard = true;
this.addFacility = false;
console.log(this.imageRefUrl);
let payload = {
  "WardName":this.addWardModel.wardname,
  "URL":this.imageRefUrl,
  "Facid":JSON.parse(sessionStorage.getItem('facilityID'))
}
// this._facilityService.createWard(payload)
// .subscribe(
// (response: any) => {
//   console.log(response);
//   form.reset();
//   //this.clearFacilityData();
//   this.getFacilityWards(JSON.parse(sessionStorage.getItem('facilityID')));
//   this.addWard = false;
//   Swal.fire({
//     position: 'top-end',
//     icon: 'success',
//     text: 'Ward Added Successfully!',
//     showConfirmButton: false,
//     timer: 2000
//   })
// },
// (error) => {
//   form.reset();
//   Swal.fire({
//     position: 'top-end',
//     icon: 'error',
//     text: 'Failed to Add!',
//     showConfirmButton: true,
//     confirmButtonColor:'#cd0000'
//    // timer: 1500
//   })
  
// }); 
}

onCancelAddNewWard(){
this.addWard = false;
this.addFacility = false;
}

// Method to list all facilities
onListAllFacilities(){
this.isLoaded = false;
// this._facilityService.listFacilities().subscribe(
//   res => {
//     this.listFacilityResponse = res;
//     this.selectedFacility = res[0];
//     if(this.listFacilityResponse){
//       sessionStorage.setItem('facilityID',this.listFacilityResponse[0].Facid);
//     }
//     this.isLoaded = true;
//   },
//   err => {
//     console.log(err);
//     this.isLoaded = true;
//   }
// )
}

// Method to create a new Facility
onCreateNewFacility(form:NgForm){
this.addWard = false;
let payload = {
    "FacilityName":this.addFaciltyModel.facilityName,
    "Address":""
}
// this._facilityService.createFacility(payload)
// .subscribe(
//   (response: any) => {
//     form.reset();
//     this.clearFacilityData();
//     this.onListAllFacilities();
//     Swal.fire({
//       position: 'top-end',
//       icon: 'success',
//       text: 'Facility Added Successfully!',
//       showConfirmButton: false,
//       timer: 2000
//     })
//   },
//   (error) => {
//     form.reset();
//     Swal.fire({
//       position: 'top-end',
//       icon: 'error',
//       text: 'Failed to Add!',
//       showConfirmButton: true,
//       confirmButtonColor:'#cd0000'
//     })
    
//   }); 
}

// Method to clear facility data entered on form
clearFacilityData(){
this.addFacility = false;
this.addWard = false;
this.addFaciltyModel = {};
}


//Method to get data inside selected ward
onGetSelectedWardInfo(wardID){
this.isLoadedRightSide = false;
sessionStorage.setItem('wardID',wardID);
this.showZoneInfo = false
this.wardID = wardID;
let payload = {
  "Wrdid" : wardID
}
// this._facilityService.getParticularWard(payload).subscribe(
//   res => {
//     this.wardInfoResponse = res[0];
//     this.isLoadedRightSide = true;
//     if(this.wardInfoResponse){
//       this.mappingList = this.wardInfoResponse.MppingList;
//       this.routerList = [];
//       this.nonRouterList = [];
//       for (var i = 0; i < this.wardInfoResponse.MppingList.length; i++){
//         if(this.mappingList[i]["ObjectType"]=='gatewayrouter'){
//           this.singleRouterData = {
//             "ObjectType": this.mappingList[i]["ObjectType"],
//             "FacilityName": this.mappingList[i]["FacilityName"],
//             "Left":this.mappingList[i]["Left"],
//             "Name":this.mappingList[i]["Name"],
//             "SerialNumber":this.mappingList[i]["SerialNumber"],
//             "Top":this.mappingList[i]["Top"],
//             "WrdObjid":this.mappingList[i]["WrdObjid"]
//           }
//           this.routerList.push(this.singleRouterData);
//         }else{
//           this.nonRouterData = {
//             "ObjectType": this.mappingList[i]["ObjectType"],
//             "FacilityName": this.mappingList[i]["FacilityName"],
//             "Left":this.mappingList[i]["Left"],
//             "Name":this.mappingList[i]["Name"],
//             "SerialNumber":this.mappingList[i]["SerialNumber"],
//             "Top":this.mappingList[i]["Top"],
//             "WrdObjid":this.mappingList[i]["WrdObjid"]
//           }
//           this.nonRouterList.push(this.nonRouterData);
//         }
//       }
//       console.log(this.routerList);
//       // console.log(this.nonRouterList);
//       // console.log(this.mappingList);
//     }   
//     this.imageRefUrl = this.wardInfoResponse.URL;
//   },
  
//   err => {
//     console.log(err);
//     this.isLoadedRightSide = true;
//   }
// )
}

//Method to get all wards listed under a facility
getFacilityWards(facilityID){
let payload = {
  "Facid":JSON.parse(facilityID)
}
// this._facilityService.listAllWards(payload)
// .subscribe(
//   res => {
//     this.wardsList = res;
//     if(this.wardsList.length == 0){
//       this.hasWardList = false;
//     }else{
//       this.hasWardList = true;
//       // to load first ward data
//       this.wardID = this.wardsList[0]['Wrdid'];
//       //console.log(this.wardID);
//       sessionStorage.setItem('wardID',this.wardsList[0]['Wrdid']);
//       this.onGetSelectedWardInfo(this.wardsList[0]['Wrdid'])
//     }
//     //console.log(res);
//   },
//   err => {
//     console.log(err);
//   }
// )
}

// Method to show particular facility info while clicking on sidebar
onShowFacilityInfo(facilityID){
//alert('clicked');
this.showZoneInfo = false
this.clearFacilityData();
this.facilityID = facilityID;
sessionStorage.setItem('facilityID',this.facilityID),
this.getFacilityWards(facilityID);
}

//Method to get the ride side bar count

onShowRightSideBarCount(){
let payload ={
"Wrdid" : JSON.parse(sessionStorage.getItem("wardID"))
}
// this._facilityService.getRightSideBarCount(payload).subscribe(
// res => {
//   this.rightSideBarCountResponse = res;
// },
// err => {
//   console.log(err);
// }
// )
}


//Method to select ward to delete

onDeleteWard(wardtoDelete){
this.deleteWard = wardtoDelete;
}

//Method to delete Ward
onDeleteWardConfirm(){
let payload = {
  'Wrdid': this.deleteWard
}
// console.log(payload);
// this._communityService.deleteWard(payload).subscribe(
//  res => {
//    this.deleteWardResponse = res;
//    Swal.fire({
//     position: 'top-end',
//     icon: 'success',
//     text: 'Deleted Successfully!',
//     showConfirmButton: false,
//     timer: 2000
//   })
//  },
//  err => {
//    console.log(err);
//    Swal.fire({
//     position: 'top-end',
//     icon: 'error',
//     text: err.error.Message,
//     showConfirmButton: true,
//     confirmButtonColor:'#cd0000'
//    // timer: 1500
//   })
//  }
// )
}
}
