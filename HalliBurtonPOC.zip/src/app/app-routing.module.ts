import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NotFoundComponent } from './shared/not-found/not-found.component';
import { LoginComponent } from './shared/login/login.component';
import { ManagementPortalComponent } from './admin/management-portal/management-portal.component';
import { PoDashboardComponent } from './admin/po-dashboard/po-dashboard.component';
import { PoItemComponent } from './admin/po-dashboard/po-item/po-item.component';


const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: '',   redirectTo: '/LoginComponent',pathMatch: 'full'},
  { path:'admin/management', component:ManagementPortalComponent},
  { path:'admin/dashboard', component:PoDashboardComponent},
  { path:'admin/po', component:PoItemComponent},
  { path: '**', component: NotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
