import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ManagementPortalComponent } from './admin/management-portal/management-portal.component';
import { VendorManagementComponent } from './admin/management-portal/vendor-management/vendor-management.component';
import { ItemManagementComponent } from './admin/management-portal/item-management/item-management.component';
import { PoDashboardComponent } from './admin/po-dashboard/po-dashboard.component';
import { PoSummaryComponent } from './admin/po-dashboard/po-summary/po-summary.component';
import { VendorDashboardComponent } from './vendor/vendor-dashboard/vendor-dashboard.component';
import { LoginComponent } from './shared/login/login.component';
import { NotFoundComponent } from './shared/not-found/not-found.component';
import { HeaderComponent } from './shared/header/header.component';
import {SortablejsModule} from 'ngx-sortablejs';
import { PoItemComponent } from './admin/po-dashboard/po-item/po-item.component';
import { ItemTrackerComponent } from './admin/item-tracker/item-tracker.component';

@NgModule({
  declarations: [
    AppComponent,
    ManagementPortalComponent,
    VendorManagementComponent,
    ItemManagementComponent,
    PoDashboardComponent,
    PoSummaryComponent,
    VendorDashboardComponent,
    LoginComponent,
    NotFoundComponent,
    HeaderComponent,
    PoItemComponent,
    ItemTrackerComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    FormsModule,
    SortablejsModule.forRoot({ animation: 150 }),
    BsDatepickerModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
