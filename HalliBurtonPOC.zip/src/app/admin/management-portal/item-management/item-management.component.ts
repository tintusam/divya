import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-item-management',
  templateUrl: './item-management.component.html',
  styleUrls: ['./item-management.component.css']
})
export class ItemManagementComponent implements OnInit {

  constructor() { }
  items = [1, 2, 3, 4, 5];
  stepsData:any;
  ngOnInit(): void {
    this.stepsData = [
      {
        id: 1,
        description: "Receiving Raw Materials",
        duration:"3 Days"
      },
      {
        id: 2,
        description: "Incoming Inspection",
        duration:"3 Days"
      },
      {
        id: 3,
        description: "Milling",
        duration:"4 Days"
      },
      {
        id: 4,
        description: "Outgoing Inspection",
        duration:"3 Days"
      },
      {
        id: 5,
        description: "Drilling & Threading",
        duration:"4 Days"
      } ,
      {
        id: 6,
        description: "Incoming Inspection",
        duration:"3 Days"
      },
      {
        id: 7,
        description: "Milling",
        duration:"4 Days"
      },
      {
        id: 8,
        description: "Outgoing Inspection",
        duration:"3 Days"
      },
      {
        id: 9,
        description: "Drilling & Threading",
        duration:"4 Days"
      }            
    ]
  }



}
