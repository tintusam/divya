import { Component, OnInit } from '@angular/core';
declare var $: any;

@Component({
  selector: 'app-vendor-management',
  templateUrl: './vendor-management.component.html',
  styleUrls: ['./vendor-management.component.css']
})
export class VendorManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    $(document).ready(function() {
      $('#timeZoneContent').timezonePicker({
        defaultValue: { value: "IN", attribute: "country" },
        showHoverText:false,
        selectBox:false,
        hoverText:true
    });
    });
  }

}
