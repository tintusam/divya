import { Component, OnInit } from '@angular/core';
import {formatDate } from '@angular/common';
declare var $: any;

@Component({
  selector: 'app-vendor-management',
  templateUrl: './vendor-management.component.html',
  styleUrls: ['./vendor-management.component.css']
})
export class VendorManagementComponent implements OnInit {
  public selectedTimeZone:String;
  today= new Date();
  todaysDataTime = '';
  public showUploadForm:boolean = false;
  constructor() { 
    //this.todaysDataTime = formatDate(this.today, 'dd/MMM/yyyy hh:mm:ss a', 'en-US', '+0530');
    this.todaysDataTime = formatDate(this.today, 'long', 'en-US', '+0530');
  }

  ngOnInit(): void {
    //this.selectedTimeZone = 'Australia/Darwin'; 
    this.selectedTimeZone = 'Asia/Calcutta'; 
    $(document).ready(() => {
      $('#timeZoneContent').timezonePicker(
        {
          defaultValue: { value: this.selectedTimeZone, attribute: "timezone" },
          width:500,
          height:300,
          showHoverText:false,
          selectBox:true,
          hoverText:true,
          quickLink:[]
        }
      );
      $('#timeZoneContent').on("map:loaded" , function(){
        //console.log("Map is loaded, have fun!");
        //$('#timeZoneContent').data('timezonePicker').setValue('Australia/Darwin')
      });

//       $('#timeZoneContent').on("map:value:changed" , function(){
//         console.log($('#timeZoneContent').data('timezonePicker').getValue());
//     });

//     $('#timeZoneContent').on("map:option:changed" , function(){
//       console.log($('#timeZoneContent').data('timezonePicker').getValue());
//   });

//   $('#timeZoneContent').on("map:country:clicked" , function(){
//     console.log($('#timeZoneContent').data('timezonePicker').getValue());
// });


    });
  }

  toggleUploadForm(){
    this.showUploadForm = !this.showUploadForm;
    console.log(this.showUploadForm);
  }


}
