import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-po-item',
  templateUrl: './po-item.component.html',
  styleUrls: ['./po-item.component.css']
})
export class PoItemComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
